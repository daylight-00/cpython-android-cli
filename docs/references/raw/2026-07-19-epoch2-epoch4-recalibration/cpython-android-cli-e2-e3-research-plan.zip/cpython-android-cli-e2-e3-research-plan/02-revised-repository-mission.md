# Revised Repository Mission


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Decision

`cpython-android-cli` is a **research laboratory**, not the future release repository.

Its permanent responsibilities are:

```text
research questions
bounded experiments
machine-readable contracts
exact evidence
alternative implementations
failure preservation
comparative qualification
architecture decisions
product-seed provenance
```

Its responsibilities explicitly exclude the long-term product surface:

```text
public releases
production distribution endpoints
upstream/downstream integration ownership
user-facing installer product
release-channel policy
final product branding
long-term support and maintenance
```

## Why this separation is appropriate

The current repository contains a valuable, dense evidence history: failed attempts, frozen predecessor authorities, lifecycle systems, result archives, and corrective audits. Removing this material would reduce trust; exposing all of it as the final product repository would reduce clarity.

A clean product repository should contain only selected, accepted implementation and support surfaces. The laboratory remains the authority explaining why those choices were made.

## Revised authority flow

```text
laboratory hypothesis
  -> bounded experiment
  -> independent verifier
  -> target evidence
  -> frozen conclusion
  -> architecture decision
  -> hash-identified product seed
  -> clean repository import
```

The clean repository must never become the evidence source for a laboratory claim. Conversely, the laboratory must not claim public product readiness merely because an implementation works in experiments.

## Change from the current Epoch 2 charter

The current charter anticipates eventual history-preserving repository promotion. The revised direction instead keeps the research repository intact and exports a frozen, provenance-bearing seed into a separately initialized clean repository.

This change requires an explicit ADR in the project before implementation. It must not silently reinterpret the current charter.

Relevant current references:

- [Epoch 2 Charter](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/epochs/EPOCH2_CHARTER.md)
- [Repository Topology ADR](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/decisions/ADR-0003-REPOSITORY-TOPOLOGY.md)
- [Component Ownership](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/architecture/COMPONENT_OWNERSHIP.md)

## Confirmed repository identities

| Repository | Identity |
|---|---|
| `cpython-android-cli` | permanent research and evidence authority |
| future clean repository | selected product implementation and release authority |

No release, integration, or publication milestone is required to close Epoch 2 or Epoch 3 in the laboratory.
