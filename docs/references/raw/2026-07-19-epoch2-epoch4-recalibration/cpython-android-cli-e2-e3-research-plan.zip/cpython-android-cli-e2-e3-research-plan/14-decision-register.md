# Decision Register


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Confirmed decisions

| ID | Decision |
|---|---|
| D-01 | The final technical direction is an Astral-like Android/Bionic standalone CPython product. |
| D-02 | The current repository remains the research, experiment, evidence, and contract laboratory. |
| D-03 | Epoch 2 completes fundamental Android adaptation experiments before structural Astral-like assembly. |
| D-04 | Epoch 3 reassembles the selected evidence into an Astral-like producer and artifact family. |
| D-05 | Release, integration, publication, and long-term maintenance belong to a separately initialized clean repository. |
| D-06 | Priority order is Astral-like standalone, Android/Bionic-native core, fresh direct extraction, then APK. |
| D-07 | Existing Epoch 1 and Epoch 2 authorities are preserved as immutable baselines. |
| D-08 | The current Termux-native producer is a reference producer, not the automatically final producer architecture. |
| D-09 | `termux-cli` is an execution profile, not an ABI or canonical platform identity. |
| D-10 | APK requirements must not control initial linkage, dependency, or artifact decisions. |

## Decisions reserved for Epoch 3 after Epoch 2 evidence

| ID | Decision input required |
|---|---|
| R-01 | static-interpreter hybrid versus shared-libpython-primary |
| R-02 | static dependency closure versus private Python-namespaced shared dependencies |
| R-03 | built-in versus shared stdlib extension policy |
| R-04 | current self-reexec launcher versus relative ELF loader topology |
| R-05 | Linux cross-producer, Termux-native producer, or dual-host authority |
| R-06 | final Android API floor and supported ABI set |
| R-07 | final runtime relocatability wording |
| R-08 | development-SDK relocation and optional initialization policy |
| R-09 | final `full` artifact contents and reconstruction promise |
| R-10 | PGO/LTO release profiles and target runner integration |
| R-11 | CA, timezone, terminfo, and host-data ownership model |

## Explicitly deferred product decisions

```text
public release channel
signature/attestation policy
production uv catalog entry
installer UX and update policy
repository branding
APK packaging
```

## Governance rule

A reserved decision may be promoted to confirmed only when the cited Epoch 2 evidence compares the material alternatives or proves that Android makes one alternative impossible.
