# References

## Reviewed repository authority

- [`cpython-android-cli` commit `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069) — E2-P3 real Termux qualification authority frozen.
- [README](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/README.md)
- [Current Context](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/CURRENT_CONTEXT.md)
- [Project Orientation](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_ORIENTATION.md)
- [Epoch 1 Closure](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/epochs/EPOCH1_CLOSURE.md)
- [Epoch 2 Charter](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/epochs/EPOCH2_CHARTER.md)
- [Epoch 2 Roadmap](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/roadmap/EPOCH2_ROADMAP.md)
- [Component Ownership](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/architecture/COMPONENT_OWNERSHIP.md)
- [E2-P1 Standalone Artifact Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P1_STANDALONE_ARTIFACT_CONTRACT.md)
- [E2-P2 Standalone Façade Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P2_STANDALONE_FACADE_CONTRACT.md)
- [E2-P2 Termux-native Producer Authority](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P2_TERMUX_NATIVE_CPYTHON3146_PRODUCER_AUTHORITY.md)
- [E2-P3 Archive Qualification Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P3_ARCHIVE_QUALIFICATION_CONTRACT.md)
- [E2-P3 Real Termux Qualification Freeze](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/evidence/E2P3_REAL_TERMUX_ARCHIVE_QUALIFICATION_AUTHORITY_FREEZE.md)
- [Stage 2-C Design](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/stages/STAGE2C_DESIGN.md)
- [Stage 3-D Consumer Integration](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3D.md)
- [Stage 3-E Managed-Python Distribution](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3E.md)
- [Stage 3-F Publication and Acquisition](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3F.md)

## Astral primary reference

- [Astral `python-build-standalone`](https://github.com/astral-sh/python-build-standalone)
- [Distribution archive documentation](https://github.com/astral-sh/python-build-standalone/blob/main/docs/distributions.rst)
- [Running distributions](https://github.com/astral-sh/python-build-standalone/blob/main/docs/running.rst)
- [Build status and target coverage](https://github.com/astral-sh/python-build-standalone/blob/main/docs/status.rst)
- [uv repository](https://github.com/astral-sh/uv)
- [uv Python environment documentation](https://github.com/astral-sh/uv/blob/main/docs/pip/environments.md)

## CPython and Android primary references

- [CPython: Using Python on Android](https://docs.python.org/3.14/using/android.html)
- [PEP 738 — Adding Android as a supported platform](https://peps.python.org/pep-0738/)
- [CPython Android platform tooling](https://github.com/python/cpython/tree/main/Android)
- [Android NDK Native APIs](https://developer.android.com/ndk/guides/stable_apis)
- [Android NDK: Using newer APIs](https://developer.android.com/ndk/guides/using-newer-apis)
- [Android NDK revision history](https://developer.android.com/ndk/downloads/revision_history)

## Python packaging references

- [Platform Compatibility Tags — Android](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/#android)
- [Binary Distribution Format](https://packaging.python.org/en/latest/specifications/binary-distribution-format/)

## Reference policy

Repository evidence is used for statements about what this project has proven. Official upstream documentation is used for platform, packaging, and reference-model facts. Discussion-derived architecture decisions are identified as proposed or confirmed project decisions rather than attributed to upstream projects.
