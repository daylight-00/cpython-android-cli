# Current Achievements and Inherited Authorities


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Conclusion

The repository has already completed the empirical work needed to prove that an official-upstream-lineage CPython Android runtime can become a practical, relocatable Termux CLI product. It has also frozen a standalone archive contract, a stable build/package/verify façade, a real deterministic envelope, and a real-device archive-only qualification authority. Epoch 2 must preserve these results as comparison authorities, not redo them under new names.

## Epoch 1 achievements

Epoch 1 established four evidence domains:

### Runtime and relocation

- the `R2` conditional self-re-exec launcher;
- `B0` PyConfig automatic path discovery;
- correct CLI, subprocess, venv, and uv explicit-interpreter behavior;
- whole-prefix relocation;
- separate loader, CA, and timezone-data boundaries.

### Native closure

The frozen runtime evidence identified:

```text
81 ELF objects
329 DT_NEEDED edges
9 needed SONAMEs
67/67 isolated extension imports
0 unresolved edges
0 Termux native-library edges
```

### Producer and lifecycle

- explicit CPython, NDK, dependency, launcher, and package provenance;
- CPython 3.14.5 and 3.14.6 product authorities;
- runtime-base, development-addon, and test-addon ownership;
- transactional install, recovery, repair, uninstall, and exact bidirectional transitions;
- project-owned uv managed-Python feasibility and immutable acquisition evidence.

### Authority discipline

- exact bytes and hashes are identities;
- failed and corrected attempts remain evidence;
- target evidence outranks design assumptions;
- a narrow PASS is never promoted into a broader claim.

Primary repository references:

- [Epoch 1 Closure](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/epochs/EPOCH1_CLOSURE.md)
- [Stage 3-C project context](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3C.md)
- [Stage 3-D consumer integration](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3D.md)
- [Stage 3-E managed-Python distribution](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3E.md)
- [Stage 3-F publication and acquisition](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/PROJECT_CONTEXT_STAGE3F.md)

## Epoch 2 achievements through the reviewed commit

### Product contract

E2-P1 freezes an immutable release-envelope model:

```text
archive bytes
+ artifact metadata
+ exact manifest
+ provenance
+ qualification result
+ licenses
+ SHA256SUMS
+ release index
```

The primary artifact is an `install_only_stripped` `pax-tar+zstd` archive with one `python/` root and runtime plus development payloads.

### Stable façade

E2-P2 provides stable `plan`, `build`, `package`, and `verify` operations while fail-closing on tracked-input drift.

### Real producer and envelope authority

The Termux-native CPython 3.14.6 producer, its three-artifact set, the façade binding, and real façade execution are frozen. Canonical and replay packaging produced byte-identical envelope files.

### Archive-only qualification

At `c05cf9b608b69903aabaf42047cfa921276a6069`, the `termux-real` profile is frozen:

```text
qualification       35/35
result verification 19/19
independent review  38/38
selectable          false
```

The same frozen archive produced the observed 81-ELF, 329-edge, 67-extension surface and passed HTTPS, offline pip, explicit-interpreter uv, venv relocation, Android wheel-tag, and mutation controls.

Primary repository references:

- [Current Context](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/CURRENT_CONTEXT.md)
- [E2-P1 Artifact Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P1_STANDALONE_ARTIFACT_CONTRACT.md)
- [E2-P2 Façade Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P2_STANDALONE_FACADE_CONTRACT.md)
- [E2-P3 Qualification Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P3_ARCHIVE_QUALIFICATION_CONTRACT.md)
- [E2-P3 Real Termux Qualification Freeze](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/evidence/E2P3_REAL_TERMUX_ARCHIVE_QUALIFICATION_AUTHORITY_FREEZE.md)

## What these authorities do not prove

They do not yet prove:

- an Astral-structured producer;
- independent dependency recipes matching Astral's build graph;
- a final static/shared linkage policy;
- generic adb/root execution qualification;
- a final definition of runtime versus development relocatability;
- a final `full` archive layout;
- release, publication, upstream uv integration, or a clean product repository.

## Confirmed disposition

Every accepted Epoch 1 and Epoch 2 authority remains immutable and becomes one of:

1. a regression oracle for Epoch 3;
2. a reference implementation of one Android adaptation strategy;
3. a negative or alternative-design authority;
4. an input to the final research-to-product seed.
