# Toolchain, Sysconfig, Wheel, and Optimization Experiments


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Build-host authority

The project currently has both Linux cross-producer and Termux-native producer history. Epoch 2 must determine what these host classes mean for the final product.

Compare:

```text
controlled Linux cross-build
Termux-native Android/Bionic build
optional same-source dual-host replay
```

The question is not whether both can produce some Python. It is whether they can produce equivalent declared artifacts and which host is suitable for the final Astral-like build authority.

## NDK and linker authority

The current Termux-native producer uses exact custom NDK bytes and an ephemeral linker overlay. Epoch 2 must isolate:

- whether the overlay remains necessary;
- whether the issue is specific to producer host, CPython topology, or linker configuration;
- whether a stock pinned NDK can produce the accepted result;
- what exact tool bytes and patches must be recorded in provenance.

A matching NDK release number is not enough to imply matching toolchain bytes; the current repository already treats that as a forbidden substitution.

Reference: [E2-P2 Termux-native Producer Authority](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P2_TERMUX_NATIVE_CPYTHON3146_PRODUCER_AUTHORITY.md).

## Configure and cross-build facts

Separate:

```text
true Android/Bionic feature absence
upstream CPython cross-build requirements
host-shell incompatibilities
historical cache workarounds
project-specific temporary adapters
```

Each cache answer must have a source mapping or a target probe, not just historical precedent.

## Sysconfig and SDK behavior

Test:

- no host/Termux/build-root path leaks;
- dynamic prefix paths after extraction;
- Android API, ABI, SOABI, MULTIARCH, and platform identity;
- compiler and linker metadata for native extension builds;
- static and shared library references;
- `python-config` and pkg-config behavior.

## Wheel ecosystem

Required experiments:

1. pure-Python wheel install;
2. trivial Android native wheel build and import;
3. wheel targeting `android_24_arm64_v8a`;
4. wheel with a private native dependency;
5. wheel linked or not linked to `libpython` according to each candidate topology;
6. incompatible API/ABI wheel rejection;
7. source distribution build using extracted SDK metadata.

Android platform tags follow the `android_apilevel_abi` scheme. See [PyPA Platform Compatibility Tags](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/#android).

## PGO and LTO feasibility

Epoch 2 should prove mechanisms, not finalize release profiles.

### LTO

- link complete candidate runtime with NDK LLVM LTO;
- verify extension loading and debug/provenance implications;
- compare ELF and size properties.

### PGO

- instrument target build;
- deploy to real device or emulator;
- run declared profile workload;
- collect and merge profiles;
- rebuild and verify identity and behavior.

The result should define a target-runner interface that Epoch 3 can integrate into Astral-like build profiles.

## Epoch 2 output

```text
accepted host roles
accepted NDK/tool identities
required patches or overlays
sysconfig contract
wheel-development contract
PGO/LTO feasibility authority
```

Epoch 3 turns these into target definitions and build profiles.
