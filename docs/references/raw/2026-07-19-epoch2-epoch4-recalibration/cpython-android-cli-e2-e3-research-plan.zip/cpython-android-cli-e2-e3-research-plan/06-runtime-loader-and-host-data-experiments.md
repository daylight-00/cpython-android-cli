# Runtime, Loader, and Host-Data Experiments


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Existing authority

The current runtime uses:

```text
R2 conditional self re-exec
+ B0 PyConfig auto-discovery
```

It derives the prefix from the executable, prepares native library lookup, repairs or preserves CA configuration, and enters normal CPython initialization. This is a valid and strongly evidenced Android/Termux adaptation, but it is not automatically the final Epoch 3 implementation.

Reference: [Stage 2-C Design](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/stages/STAGE2C_DESIGN.md).

## Remaining fundamental questions

### Is re-exec intrinsically required?

Compare at least:

```text
A. current LD_LIBRARY_PATH + conditional self-reexec
B. executable-relative DT_RUNPATH/RPATH where supported
C. loader wrapper or alternate entry executable
D. shared-libpython layout with direct DT_NEEDED resolution
```

The experiment must distinguish:

- initial process startup;
- extension-module dependency loading after startup;
- subprocess identity;
- venv and symlink invocation;
- adb and Termux behavior.

### What must the core launcher own?

The final core should own only behavior required to start a standalone Bionic Python consistently:

```text
self-location
native runtime discovery
Python path discovery
argv/exit/stdio semantics
stable subprocess identity
```

It should not automatically own every host-data policy.

### CA trust

Compare:

1. bundled CA bundle;
2. Termux CA discovery;
3. Android/system certificate integration if practical for native CLI;
4. explicit environment configuration;
5. absence/fail-closed behavior.

Record both functionality and ownership. `HTTPS=PASS` is insufficient unless the evidence states which authority supplied trust.

### Timezone data

Compare:

- platform TZPATH availability;
- Termux timezone data;
- first-party `tzdata` package fallback;
- optional bundled tzdata.

### Terminal, readline, curses, and terminfo

Determine whether a core CLI can provide interactive behavior without hardcoding Termux paths. Test bundled terminfo, profile-provided terminfo, and absence behavior separately.

### Temporary and home directories

Verify that the core does not encode Termux paths. Profiles may supply `HOME` and `TMPDIR`, but failure behavior and defaults must be explicit.

## Required context matrix

| Context | Scope |
|---|---|
| Termux real device | full acceptance |
| Termux emulator | harness and environment parity |
| adb shell | differential core/profile probe |
| root shell | only where UID, namespace, or executable-path behavior differs materially |

## Epoch 2 conclusion target

Epoch 2 should not select the final launcher source layout. It should freeze:

- valid bootstrap mechanisms;
- mechanisms rejected on Android;
- required core responsibilities;
- profile-owned host data;
- conditions under which current R2 remains the selected fallback.
