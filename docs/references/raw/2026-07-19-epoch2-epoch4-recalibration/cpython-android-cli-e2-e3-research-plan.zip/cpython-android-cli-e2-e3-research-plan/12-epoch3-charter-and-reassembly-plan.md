# Epoch 3 Charter and Astral-Like Reassembly Plan


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Mission

> Epoch 3 uses the frozen Epoch 2 evidence to construct, compare, and select an Astral-like Android/Bionic standalone CPython producer and artifact family.

Epoch 3 is a structural and decision epoch, not the primary experimental discovery epoch.

## Reference hierarchy

```text
1. Astral python-build-standalone producer and artifact philosophy
2. official CPython Android source and platform behavior
3. Android NDK public ABI and toolchain rules
4. Epoch 2 accepted Android adaptation evidence
5. Epoch 1 behavior and lifecycle regression authorities
6. Termux implementation history as a supporting reference
```

## Epoch 3 phases

### E3-P0 — Reference and charter freeze

- pin the Astral source commit;
- define which Astral contracts are copied, mapped, or intentionally diverged;
- pin CPython, NDK, target, API floor, and initial architecture;
- import Epoch 2 decision inputs.

### E3-P1 — Producer skeleton

Recreate the Astral-style responsibilities:

```text
build entry point
target configuration
dependency source and build graph
host/target split
extension metadata and generated Setup
build profiles
full and install-oriented outputs
```

### E3-P2 — Final topology selection

Using Epoch 2 evidence, select:

- static-interpreter hybrid or shared-libpython-primary;
- built-in/shared stdlib extension policy;
- static/private-shared dependency policy;
- system-library allowlist;
- bootstrap and loader mechanism;
- core versus execution-profile boundaries.

No topology is selected merely because it visually resembles Astral.

### E3-P3 — Artifact family

Define exact layouts for:

```text
full
install_only
install_only_stripped
symbols, if retained
```

The `full` artifact must reflect real reconstruction and audit needs, not just reserve an Astral-compatible filename.

### E3-P4 — Final relocatability and SDK contract

Select the guarantee using Epoch 2 evidence:

- mandatory fresh-extraction runtime behavior;
- development metadata behavior;
- optional initialization, if any;
- explicit post-mutation exclusions.

### E3-P5 — Comparative qualification

Run the producer output through producer-independent Epoch 2 harnesses and compare it with the reference producer baseline.

Acceptance includes intentional differences only when they are documented and independently justified.

### E3-P6 — Laboratory freeze

Freeze:

```text
selected producer
build graph
patch set
dependency identities
artifact family
qualification results
architecture decisions
product-seed export
```

## Astral reference boundary

Astral produces redistributable Python builds with full and install-oriented artifact classes and is consumed by tools such as uv. See the [python-build-standalone repository](https://github.com/astral-sh/python-build-standalone) and its [distribution documentation](https://github.com/astral-sh/python-build-standalone/blob/main/docs/distributions.rst).

Epoch 3 follows the reference as closely as Android evidence permits. Divergence requires an explicit decision record naming the Android constraint and the rejected preserved implementation.

## Epoch 3 does not own

```text
public release channels
production catalog integration
installer UX
promotion workflow
upstream contribution process
APK productization
```

These belong to the clean product repository.
