# Epoch 2 Continue, Stop, and Defer Matrix


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Continue now

| Work | Reason |
|---|---|
| Finish the existing `termux-emulator` E2-P3 profile | It is already part of the frozen qualification contract and tests harness portability against the same archive. |
| Preserve combined E2-P3 acceptance as non-selectable evidence | It closes the current bounded contract without turning it into release authority. |
| Build producer-independent qualification tools | Epoch 3 must be judged by the same external evidence. |
| Run core/profile boundary experiments | Termux-specific CA, shell, temp, and timezone behavior must not leak into the final core identity. |
| Expand fresh-extraction and development-relocation evidence | The final relocatability contract cannot be selected safely without it. |
| Test dependency/linkage alternatives | Static closure, private shared libraries, and `libpython` topology are fundamental architecture decisions. |
| Test build-host and NDK assumptions | Epoch 3 must know whether Linux cross-build, Termux-native build, or both are authoritative. |
| Test Android wheel and native-extension development | The runtime must support the intended package ecosystem, not only bundled imports. |
| Test target-side PGO and LTO feasibility | Astral-like profiles need evidence that Android execution and toolchain collection are workable. |
| Run adb differential probes | They distinguish Android/Bionic core behavior from Termux profile behavior. |

## Stop after current bounded closure

| Work | Why it should stop |
|---|---|
| More current-producer release-envelope polish | The current producer is a reference producer, not the final producer architecture. |
| Selectability and release metadata finalization | Selection belongs to the clean product repository after Epoch 3. |
| Public publication/acquisition implementation | Epoch 1 already proved bounded acquisition concepts; public operations are product-repository concerns. |
| Full production installer conversion | Only a reference artifact-only consumer proof is needed in the lab. |
| Additional multi-version transition matrices | Epoch 1 already provides strong lifecycle evidence; this does not decide Android standalone architecture. |
| Global Termux shell exposure | It is integration policy, not core research. |
| Production uv managed-root design | Keep only explicit-interpreter and bounded catalog qualification fixtures. |
| Repository promotion work | The chosen direction is a separately initialized clean repository. |

## Defer to Epoch 3

| Work | Reason |
|---|---|
| Astral-like repository/build layout | It should encode selected evidence, not precede it. |
| Final target configuration schema | It depends on completed toolchain and API-floor evidence. |
| Final dependency graph and extension metadata | It depends on linkage experiments. |
| Final `full` archive contract | It depends on the chosen producer and downstream reconstruction needs. |
| Final relocation guarantee | Epoch 3 decides the contract after Epoch 2 finishes experiments. |
| Final `libpython` topology | Epoch 2 supplies experiments; Epoch 3 selects. |
| Final static/shared dependency policy | Epoch 2 supplies comparative evidence; Epoch 3 selects. |
| Final PGO/LTO profiles | Epoch 2 proves feasibility; Epoch 3 integrates them. |

## Defer to the clean product repository

```text
release automation
public artifacts
channels and mirrors
production signatures/attestations
upstream uv catalog integration
user-facing installer and update policy
brand and support documentation
long-term CI and maintenance
```

## Defer as Priority 4

APK packaging, JNI embedding UX, app lifecycle, and Play-oriented packaging must not control Epoch 2 or initial Epoch 3 choices. A narrow embedding compatibility probe is allowed only when needed to understand `libpython` ABI behavior; it is not APK product development.
