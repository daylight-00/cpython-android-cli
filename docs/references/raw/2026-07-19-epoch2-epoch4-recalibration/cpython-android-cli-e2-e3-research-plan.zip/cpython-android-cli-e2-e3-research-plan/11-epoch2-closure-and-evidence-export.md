# Epoch 2 Closure and Evidence Export


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Closure principle

Epoch 2 closes when all fundamental Android adaptation experiments needed by Epoch 3 have accepted conclusions or explicitly valid alternatives. It does not close when a product is publishable.

## Required closure gates

### Gate 1 — existing E2-P3 completion

- `termux-real` remains frozen;
- `termux-emulator` runs against the same archive;
- combined result is recorded without selectability or publication.

### Gate 2 — core/profile boundary

- loader/bootstrap responsibility is classified;
- CA, timezone, terminfo, HOME, TMPDIR, and shell ownership is classified;
- adb differential evidence is frozen.

### Gate 3 — relocatability

- fresh-extraction runtime matrix is complete;
- development-SDK relocation is separately measured;
- post-mutation movability is explicitly excluded or separately scoped.

### Gate 4 — dependency and linkage

- `libpython` alternatives are experimentally compared;
- static versus private-shared dependencies are compared;
- representative stdlib extensions and native wheels are tested;
- valid and rejected alternatives are frozen.

### Gate 5 — toolchain and package-development surface

- build-host authority is classified;
- NDK/overlay requirements are understood;
- sysconfig and native-wheel behavior are accepted;
- PGO/LTO feasibility is established.

### Gate 6 — synthesis

- all evidence is machine-readable and independently reviewed;
- Epoch 3 receives a decision-input package;
- all release/integration work is explicitly outside the laboratory epoch.

## Epoch 2 evidence package

```text
epoch2-evidence-export/
├── authorities/
├── contracts/
├── baselines/
│   ├── runtime-identity.json
│   ├── native-closure.json
│   ├── extension-surface.json
│   ├── host-data-boundaries.json
│   ├── relocation-matrix.json
│   ├── linkage-alternatives.json
│   ├── sysconfig-wheel-matrix.json
│   └── build-host-toolchain-matrix.json
├── decision-inputs/
├── negative-evidence/
├── REFERENCES.md
├── EPOCH2-CLOSURE.json
└── SHA256SUMS
```

## Required claim boundary

Epoch 2 closure must state that it does not authorize:

```text
public release
selectability
publication
production installer
upstream uv integration
clean-repository release automation
APK product
```

## Epoch 3 handoff condition

Epoch 3 may begin when its structural work no longer needs to invent or test a fundamental Android behavior. New experiments are allowed only when Epoch 3 integration reveals a previously unrecognized interaction; such experiments must return to the laboratory evidence model rather than being hidden as implementation fixes.
