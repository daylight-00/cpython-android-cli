# Dependency, Linkage, and Extension Experiments


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Purpose

This is one of the most important remaining Epoch 2 areas. Epoch 3 must not select Astral-like static closure, official-Android-style private shared dependencies, or a `libpython` topology based only on conceptual preference.

## Independent decision axes

```text
Axis 1  interpreter/libpython topology
Axis 2  stdlib extension built-in versus shared
Axis 3  third-party dependency static versus private shared
Axis 4  dependency naming and symbol visibility
Axis 5  native wheel linkage contract
```

These axes must not be collapsed into one binary choice.

## Interpreter/libpython experiments

Compare:

### Astral-style hybrid baseline

```text
interpreter contains static libpython code
shared libpython also distributed
```

### Shared-libpython-primary

```text
python executable DT_NEEDED -> libpython.so
CLI, native extensions, and future embedders use one runtime library
```

Required tests:

- startup and relocation;
- extension loading;
- extension explicitly linked and not linked to libpython;
- duplicate runtime-state detection;
- symbol export and visibility;
- subprocess and venv behavior;
- package size and startup cost;
- Android linker behavior across API floor and current API.

APK is not the decision driver. A minimal embedding probe may be used only to detect ABI impossibility.

## Dependency-closure experiments

Compare at least the following for OpenSSL, SQLite, and libffi:

### Static closure

Dependency code is linked into built-in/shared Python components, following the Astral Unix preference where practical.

### Private shared bundle

Python-specific SONAMEs such as `libssl_python.so` or equivalent are packaged and linked privately, following official CPython Android packaging patterns where necessary.

Required observations:

- complete `DT_NEEDED` graph;
- symbol collisions and interposition;
- duplicate library instances;
- independent security update implications;
- artifact size and memory sharing;
- direct extraction and RUNPATH complexity;
- wheel/native extension interoperability;
- API-floor behavior;
- reproducibility and license inventory.

## Extension topology

For representative modules:

```text
_ssl and _hashlib
_sqlite3
_ctypes
zlib / _bz2 / _lzma
_decimal
_socket and _multiprocessing
```

compare built-in/static and shared extension forms where technically meaningful.

## System-library policy

Only public NDK ABI libraries may be host dependencies. Platform-private libraries are forbidden. The current E2 baseline includes Android-system SONAMEs such as `libc.so`, `libdl.so`, `liblog.so`, `libm.so`, and `libz.so`; Epoch 2 experiments must determine whether `libz.so` remains a system dependency or moves into a pinned closure.

Reference: [Android NDK Native APIs](https://developer.android.com/ndk/guides/stable_apis).

## Required decision evidence

Each topology must yield:

```text
build recipe
ELF graph
symbol/export report
runtime matrix
native-wheel matrix
relocation matrix
size metrics
failure cases
security/update implications
```

## Epoch boundary

Epoch 2 freezes the comparative authority and identifies valid/rejected alternatives. Epoch 3 selects the final topology and maps it into Astral-like extension metadata and dependency recipes.
