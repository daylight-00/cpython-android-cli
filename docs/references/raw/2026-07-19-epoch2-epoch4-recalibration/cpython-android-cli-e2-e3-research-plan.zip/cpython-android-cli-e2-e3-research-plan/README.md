# Android/Bionic CPython Research Boundary: Epoch 2 to Epoch 3


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Governing conclusion

This repository is not the future public release repository. It is the permanent research, experiment, evidence, and contract authority used to eliminate Android-specific uncertainty before a clean product repository implements release, distribution, consumer integration, and long-term maintenance.

```text
Epoch 1
  practical Android CPython CLI and lifecycle evidence
        ↓
Epoch 2
  producer-independent Android adaptation evidence
  and qualification contracts
        ↓
Epoch 3
  Astral-like reassembly and final architecture decisions
        ↓
Frozen research-to-product seed
        ↓
Clean product repository
  release, integration, publication, maintenance
```

## Reading order

1. [Project achievements and inherited authorities](01-current-achievements-and-authorities.md)
2. [Revised repository mission](02-revised-repository-mission.md)
3. [Epoch 2 revised scope](03-epoch2-revised-scope.md)
4. [Continue, stop, and defer matrix](04-epoch2-continue-stop-defer.md)
5. [Android adaptation evidence agenda](05-android-adaptation-evidence-agenda.md)
6. [Runtime, loader, and host-data experiments](06-runtime-loader-and-host-data-experiments.md)
7. [Relocatability experiment program](07-relocatability-experiment-program.md)
8. [Dependency, linkage, and extension experiments](08-dependency-linkage-and-extension-experiments.md)
9. [Toolchain, build-host, sysconfig, wheel, and optimization experiments](09-toolchain-sysconfig-wheel-and-optimization-experiments.md)
10. [Cross-context and consumer qualification](10-cross-context-and-consumer-qualification.md)
11. [Epoch 2 closure and evidence export](11-epoch2-closure-and-evidence-export.md)
12. [Epoch 3 charter and reassembly plan](12-epoch3-charter-and-reassembly-plan.md)
13. [Clean product repository boundary](13-clean-product-repository-boundary.md)
14. [Decision register](14-decision-register.md)
15. [Module review notes](REVIEW-NOTES.md)
16. [References](REFERENCES.md)

## Priority order

```text
Priority 1  Astral-like standalone product architecture
Priority 2  true Android/Bionic native core, not Termux-bound
Priority 3  fresh direct extraction into any suitable path
Priority 4  APK consumption, deferred
```

Priority 1 does not mean prematurely copying Astral directory names. In Epoch 2 it means collecting the evidence needed so Epoch 3 can adopt Astral's producer and artifact structure without hiding unresolved Android-specific behavior behind a familiar surface.
