# Relocatability Experiment Program


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Terminology

The project must separate three guarantees.

### Fresh-extraction runtime relocatability

An untouched archive is extracted into any suitable executable path, and the CPython runtime works without installer path patching.

### Development-SDK relocatability

Headers, `sysconfig`, Makefiles, `python-config`, pkg-config data, and compiler/linker metadata work from the chosen extraction prefix.

### Post-mutation movability

An installation is moved after venvs, packages, or console scripts have been created.

Priority 3 requires the first guarantee. The second is a high-value standalone SDK goal. The third is outside the core guarantee unless separately accepted.

## Existing evidence

Epoch 1 and E2-P3 strongly prove whole-prefix relocation under Termux, including two extraction locations, stale-prefix absence, relocated sysconfig paths, venv behavior, and product fidelity. The evidence must be retained as the baseline.

Reference: [E2-P3 Qualification Contract](https://github.com/daylight-00/cpython-android-cli/blob/c05cf9b608b69903aabaf42047cfa921276a6069/docs/contracts/E2P3_ARCHIVE_QUALIFICATION_CONTRACT.md).

## Remaining experiment matrix

### Location variation

```text
short path
deep path
different basename
symlink entry point
Termux private storage
/data/local/tmp under adb
root-owned executable directory when relevant
```

### Runtime checks

- `sys.executable`, `sys.prefix`, `sys.exec_prefix`, `sys.base_prefix`;
- stdlib and native extension imports;
- subprocess child identity;
- HTTPS and runtime data discovery;
- no old-prefix strings in active paths;
- no product mutation or pycache mutation where prohibited.

### Development checks

- `sysconfig.get_paths()`;
- `python-config` and pkg-config;
- compile and import a trivial native extension;
- build and install an Android wheel;
- check that compiler paths and NDK requirements are represented intentionally rather than leaked accidentally.

### Zero-fixup boundary

The experiment must record whether each surface works:

```text
immediately after extraction
only after optional SDK initialization
only through an installer
not supported
```

Runtime-critical behavior must not require uv or an installer fixup. Development metadata may permit an explicit one-time SDK initialization only if Epoch 3 decides that the stronger dynamic-prefix model is impractical.

## Android-specific suitability boundary

“Any path” means a path that:

- is executable for the current UID;
- preserves Unix modes and symlinks;
- is readable and traversable;
- satisfies Android security policy.

Shared emulated storage is not a required target.

## Epoch 2 output

Epoch 2 freezes evidence, not the final wording. Epoch 3 must select and document the final guarantee from this evidence, including explicit exclusions for moved venvs and post-install console-script shebangs.
