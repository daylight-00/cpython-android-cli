# Epoch 2 Revised Scope


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Epoch 2 mission

Epoch 2 must finish the **fundamental Android adaptation research** needed before Epoch 3 chooses and assembles the Astral-like structure.

> Epoch 2 determines what an Android/Bionic standalone CPython must do, what Android changes require, and which implementation choices are valid. Epoch 3 determines how to organize the selected choices into an Astral-like producer and artifact family.

## Epoch 2 is not a surface-shape phase

Epoch 2 must not spend its remaining scope making the current producer look more like `python-build-standalone` merely through:

- directory renaming;
- `full`/`install_only` naming without matching content authority;
- premature Astral-style build profiles;
- release metadata designed for a public catalog;
- repository extraction or promotion.

These actions would create shape before the Android-specific decisions are complete.

## Revised phase sequence

```text
E2-P3A  finish existing archive-qualification authority
        - termux-real already frozen
        - termux-emulator remains
        - combined result closes only this contract

E2-P4   core-versus-profile boundary experiments

E2-P5   relocatability and development-SDK experiments

E2-P6   dependency, linkage, extension, and libpython experiments

E2-P7   build-host, NDK, sysconfig, wheel, PGO/LTO feasibility

E2-P8   cross-context differential qualification

E2-P9   evidence synthesis, decision inputs, and Epoch 2 closure
```

The numbering is conceptual; the repository may choose different exact identifiers. The boundaries, not the labels, are authoritative.

## Scope principle

Every remaining Epoch 2 task must answer at least one of these questions:

1. Does Android/Bionic force a change from the Astral reference model?
2. Which alternative is technically valid on Android?
3. Which behavior belongs to the core and which belongs to a Termux/adb/root profile?
4. What evidence must an Epoch 3 implementation reproduce?
5. What decision can be deferred until Epoch 3 without requiring a new experiment?

If a task answers none of these, it is outside Epoch 2.

## Relationship to the ABCD model

```text
A  Astral behavior or structure that can be preserved
B  existing responsibility requiring Android implementation changes
C  Android-only infrastructure or authority
D  later consumer and delivery additions
```

Epoch 2 primarily produces evidence for classifying A/B/C. It may retain limited D2/D3 qualification as evidence, but it does not build the final delivery system. APK remains D4 and deferred.

## Confirmed exit product

Epoch 2 closes with:

```text
producer-independent qualification contracts
Android adaptation evidence
alternative-topology experiment results
machine-readable baselines
explicit unresolved decision inputs
an Epoch 3 charter input package
```

It does not close with a public release candidate.
