# Cross-Context and Consumer Qualification


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Goal

Prove which behavior belongs to the Android/Bionic core and which behavior is supplied by an execution profile. This is evidence work, not final integration work.

## Context hierarchy

### Termux real device

Primary full qualification environment because it represents the intended interactive CLI workload.

Already frozen at the reviewed commit:

```text
35/35 qualification
19/19 result verification
38/38 independent review
```

### Termux emulator

Complete the existing E2-P3 contract against the same immutable envelope. Its purpose is reproducible environment coverage and harness portability, not a separate product flavor.

### adb shell

Run a differential investigation:

- direct startup from a suitable path;
- core imports and ELF closure;
- prefix identity and relocation;
- subprocess behavior;
- absent or different CA/timezone/home/temp behavior;
- exact explanation for each difference from Termux.

A failure in a profile-owned service does not invalidate the core if the boundary is explicit.

### root shell

Use only for questions that cannot be resolved under adb shell, such as UID policy, executable storage, linker namespace, or ownership. Do not duplicate the complete Termux matrix without a distinct hypothesis.

### APK

Deferred to Priority 4. No APK product qualification belongs to Epoch 2. A minimal JNI/libpython probe is allowed only as an input to a fundamental linkage decision.

## Consumer qualification

The laboratory retains bounded qualification for:

```text
pip
venv
uv explicit interpreter
uv venv
uv run
uv sync
local custom-catalog feasibility
```

It must stop before:

```text
upstream uv catalog integration
automatic downloads
default managed root
network publication
global shell exposure
production update policy
```

uv needs a discoverable Python environment for environment and source-build operations; the clean product repository will own the final integration. See [uv environment documentation](https://github.com/astral-sh/uv/blob/main/docs/pip/environments.md).

## Evidence format

Each context result must distinguish:

```text
core capability
profile capability
host-provided data
unsupported operation
unexpected regression
```

## Epoch 2 conclusion target

Freeze a compatibility matrix that Epoch 3 can use to define:

- core runtime contract;
- `termux-cli` profile;
- `android-shell` profile;
- optional `root-shell` profile;
- explicitly unqualified `embedded-app` profile.
