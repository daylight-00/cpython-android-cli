# Android Adaptation Evidence Agenda


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Purpose

Epoch 2 must identify every material place where Android/Bionic differs from the Unix platforms already handled by the Astral reference model. Each difference must be classified as preserved behavior, Android adaptation, Android-only infrastructure, or downstream profile behavior.

## Evidence domains

### Platform and ABI

- target triple versus Android ABI versus minimum API;
- Bionic API availability and symbol floors;
- public NDK libraries versus forbidden platform-private libraries;
- page-size and ELF alignment requirements;
- dynamic-linker behavior, SONAME, RUNPATH, and namespace restrictions.

Android's NDK exposes stable public libraries such as `libc`, `libm`, and `libdl`; unlike conventional Linux it does not have separate `libpthread` or `librt` libraries. See [Android NDK Native APIs](https://developer.android.com/ndk/guides/stable_apis).

### CPython Android behavior

- upstream Android source and packaging assumptions;
- `sys.getandroidapilevel()`, `SOABI`, `MULTIARCH`, sysconfig platform, and Android wheel tags;
- official package dependency and `libpython` topology;
- CLI behaviors not covered by the official embedding-oriented documentation.

CPython's official Android model is embedding-focused, while this project is deliberately researching a CLI standalone contract. See [Using Python on Android](https://docs.python.org/3.14/using/android.html).

### Build system

- build Python versus target Python;
- configure cache answers that are Android facts rather than historical workarounds;
- NDK compiler, linker, archiver, strip, and sysroot identity;
- stock NDK versus custom/ephemeral overlays;
- Linux cross-producer versus Termux-native producer.

### Runtime environment

- executable storage and UID permissions;
- `/proc/self/exe` reliability;
- `HOME`, `TMPDIR`, shell, CA, timezone, terminfo, and terminal behavior;
- Termux, adb shell, and root context differences.

### Packaging ecosystem

- Android platform tag `android_<api>_<abi>`;
- extension suffixes and wheel installation;
- source-build compiler metadata;
- external native dependencies in wheels;
- libpython linkage expectations.

The PyPA Android platform tag uses the `android_apilevel_abi` scheme. See [Platform Compatibility Tags](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/#android).

## Required output for each issue

Every experiment must produce:

```text
question
reference behavior
Android-specific hypothesis
exact inputs
alternative implementations
static evidence
target evidence
negative evidence
mutation controls
conclusion
claim boundary
Epoch 3 implication
```

## Completion standard

An Android adaptation question is complete only when Epoch 3 can either:

1. select one implementation without another target experiment; or
2. explicitly defer a non-fundamental choice while preserving all valid options.
