# Clean Product Repository Boundary


> **Documentation status:** Proposed research-boundary authority for review  
> **Repository reviewed:** [`daylight-00/cpython-android-cli` at `c05cf9b608b69903aabaf42047cfa921276a6069`](https://github.com/daylight-00/cpython-android-cli/commit/c05cf9b608b69903aabaf42047cfa921276a6069)  
> **Purpose:** Define the laboratory scope that prepares an Astral-like Android/Bionic standalone CPython implementation without treating this repository as the final release repository.


## Purpose

The clean repository begins only after Epoch 3 freezes a complete product seed. It is not created to continue unresolved research.

## Imported seed

```text
product-seed/
├── selected producer implementation
├── target and dependency definitions
├── required patches
├── artifact schemas and contracts
├── qualification harness subset
├── accepted reference fixtures
├── license and provenance inventories
├── LAB-AUTHORITY.json
└── SHA256SUMS
```

`LAB-AUTHORITY.json` must bind the import to:

- research repository URL;
- Epoch 3 freeze commit;
- producer authority hash;
- qualification authority hash;
- seed-tree hash;
- supported contract versions.

## Clean repository responsibilities

```text
maintainable source layout
CI and supported host matrix
public release automation
release signing and attestations
artifact hosting and channels
consumer-facing documentation
uv integration or metadata contribution
user-facing installation and updates
issue and security policy
long-term version support
```

## Prohibited leakage from the laboratory

The clean repository should not carry:

- superseded experiments;
- result archives not needed for regression;
- historical lifecycle implementations that are not selected;
- private authority storage paths;
- project-specific Drive operations;
- mutable laboratory staging paths;
- ambiguous shared ownership of schemas.

## Contract ownership

The clean repository should become the owner of production contract evolution after import. The laboratory preserves the frozen origin and may run new research branches, but production changes require explicit contract versions and backward-compatibility policy.

## Release readiness

Only the clean repository decides:

```text
selectable
publishable
stable
supported
```

The laboratory can state `technically qualified` or `research-frozen`; it cannot authorize public release status.

## APK boundary

APK integration remains a later consumer project. It may consume the final core or a derivative artifact, but it must not retroactively redefine the initial standalone CLI producer.
