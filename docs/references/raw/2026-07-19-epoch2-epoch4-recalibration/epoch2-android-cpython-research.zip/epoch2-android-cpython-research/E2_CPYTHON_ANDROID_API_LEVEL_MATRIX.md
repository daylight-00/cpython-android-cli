# CPython 3.14/3.15 Across Android API Levels 24 and 29–36

> **Status:** source-verified research conclusion  
> **Verified:** 2026-07-18  
> **CPython baselines:** 3.14.6 and 3.15.0b3  
> **Purpose:** identify Android API-floor changes that can materially affect a standalone CPython distribution  
> **Non-purpose:** select or freeze a future release policy

## 1. Executive conclusion

The upstream-derived CPython 3.14.6 product remains correctly anchored to API 24,
because API 24 is the minimum selected by the official CPython Android producer.

Raising the compile-time API floor does not create a uniform performance improvement.
The source audit identifies three thresholds with the strongest practical relevance:

- **API 29:** native ELF TLS instead of compiler emulated TLS;
- **API 31:** pidfd availability, with a new timed-subprocess-wait path in Python 3.15;
- **API 34:** `close_range()` and `copy_file_range()` become build-visible.

API 36 is useful as a modern experimental ceiling. It is not currently supported
as a generally faster or better release target.

## 2. Summary matrix

| Compile-time floor | CPython 3.14 | CPython 3.15 | Research conclusion |
|---:|---|---|---|
| 24 | Official upstream baseline | Valid compatibility baseline | Preserve as the upstream-faithful control |
| 29 | Native ELF TLS | Native ELF TLS | Strongest candidate for a broad low-level runtime change |
| 30 | `sem_clockwait()` available | Same | Timed-lock robustness; RELR requires separate linker policy |
| 31 | `os.pidfd_open()` may be exposed | `Popen.wait(timeout)` may use pidfd + poll | Targeted subprocess improvement in 3.15 |
| 32 | No distinct relevant threshold found | Same | Do not maintain a separate profile |
| 33 | Bionic gains `backtrace*`; CPython still lacks `dladdr1()` | Same | Does not enable CPython's full non-Apple C-stack path |
| 34 | `close_range()` and `copy_file_range()` visible | Same | Targeted subprocess and file-copy improvement |
| 35 | No identified broad CPython use | Same | No confirmed broad benefit |
| 36 | No identified broad CPython use | Same | Experimental ceiling, not a proven optimization target |

## 3. Three boundaries that must not be confused

### 3.1 Compile-time Android API floor

The NDK compiler target controls:

- which Bionic declarations are visible;
- which compatibility stubs are selected;
- some compiler code-generation choices;
- the minimum Android release on which the binary may run.

### 3.2 Runtime Android release

A binary compiled for API 24 can run on a newer Android device and use the newer
dynamic linker, libc implementation, and platform fixes that do not require linking
against newer symbols.

### 3.3 Runtime Linux kernel

Wrappers such as `pidfd_open`, `close_range`, and `copy_file_range` ultimately
depend on kernel support. A symbol being visible at build time does not guarantee
that every target kernel or security policy will permit it.

Every comparison must therefore record:

- compiler API floor;
- NDK version;
- Android release and Bionic version;
- kernel version;
- device or emulator identity;
- relevant security restrictions.

## 4. API 24: upstream compatibility control

### Verified facts

The frozen project product is:

- CPython 3.14.6;
- `aarch64-linux-android`;
- Android API 24;
- NDK 27.3.13750724;
- an official upstream CPython Android package.

Python 3.14 is the first release series with official python.org Android binary
packages. The package is primarily described as an application-embedding input,
with a `prefix` containing shared `libpython`, the standard library, native extension
modules, and external native libraries.

### Conclusion

API 24 is important because it is the upstream-selected compatibility floor.
It must remain the control even when modern-floor source builds are tested.

## 5. API 29: native ELF TLS

### Verified facts

Android supports ELF TLS from API 29. With modern NDKs, a minimum API of 29 or
higher allows Clang to emit native ELF TLS. Lower targets use compiler emulated TLS,
which is backed by helper logic and pthread-key storage.

CPython uses language TLS for core thread-local state when the compiler supports it.

### Expected effect

Native ELF TLS can replace the emulated helper path with direct TLS access. This is
the clearest API-floor change that may affect frequently executed interpreter state
access rather than one isolated library feature.

### Limit

The code-generation difference is verified. A meaningful end-to-end Python speedup
must still be measured.

### Conclusion

API 29 is the most informative intermediate performance experiment. It is more useful
than building every API number between 24 and 36.

## 6. API 30: monotonic semaphore waits and optional RELR

### Verified facts

Bionic provides `sem_clockwait()` at API 30. When CPython detects it, timed semaphore
waits can use an absolute `CLOCK_MONOTONIC` deadline. Without it, the fallback uses
`sem_timedwait()` and wall-clock-based calculations.

Android 11 also establishes the platform era in which standardized RELR relocations
are available. RELR is not enabled merely by changing the API floor; the linker flags
and resulting ELF must be inspected.

### Expected effect

- better resilience to wall-clock changes during timed waits;
- less deadline recomputation after interruption;
- possible relocation-table size and load-time effects only when RELR is explicitly enabled.

### Conclusion

API 30 is a correctness and packaging research point, not a separate long-term product
profile by default.

## 7. API 31: pidfd and Python 3.15

### Verified facts

Bionic exposes `pidfd_open()` from API 31.

Python 3.15 changes `subprocess.Popen.wait(timeout=...)` on supported Linux systems:
it can first try `pidfd_open()` plus `poll()`, then fall back to the traditional
`waitpid(WNOHANG)` sleep loop when pidfd is unavailable or blocked.

Python 3.14 does not contain this new timed-wait behavior.

### Expected effect

For Python 3.15, timed subprocess waits can become event-driven rather than repeatedly
polling and sleeping. This matters for process-heavy CLI tools, environment managers,
and orchestration workloads.

### Limit

It does not accelerate normal bytecode execution. Kernel version and security policy
remain part of the result.

### Conclusion

API 31 is a real Python-3.15-specific threshold and should be covered by the API-36
behavioral test matrix.

## 8. API 32: no separate project-relevant threshold

No Bionic addition at API 32 was identified that creates a distinct CPython 3.14 or
3.15 code path material to this project.

### Conclusion

Do not create an API-32 artifact merely because it lies between other thresholds.

## 9. API 33: partial backtrace availability

### Verified facts

Bionic adds `backtrace`, `backtrace_symbols`, and `backtrace_symbols_fd` at API 33.

CPython's non-Apple native C-stack implementation also requires `dladdr1()`.
Android provides `dladdr()`, but not the glibc-specific `dladdr1()` interface used by
that CPython path.

### Conclusion

API 33 alone does not enable CPython's complete native C-stack dump path. A custom
Android diagnostic adaptation would be project-owned work and requires its own research
question.

## 10. API 34: `close_range()` and `copy_file_range()`

### Verified facts

Bionic exposes `close_range()` and `copy_file_range()` at API 34.

CPython's POSIX subprocess implementation uses `close_range()` when detected, with
fallback logic when it is absent or fails. CPython also exposes `os.copy_file_range()`
when detected.

### Expected effect

- faster or simpler child-process file-descriptor cleanup, especially with many open FDs;
- in-kernel copying for callers that use `os.copy_file_range()`;
- continued fallback when the kernel or filesystem cannot satisfy the operation.

### Conclusion

API 34 is the strongest targeted threshold after API 29 and is directly relevant to
CLI-oriented Python workloads.

## 11. API 35 and API 36

Bionic adds additional interfaces at API 35 and 36, but the audited CPython 3.14.6 and
3.15.0b3 sources did not reveal a broad interpreter path that gains a general runtime
advantage from those additions.

Some APIs may expand a small `os` or diagnostic surface. That is different from a
general interpreter optimization.

### Conclusion

API 36 is justified as an Epoch 2 experimental profile because it:

- tests the newest platform surface;
- reveals modern Android adaptation problems early;
- provides an upper-bound comparison against the upstream artifact.

It is not presently justified as the main distribution floor.

## 12. Required Epoch 2 comparison

| Variant | CPython | Launcher | Dependencies | Purpose |
|---|---:|---:|---:|---|
| A — upstream control | official API 24 | API 24-compatible | upstream API 21/24 mixture | exact product-faithful reference |
| B — minimal modern floor | API 36 | API 36 | unchanged upstream binaries | isolate CPython and launcher effects |
| C — all API 36 | API 36 | API 36 | rebuilt at API 36 | test dependency-floor unification only if B leaves a question |

Variant C should not be automatic.

All variants should run the same tests:

- startup and command-line behavior;
- relocation;
- ELF closure and unresolved dependencies;
- isolated extension imports;
- HTTPS and certificate discovery;
- venv and offline pip;
- uv with an explicit interpreter;
- subprocess creation and timed waits;
- high-file-descriptor child setup;
- file copying;
- archive size and installed size.

Measurements must include source delta, patch count, warnings, device/kernel identity,
and the effort required to repeat the build.

## 13. Final decision for Epoch 2

The main policy remains upstream-faithful.

API 36 belongs in Epoch 2 as a bounded comparative experiment. The result should be
retained only long enough to decide whether the modern floor provides enough benefit
to justify any continuing local ownership.

## References

### Android and Bionic

- https://android.googlesource.com/platform/bionic/+/HEAD/android-changes-for-ndk-developers.md#elf-tls-available-for-api-level-29
- https://android.googlesource.com/platform/bionic/+/HEAD/docs/elf-tls.md
- https://android.googlesource.com/platform/bionic/+/HEAD/docs/status.md
- https://developer.android.com/about/versions/10/features#elf-tls

### CPython 3.14

- https://github.com/python/cpython/blob/v3.14.6/Include/pyport.h
- https://github.com/python/cpython/blob/v3.14.6/Python/thread_pthread.h
- https://github.com/python/cpython/blob/v3.14.6/Modules/_posixsubprocess.c
- https://github.com/python/cpython/blob/v3.14.6/Modules/posixmodule.c
- https://github.com/python/cpython/blob/v3.14.6/Python/traceback.c
- https://docs.python.org/3.14/using/android.html
- https://docs.python.org/3.14/whatsnew/3.14.html#build-changes

### CPython 3.15

- https://docs.python.org/3.15/whatsnew/3.15.html#subprocess
- https://github.com/python/cpython/blob/v3.15.0b3/Lib/subprocess.py
