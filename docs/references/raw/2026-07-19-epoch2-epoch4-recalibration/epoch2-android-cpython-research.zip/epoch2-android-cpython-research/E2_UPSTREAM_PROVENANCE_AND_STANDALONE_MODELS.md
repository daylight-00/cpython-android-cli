# Upstream Provenance and Standalone Distribution Models

> **Status:** source-verified research conclusion  
> **Verified:** 2026-07-18  
> **Scope:** CPython/Python.org, BeeWare Android dependency artifacts, this project, Astral `python-build-standalone`, and uv

## 1. Executive conclusion

This project has a recognized Android runtime upstream:

```text
CPython/Python.org Android package
  -> built with BeeWare-produced Android dependency archives
  -> consumed by this project
  -> minimally adapted into a relocatable command-line distribution
```

The future main distribution should preserve this chain.

The project should normally own:

- the standalone launcher;
- Android and Termux runtime adaptation;
- relocation;
- archive construction and metadata;
- qualification;
- uv-facing consumer integration;
- provenance for the small local delta.

It should normally delegate:

- CPython Android source policy;
- CPython Android patches;
- dependency versions and recipes;
- NDK and minimum-API selection;
- upstream security maintenance.

Astral is the correct reference for **standalone distribution form**, but it is not
the Android binary upstream for this project.

## 2. Official CPython Android package

Python 3.14 provides official Android binary packages through the CPython release
process.

The official package is embedding-oriented. Its top-level prefix contains the material
required for an Android application to load Python, including:

- shared `libpython`;
- the standard library;
- native extension modules;
- external native libraries used by extensions.

“Embedding-oriented” describes the expected entry model. It does not mean the package
is dependency-free, source-only, or incapable of supporting a command-line launcher.

### Frozen product used by the project

| Field | Value |
|---|---|
| Product kind | `upstream-cpython-android-package` |
| CPython | 3.14.6 |
| Target | `aarch64-linux-android` |
| Android API | 24 |
| NDK | 27.3.13750724 |
| Archive | `python-3.14.6-aarch64-linux-android.tar.gz` |
| SHA-256 | `517f4b0d113c4c1cf6931c230b6b517bee7a2b7f8b4f0f099a148260fa3ac8e7` |

### Conclusion

The official package is the correct control and primary input for the future main
distribution. The missing layer is a standalone CLI and distribution contract, not a
replacement CPython producer.

## 3. BeeWare dependency producer

The CPython Android producer downloads prebuilt dependency archives from BeeWare's
`cpython-android-source-deps` releases.

“Prebuilt” means that CPython receives already compiled Android prefix archives.
BeeWare still begins from source:

```text
upstream dependency source
  -> BeeWare recipe and Android-specific patches
  -> NDK compilation
  -> installed prefix
  -> release archive
  -> CPython Android build input
```

The BeeWare OpenSSL recipe, for example:

- downloads an OpenSSL source release;
- applies Android-specific patches;
- selects an Android configuration;
- builds the native libraries;
- installs a prefix for packaging.

The same producer model applies to the other dependency archives.

## 4. Frozen dependency products and API policy

The dependency set recorded by the project is:

| Dependency | Version/revision | Recipe API policy |
|---|---|---:|
| bzip2 | 1.0.8-3 | common API 21 |
| libffi | 3.4.4-3 | common API 21 |
| OpenSSL | 3.5.7-0 | common API 21 |
| SQLite | 3.50.4-0 | common API 21 |
| xz | 5.4.6-1 | common API 21 |
| zstd | 1.5.7-2 | explicit API 24 |

The BeeWare common Android environment defaults to API 21. The zstd recipe overrides
the level to API 24, aligning it with Python 3.14's Android minimum and its relevant
32-bit API requirements.

CPython and the project launcher are API 24, so the complete product floor is API 24.

### Conclusion

The API-21/API-24 mixture is an upstream producer result. It is not a local project
policy that needs to be normalized for the primary distribution.

A dependency compiled with a lower minimum remains usable in an API-24 process. Its
lower floor does not lower the minimum of the complete product.

## 5. Practical decision authority

| Decision | Practical authority |
|---|---|
| Official CPython Android package | CPython project / Python.org release process |
| CPython Android minimum floor | CPython project |
| Dependency source recipes and Android patches | BeeWare |
| Common dependency API floor | BeeWare |
| zstd API-24 override | BeeWare recipe aligned with CPython 3.14 |
| Final package composition | CPython project |
| Standalone CLI behavior | This project |
| Android host adaptation and qualification | This project |
| Future managed-Python integration | This project and the consuming tool |

A precise formulation is:

> The CPython project is the final authority for the official Android package.
> It adopts dependency products whose detailed Android build policies are maintained
> by BeeWare. This project inherits that combination and owns only the downstream
> standalone adaptation.

## 6. Product consumption and producer reconstruction

The current repository has explored two paths:

### 6.1 Product-consumption path

```text
official completed package
  -> verify identity and digest
  -> extract prefix
  -> add minimum standalone adaptation
  -> qualify final archive
```

This is the preferred future main path.

### 6.2 Producer-reconstruction path

```text
CPython source and Android producer
  + exact BeeWare dependency products
  + Android NDK
  -> reconstructed Android prefix
  -> comparison and fallback evidence
```

This path was valuable for understanding provenance, API decisions, build feasibility,
and failure boundaries.

### Conclusion

The two paths serve different purposes. Reconstructing the producer should remain
experimental evidence and a fallback capability. It should not become a mandatory
step for every upstream patch release.

## 7. Astral `python-build-standalone`

Astral's producer is structurally different.

`python-build-standalone`:

- constructs controlled build environments and toolchains;
- builds CPython dependencies from source;
- builds CPython;
- controls extension build and linking policy;
- applies target-specific patches and optimization profiles;
- emits self-contained distribution archives;
- records machine-readable metadata for downstream consumers.

Astral therefore owns decisions that this Android project can mostly delegate upstream:

- compiler and toolchain policy;
- dependency versions;
- dependency source builds;
- CPython patches;
- extension linking;
- PGO and LTO;
- platform archive variants.

Astral's archive model is still highly relevant:

- canonical archive root;
- install-only distribution variants;
- machine-readable interpreter metadata;
- explicit executable and library paths;
- downstream-consumer orientation;
- deterministic validation.

### Conclusion

Astral is:

- a downstream CPython source builder;
- an upstream standalone binary producer;
- the binary-distribution upstream used by uv for its supported managed-Python matrix.

For this project, Astral is the product-form reference, not the Android binary provider.

## 8. uv relationship

The managed-Python flow for uv is approximately:

```text
CPython and dependency source projects
  -> Astral python-build-standalone
  -> uv managed-Python catalog and installation
```

For uv, Astral is the binary upstream. For Astral, CPython and each dependency project
are source upstreams.

The intended Android flow can be thinner:

```text
CPython/Python.org Android package
  -> this project's standalone adaptation
  -> future uv-compatible catalog or discovery integration
```

The final uv integration should not be designed until Epoch 2 has determined the
required target identity, archive shape, relocation behavior, checksums, executable
path, and platform metadata.

## 9. Responsibility comparison

| Responsibility | Astral | Recommended Android main path |
|---|---|---|
| CPython source build | Owned | Delegated to official CPython Android producer |
| Dependency source builds | Owned | Delegated to BeeWare/CPython chain |
| Toolchain and API floor | Owned | Inherited from upstream |
| Standalone executable | Produced by Astral | Added by this project |
| Relocation | Producer-owned | Project-owned Android adaptation |
| Archive and metadata | Producer-owned | Project-owned, informed by Astral |
| Validation | Producer-owned | Project-owned |
| uv integration | Consumed by uv | Future integration target |

### Conclusion

This project can provide an Astral-like distribution while remaining much thinner than
Astral's producer.

## 10. Main and experimental policies

### Main upstream-faithful path

- consume the official CPython Android package;
- verify the release identity and checksum;
- preserve upstream CPython and dependency choices;
- apply only demonstrated standalone adaptations;
- qualify relocation, native closure, HTTPS, venv, pip, subprocess, and uv workflows;
- record every project-owned mutation.

The current API 24 floor is an upstream result. It is not an eternal project identity.

### API-36 Epoch 2 experiment

The experiment may test:

1. CPython and the launcher rebuilt at API 36 while reusing upstream dependency binaries;
2. all native components rebuilt at API 36 from upstream sources and BeeWare recipes.

The second variant should proceed only if the first leaves a concrete technical question.

## 11. Delegation principle

The project's maintenance strategy should be:

> Trust and verify recognized upstream production, then own only the Android standalone
> delta that upstream does not provide.

This minimizes:

- source maintenance;
- dependency security responsibility;
- NDK transition work;
- repeated patch adaptation;
- unnecessary parallel release policy.

## 12. Final Epoch 2 conclusion

The project's strongest property is the existence of a recognized upstream Android
production chain.

The main product should be an **upstream-derived standalone adaptation**.

Astral defines the reference distribution form. CPython/Python.org and BeeWare define
the Android runtime production policy. API 36 remains a bounded experiment so modern
Android behavior can be studied without transferring permanent producer ownership to
this project.

## References

### CPython / Python.org

- https://docs.python.org/3.14/using/android.html
- https://docs.python.org/3.14/whatsnew/3.14.html#build-changes
- https://github.com/python/cpython/blob/main/Platforms/Android/__main__.py

### BeeWare

- https://github.com/beeware/cpython-android-source-deps
- https://github.com/beeware/cpython-android-source-deps/blob/main/android-env.sh
- https://github.com/beeware/cpython-android-source-deps/blob/main/zstd/build.sh
- https://github.com/beeware/cpython-android-source-deps/blob/main/openssl/build.sh
- https://github.com/beeware/cpython-android-source-deps/releases

### Astral and uv

- https://github.com/astral-sh/python-build-standalone
- https://github.com/astral-sh/python-build-standalone/blob/main/docs/technotes.rst
- https://github.com/astral-sh/python-build-standalone/blob/main/docs/distributions.rst
- https://docs.astral.sh/uv/concepts/python-versions/
