# Epoch 2 Android CPython Research Documentation

> **Prepared:** 2026-07-18  
> **Scope:** independently reviewable research conclusions for Epoch 2  
> **Authority:** research guidance only; this set does not design Epoch 3 or authorize a release

This archive contains three standalone English Markdown documents.

## Reading order

1. [`E2_CPYTHON_ANDROID_API_LEVEL_MATRIX.md`](E2_CPYTHON_ANDROID_API_LEVEL_MATRIX.md)
   - CPython 3.14 and 3.15 behavior across Android API 24 and API 29–36.
   - Separates compile-time API floor, runtime Android release, and runtime kernel.
   - Defines the bounded API-36 comparison.

2. [`E2_UPSTREAM_PROVENANCE_AND_STANDALONE_MODELS.md`](E2_UPSTREAM_PROVENANCE_AND_STANDALONE_MODELS.md)
   - Separates CPython/Python.org, BeeWare, this project, Astral, and uv responsibilities.
   - Documents the source-to-prebuilt dependency chain.
   - Explains why the main distribution should remain upstream-derived.

3. [`E2_RESEARCH_SCOPE_AND_DIRECTION.md`](E2_RESEARCH_SCOPE_AND_DIRECTION.md)
   - Reviews the current repository as an experiment and evidence incubator.
   - Identifies completed questions, work to pause, and fundamental experiments still required.
   - Keeps the project focused on Epoch 2 Android adaptation research.

## Shared conclusion

The future main distribution should be an **upstream-derived, Astral-like standalone
adaptation for Android/Bionic**.

The current repository should remain an evidence-bearing research environment.
Its priority is to finish the Android-specific questions that must be answered
before a later clean release repository can be designed.

The official upstream API-24 product remains the control. API 36 remains a bounded
Epoch 2 experiment rather than a release policy.
