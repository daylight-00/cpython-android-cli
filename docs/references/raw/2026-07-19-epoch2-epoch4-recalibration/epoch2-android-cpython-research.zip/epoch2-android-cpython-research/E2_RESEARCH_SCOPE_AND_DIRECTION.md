# Epoch 2 Research Scope Review and Direction

> **Status:** independently reviewed research conclusion  
> **Verified:** 2026-07-18  
> **Scope:** the current repository as an experiment and evidence incubator  
> **Explicit exclusion:** this document does not design Epoch 3 or the future clean release repository

## 1. Correct interpretation of the repository

The current repository is not the final distribution repository.

It is an evidence-bearing research environment whose results will later inform a clean
repository for an Astral-like Android standalone CPython distribution.

Therefore, the presence of:

- failed approaches;
- detailed provenance;
- source reconstruction;
- temporary contracts;
- comparison builds;
- experimental scripts;
- machine-readable evidence;

is not itself a problem.

The correct review question is:

> Does each experiment reduce a real uncertainty about Android standalone CPython or
> determine a future product boundary?

An experiment becomes self-serving when its main result is only a stronger restatement
of an already accepted result, without changing an Android adaptation decision.

## 2. Epoch 2 mission

Epoch 2 should finish the fundamental Android adaptation research required before a
later clean distribution can be designed.

It should produce evidence for:

- converting the official embedding-oriented prefix into a normal CLI;
- launcher and loader behavior;
- relocation;
- Bionic-native dependency closure;
- host-provided certificates, timezone data, temporary storage, and writable state;
- subprocess behavior;
- venv, pip, and uv workflows;
- native-extension development capability;
- upstream artifact consumption;
- update portability;
- Python 3.15 adaptation;
- the practical value of higher Android API floors;
- minimum-floor and modern-device compatibility;
- 16 KB page-size compatibility;
- licensing and source provenance;
- consumer requirements for later managed-Python integration.

Epoch 2 should not finalize:

- the permanent release repository;
- the final public catalog;
- a long-term installer architecture;
- release governance;
- Epoch 3 structure.

## 3. What the project has already achieved

### 3.1 Standalone launcher architecture

The project established a concrete launcher model that:

- locates the real executable through `/proc/self/exe`;
- derives the installation prefix;
- derives the private native-library directory;
- normalizes `LD_LIBRARY_PATH`;
- discovers or preserves a CA bundle;
- re-executes once when loader state must be repaired;
- initializes CPython through `PyConfig`;
- preserves normal arguments and `Py_RunMain` behavior.

This is essential Android product research. The official embedding package does not
provide this standalone CLI contract.

### 3.2 Whole-prefix relocation

The project demonstrated that the runtime can move between unrelated paths while
retaining its runtime identity and behavior.

It also learned to distinguish:

- legitimate relocation;
- mutation of the product under test;
- symlink-aware runtime paths;
- lexical containment requirements.

This is directly relevant to install-only and managed-Python distributions.

### 3.3 Native dependency closure

The project:

- inventoried ELF objects;
- classified internal and Android-system dependencies;
- rejected unresolved dependency edges;
- checked isolated native-extension imports;
- verified that the tested runtime has no Termux-native ELF dependency.

This establishes a central architectural claim:

> Termux is the primary interactive shell profile, not the binary ABI provider.

Exact object counts are useful observations for a frozen product. They should not become
permanent cross-version invariants.

### 3.4 Host-data boundaries

The project separated the relocatable core from host-provided data and writable state:

- certificate trust;
- timezone database;
- temporary directories;
- home directory;
- caches;
- terminal and shell behavior.

This boundary is required for a core that may run from Termux, adb, root, or an
application-private environment.

### 3.5 Upstream producer understanding

The project reconstructed and audited:

- the official CPython Android producer;
- BeeWare dependency artifacts;
- API and NDK policy;
- exact dependency provenance;
- a bounded Termux-native source build;
- the boundary between upstream production and local adaptation.

This work answered a real question.

The answer is now substantially known. Full producer reconstruction should not be
repeated for every patch release unless a new question requires it.

### 3.6 Artifact and consumer boundaries

Epoch 1 and early Epoch 2 established:

- runtime and development payload concepts;
- archive boundaries;
- ownership;
- acquisition and transition concepts;
- a stable build/package/verify façade;
- archive-only qualification.

These results should now support research rather than continuously expanding into more
formal layers.

## 4. Current E2-P3 state

The accepted real-Termux archive-only qualification used the frozen product envelope
without rebuilding or repackaging it.

Recorded result:

| Item | Result |
|---|---:|
| Target profile | real Android / Termux / aarch64 |
| Device Android API | 36 |
| Qualification | 35/35 |
| Result verification | 19/19 |
| Independent review | 38/38 |
| Product mutation | none |
| Selectable release | no |

The result covers behavior including:

- relocation;
- interpreter identity;
- native closure;
- extension imports;
- HTTPS;
- venv;
- offline pip;
- explicit-interpreter uv workflows;
- Android wheel tags;
- product fidelity.

This is not an experiment for its own sake. It validates the archive boundary that a
future clean distribution will consume.

The remaining bounded E2-P3 work is the separate emulator profile and combined
qualification closure. It should use the same frozen envelope and must not reopen the
producer or accepted real-device result.

## 5. Work that should pause

The repository already demonstrates that a detailed provenance and authority chain can
be constructed.

Do not make the default next action another layer of:

- a contract over an already frozen contract;
- a binding over an already frozen binding;
- exact Git-blob restatement of an accepted commit;
- new metadata schemas without a demonstrated consumer;
- repeated producer reconstruction for each patch release;
- exact ELF counts treated as eternal product identity;
- complete installer transition expansion before consumer requirements are known;
- release publication mechanics before research inputs are stable.

These artifacts can remain as historical evidence. The recommendation is to stop
expanding them by default.

## 6. Fundamental Epoch 2 experiments that should continue

### 6.1 Direct adaptation of the official upstream artifact

Prove the thinnest intended main path:

```text
verified python.org Android package
  -> extract official prefix
  -> overlay minimum standalone launcher
  -> normalize only demonstrated Android boundaries
  -> run the same essential qualification
```

Compare it with the reconstructed producer result.

**Decision:** whether a local CPython source build is required for the main path.

**Stop condition:** the direct upstream artifact passes the required standalone tests
and every local mutation is enumerated and justified.

### 6.2 Upstream patch-update rehearsal

Perform one controlled update to another official CPython Android patch release by
changing primarily:

- version;
- upstream locator;
- checksum;
- expected upstream metadata.

The goal is to reveal hidden assumptions in:

- launcher paths;
- package filtering;
- sysconfig;
- metadata generation;
- extension enumeration;
- qualification.

**Stop condition:** the update requires only bounded configuration changes, or every
code change has a documented Android reason.

### 6.3 Python 3.15 preview adaptation

Use Python 3.15 as a research input, not a stable product.

Investigate:

- launcher compatibility;
- standard-library and extension-surface changes;
- path assumptions tied to 3.14;
- sysconfig changes;
- pidfd-based timed subprocess waits;
- differences in official Android packaging when available.

**Stop condition:** a concise 3.14-to-3.15 delta report exists, with no release claim.

### 6.4 API-floor comparison, including API 36

Use three bounded variants:

| Variant | Purpose |
|---|---|
| official upstream control | preserve exact API-24 product behavior |
| CPython and launcher at API 36 | isolate modern-floor effects with minimum ownership |
| all components at API 36 | test dependency-floor unification only if a question remains |

Measure:

- behavior;
- startup;
- representative performance;
- TLS-sensitive paths;
- subprocess behavior;
- file-copy behavior;
- native closure;
- archive size;
- patch count;
- maintenance cost.

**Stop condition:** the evidence is sufficient to retain, archive, or discontinue the
modern-floor experiment.

### 6.5 Minimum-floor and modern-device qualification

A successful run on an API-36 device does not prove API-24 compatibility.

Distinguish:

- minimum claimed Android API;
- current real Termux device;
- modern emulator;
- modern Bionic and kernel behavior.

**Stop condition:** the compatibility claim has credible minimum-floor and modern
evidence, or the limitation is explicitly documented.

### 6.6 16 KB page-size compatibility

Verify the complete assembled runtime, not only linker flags.

Required checks:

- ELF load-segment alignment;
- execution in a 16 KB page-size environment;
- no unsafe hard-coded 4 KB assumptions in project code;
- unchanged extension imports;
- unchanged subprocess behavior.

**Stop condition:** the upstream-derived archive and project launcher run successfully,
or the exact incompatible component is identified.

### 6.7 Native-extension build capability

A development payload must demonstrate real value.

Test one minimal native extension for:

- header discovery;
- `libpython` and sysconfig metadata;
- compiler and linker policy;
- Android wheel tags;
- installation;
- import;
- relocation;
- clean rebuild.

Separately define whether the supported claim is:

- on-device build;
- cross-build;
- both;
- neither.

**Stop condition:** one controlled extension completes the full workflow, or the
unsupported boundary is explicit.

### 6.8 Shell and host-profile boundary

Termux-first must not silently become Termux-bound.

Retain Termux as the primary interactive profile, but probe at least one non-Termux
Android context where practical:

- adb shell;
- root shell;
- controlled application-private shell.

The purpose is not polished UX. It is to identify which assumptions belong to:

- the core;
- the launcher;
- the Termux profile;
- host certificates;
- home and temporary directories;
- terminal behavior.

**Stop condition:** evidence documents the core boundary across more than one host
profile, or a Termux-only limitation is explicit.

### 6.9 License and source-provenance evidence

The future distribution redistributes CPython and dependency binaries.

Epoch 2 should map every distributed component to:

- exact version;
- source project;
- source archive or tag;
- recipe revision;
- license identity;
- authoritative license text;
- source-offer requirement where applicable.

Final presentation belongs to the later clean repository. The source-of-truth mapping
belongs in Epoch 2.

**Stop condition:** every redistributed component has a complete mapping.

### 6.10 uv consumer requirements

Continue explicit-interpreter uv tests, but do not design the final integration yet.

Produce a requirements conclusion for:

- canonical target identity;
- archive root;
- executable path;
- relocation semantics;
- download URL and checksum;
- Python version;
- ABI and Android platform tag;
- installation and uninstall assumptions;
- update behavior;
- Android-specific discovery.

**Stop condition:** a later integration effort can state exactly what it must consume
without guessing.

## 7. Questions that should normally be considered answered

### Standalone launcher feasibility

Answered for the tested product. Reopen only for a specific failing behavior or version
change.

### Whole-prefix relocation

Answered for the tested product. Revalidate new upstream packages rather than redesigning
relocation without evidence.

### Termux-native ELF dependency

Answered for the frozen product. Keep the semantic verifier, not permanent exact counts.

### Official producer reconstruction

Substantially answered. Preserve it as fallback and API-floor research capability.

### Ability to construct a detailed authority chain

Answered. More layers require a concrete security, reproducibility, or consumer need.

### Full installer lifecycle

Already explored substantially in Epoch 1. Do not repeat it before the final artifact
input and uv consumer requirements are known.

## 8. Experiment admission rule

Every new Epoch 2 experiment must begin with:

```text
Question
What is not yet known?

Decision
What future choice changes based on the result?

Variants
What control and comparison builds are required?

Measurements
What evidence answers the question?

Stop condition
When is the question closed?
```

Reject or reduce a proposed experiment when its only decision is:

> create stronger authority for the same accepted result.

## 9. Evidence policy

Detailed evidence remains appropriate. The change is to connect rigor to a question.

Preferred evidence includes:

- exact upstream identities;
- checksums;
- reproducible commands;
- machine-readable results;
- positive and negative probes;
- before/after fingerprints when mutation matters;
- Android, kernel, NDK, device, and page-size identity;
- explicit local patches;
- comparison results;
- failed approaches that explain a selected decision.

Counts should generally be recorded as observations. Contracts should protect semantic
invariants such as:

- zero unresolved dependencies;
- zero unexpected Termux-native dependencies;
- zero failed required extension imports;
- no unintended product mutation.

## 10. Suggested remaining Epoch 2 sequence

This is a research sequence, not an Epoch 3 design:

1. complete the emulator profile and combined E2-P3 closure;
2. validate direct official-artifact adaptation;
3. perform one upstream patch-update rehearsal;
4. perform Python 3.15 preview adaptation;
5. run the minimal API-36 comparison;
6. run all-components API 36 only if required;
7. validate API-24 minimum-floor behavior;
8. validate a modern 16 KB environment;
9. prove one native-extension build;
10. test a non-Termux host profile;
11. complete dependency license and source mapping;
12. write the uv consumer-requirements conclusion;
13. close Epoch 2 with a research synthesis.

Structural release implementation should not displace these questions.

## 11. Epoch 2 completion criteria

Epoch 2 is complete when it can provide evidence-backed answers to:

- What exact upstream Android package is consumed?
- What project-owned mutations are unavoidable?
- How is the interpreter launched and relocated?
- What binary and host-data dependencies exist?
- What API floor is inherited?
- What do higher API floors actually change?
- Does the product work at the oldest claimed API?
- Does it work in modern 16 KB environments?
- Do subprocess, HTTPS, venv, pip, uv, and native-extension workflows work?
- Does the approach survive an upstream patch update?
- What changes for Python 3.15?
- Which source-build capabilities are fallback experiments rather than main policy?
- What must a later archive and consumer integration express?
- What licensing and source provenance must accompany the redistributed bytes?

Epoch 2 does not need to determine the final clean-repository structure or Epoch 3
governance.

## 12. Final conclusion

The project has not primarily been performing useless experiments.

Launcher, relocation, native closure, host boundaries, upstream provenance, source-build
feasibility, and archive qualification resolved real uncertainties.

The project is now at a transition point. The highest-value remaining work is
comparative and Android-specific:

- direct upstream consumption;
- update portability;
- Python 3.15;
- API 36;
- minimum-floor compatibility;
- 16 KB pages;
- native extensions;
- host-profile separation;
- license provenance;
- uv consumer requirements.

The principal adjustment is:

> Stop expanding product-form authorities as the default activity. Use the existing
> structure to finish the unresolved Android adaptation research that a future
> Astral-like distribution will need.

## References

### Project evidence

- Current repository context and frozen E2-P3 evidence
- Frozen CPython 3.14.6 product lock
- Frozen BeeWare dependency lock
- Frozen launcher source
- E2-P1 artifact contract
- E2-P2 façade and producer evidence
- E2-P3 archive qualification evidence

### External references

- https://docs.python.org/3.14/using/android.html
- https://docs.python.org/3.15/whatsnew/3.15.html
- https://developer.android.com/guide/practices/page-sizes
- https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/#android
- https://github.com/astral-sh/python-build-standalone/blob/main/docs/distributions.rst
- https://docs.astral.sh/uv/concepts/python-versions/
