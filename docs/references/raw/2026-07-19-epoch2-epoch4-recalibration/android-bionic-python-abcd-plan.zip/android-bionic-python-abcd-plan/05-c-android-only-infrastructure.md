# 05 — C: Android-Only Infrastructure

## 1. Classification

**Class:** C — new infrastructure required because an Android target cannot be built, optimized, and validated entirely through Astral's desktop-target execution assumptions.

C must remain infrastructure around the A/B build rather than a second Android-specific Python build system.

## 2. Android target runner

Cross-compiled Android binaries normally cannot execute directly on a Linux or macOS build host. The build requires a reusable target-runner abstraction.

```python
class AndroidRunner:
    def prepare(self) -> None: ...
    def deploy_tree(self, local_root: str) -> str: ...
    def run(self, argv: list[str], env: dict[str, str]) -> RunResult: ...
    def push(self, local: str, remote: str) -> None: ...
    def pull(self, remote: str, local: str) -> None: ...
    def cleanup(self) -> None: ...
```

Initial backends:

```text
connected ADB device
managed or pre-created Android emulator
```

Later backends may include a device farm, but the build graph must see all backends through the same interface.

## 3. Deployment workspace

The runner creates a controlled target workspace, such as:

```text
/data/local/tmp/pbs-android/<run-id>/
├── runtime/
├── home/
├── tmp/
├── output/
└── profiles/
```

It explicitly sets:

```text
HOME
TMPDIR
PYTHONHOME only when a test intentionally uses it
locale variables where supported
certificate/terminal variables only for diagnostic comparison
```

The production runtime must not rely on the runner's environment beyond ordinary context requirements such as a writable temporary directory.

## 4. Target-side PGO

Astral's PGO profile model is retained, but Android needs a new collection path.

```text
instrumented build
    |
    v
deploy runtime to Android
    |
    v
run CPython PROFILE_TASK
    |
    v
collect *.profraw
    |
    v
pull to host
    |
    v
llvm-profdata merge
    |
    v
optimized rebuild
```

The runner records:

- device model or emulator image;
- Android API level;
- CPU architecture and feature set;
- profile task arguments;
- test exclusions;
- profile-file hashes;
- LLVM tool version.

PGO is not promoted to the release default until repeated runs produce stable functional results and acceptable performance variance.

## 5. Android metadata extension

Android compatibility fields must be machine-readable.

Proposed `PYTHON.json` extension:

```json
{
  "android": {
    "abi": "arm64-v8a",
    "api_min": 24,
    "ndk_version": "<pinned>",
    "linker": "/system/bin/linker64",
    "page_size_max": 16384,
    "public_native_dependencies": ["libc.so", "libm.so", "libdl.so"]
  }
}
```

The schema must distinguish:

```text
build metadata
runtime compatibility claims
observed validation environments
```

A successful test on API 35 does not replace the declared API 24 floor.

## 6. Android ELF verifier

A dedicated verifier audits every ELF file in the full and install-only archives.

Checks:

```text
ELF class and machine
Android program interpreter
SONAME
DT_NEEDED allowlist
RPATH/RUNPATH policy
text relocations
undefined symbols
GNU hash/build-id policy where applicable
16 KiB page alignment compatibility
executable-stack flags
absolute path strings
Termux path strings
NDK/build-root leakage
```

The verifier classifies dependencies as:

```text
bundle-owned
public NDK platform dependency
forbidden private platform dependency
unknown/error
```

Any unknown dependency fails the release until explicitly adjudicated.

## 7. API compatibility verifier

Static inspection is paired with actual load tests.

Minimum matrix:

```text
minimum supported API emulator/device
current target API emulator/device
at least one physical arm64 device when available
```

The test starts every executable and imports every shipped shared extension. This catches load-time strong references and missing `DT_NEEDED` libraries.

## 8. Functional device test suite

Required tests are behavioral, not only imports:

```text
ssl: verified HTTPS connection and certificate failure case
sqlite3: create/query/transaction/extension policy
ctypes: call libc and execute a callback closure
zlib/bz2/lzma/zstd: round trips
socket: TCP and DNS
subprocess: simple command in contexts that support it
multiprocessing: supported start methods and IPC
venv: create and execute
pip: install a pure-Python wheel without network
locale/timezone: documented behavior
signals: basic delivery where permitted
```

Context-specific expected failures are encoded explicitly rather than hidden with broad skips.

## 9. Android wheel validator

The project needs a minimal Android-native package test independent of Termux packages.

Pipeline:

```text
small C extension source
    |
    v
build with declared Android SDK/toolchain contract
    |
    v
produce Android-tagged wheel
    |
    v
install into standalone Python
    |
    v
import and run extension
```

The validator checks:

- `sysconfig.get_platform()`;
- extension suffixes;
- Python ABI tag;
- wheel platform tag;
- API floor metadata;
- `DT_NEEDED` and libpython behavior;
- absence of Termux paths.

## 10. Clean-room test image

A release claim of Termux independence requires a clean Android environment with no Termux package tree.

The clean image contains only:

```text
Android system image
adb access
runtime archive and test harness pushed by CI
```

This is infrastructure for Priority 1 validation and later Priority 2 proof.

## 11. Test-result artifacts

Every build profile should produce:

```text
elf-audit.json
api-matrix.json
module-results.json
functional-results.json
relocation-results.json
wheel-smoke-test.json
pgo-provenance.json, when applicable
```

These become release attachments or are embedded into the build provenance archive.

## 12. Acceptance criteria for C

- target binaries can be deployed and executed without manual steps;
- noopt/debug test runs are automated;
- ELF and API policy failures are machine-readable release failures;
- minimum-API and current-API tests exist;
- PGO collection is reproducible enough to audit;
- a native Android wheel can be built and imported;
- clean-room tests do not depend on Termux.

## References

- [CPython Android testing and packaging README](https://github.com/python/cpython/blob/v3.14.6/Android/README.md)
- [CPython Android testbed](https://github.com/python/cpython/tree/v3.14.6/Android/testbed)
- [Android NDK: Using newer APIs](https://developer.android.com/ndk/guides/using-newer-apis)
- [Android NDK: Native APIs](https://developer.android.com/ndk/guides/stable_apis)
