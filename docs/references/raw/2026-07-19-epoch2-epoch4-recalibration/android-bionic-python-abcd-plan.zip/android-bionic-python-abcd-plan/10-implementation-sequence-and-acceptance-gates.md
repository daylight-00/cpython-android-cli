# 10 — Implementation Sequence and Acceptance Gates

## 1. Principle

Implementation order follows priority and evidence:

```text
Preserve Astral first
    -> adapt for Android only where required
        -> build Android-only test infrastructure
            -> prove generic Android delivery
                -> strengthen direct extraction
                    -> add APK consumption
```

No later stage may silently rewrite the contract of an earlier stage.

## 2. Stage 0 — Reference snapshot and diff discipline

Outputs:

```text
pinned Astral reference commit
pinned CPython version/tag
pinned NDK version
source/dependency lock data
initial patch inventory
classification map: A/B/C/D2/D3/D4
```

Gate:

- every planned file or component has a classification;
- every intended divergence from Astral has a stated Android reason;
- APK-driven changes are marked deferred.

## 3. Stage 1 — A skeleton preserved

Implement or fork the Astral orchestration without building a working target yet.

Outputs:

```text
build CLI
target parser
Makefile graph
dependency artifacts
full/install-only transformation
PYTHON.json validation
```

Gate:

- a dummy or existing target can traverse the unchanged pipeline;
- archive validation tests pass;
- Android support is a target addition, not a parallel build system.

## 4. Stage 2 — B1 Android dependency toolchain

Target:

```text
CPython 3.14.x
aarch64-linux-android
API 24
noopt
```

Build the native dependency closure first.

Outputs:

```text
NDK provider
Android target settings
OpenSSL static artifact
SQLite static artifact
libffi static artifact
compression/parser static artifacts
metadata and license records
```

Gate:

- every archive is NDK-built, PIC-compatible, and host-path-clean;
- no Termux libraries are consumed;
- minimal test libraries load on the minimum API.

## 5. Stage 3 — B2 baseline CPython

Build the Astral topology:

```text
static-interpreter/shared-libpython hybrid
static-first stdlib extensions
static native dependency closure
pinned pip
no Tk/X11
```

Outputs:

```text
noopt full.tar.zst
noopt install_only.tar.gz
PYTHON.json
module manifest
```

Gate:

- `python -c` starts on Android;
- required modules import;
- full archive passes schema checks;
- install-only is mechanically derived;
- ELF dependencies pass the provisional allowlist.

## 6. Stage 4 — C target runner and functional tests

Outputs:

```text
ADB runner
clean emulator/device workspace
functional module suite
ELF verifier
API-floor load suite
```

Gate:

- the build can deploy and test without manual intervention;
- functional SSL/SQLite/ctypes tests pass;
- failures are machine-readable;
- clean Android with no Termux installation succeeds.

## 7. Stage 5 — Debug and shared-extension compatibility

Outputs:

```text
debug full archive
minimal third-party C extension
Android wheel smoke test
libpython topology diagnostic tests
```

Gate:

- debug runtime works;
- shared extension loading works;
- no duplicate-runtime correctness failure is observed, or a decision record is opened;
- no fallback architecture is adopted without evidence.

## 8. Stage 6 — D2 Priority 2 delivery

Outputs:

```text
Termux-independent audit
Termux direct-use test
adb test
root-shell test
deployment helpers
uv integration prototype/catalog
```

Gate:

- the same archive passes Termux, adb, and root contexts;
- no Termux runtime dependency exists;
- uv installs the same archive rather than a rebuilt Termux flavor;
- context differences are documented as Android policy differences.

## 9. Stage 7 — D3 Priority 3 direct extraction

Outputs:

```text
multiple extraction-root matrix
symlink invocation tests
bundle-relative certificate policy
terminal-data policy
runtime zero-fixup proof
```

Gate:

- fresh extraction at all supported roots succeeds;
- uv is absent from a successful path;
- runtime-critical metadata contains no fixed final prefix;
- post-install movement remains explicitly outside scope.

## 10. Stage 8 — LTO

Build and compare:

```text
noopt
lto
```

Gate:

- functional and relocation suites are identical;
- archive metadata records LTO state and toolchain;
- size/performance changes are measured;
- no unsupported LLVM bitcode leaks into user-facing SDK expectations without metadata.

## 11. Stage 9 — PGO and PGO+LTO

Outputs:

```text
Android PGO runner
profile provenance
pgo archive
pgo+lto archive
performance report
```

Gate:

- target-side profile collection is reproducible;
- optimized builds pass all earlier tests;
- install-only release selection may promote PGO+LTO only after this gate.

## 12. Stage 10 — SDK and wheel maturity

Outputs:

```text
relocatable sysconfig review
NDK/toolchain descriptor
python-config/pkg-config validation
native Android wheel build guide
larger extension package tests
```

Gate:

- source builds do not use Termux runtime paths;
- Android tags are correct;
- API floor is preserved;
- the SDK helper does not patch the runtime installation.

## 13. Stage 11 — D4 Priority 4 APK consumer

Outputs:

```text
minimal APK testbed
full-archive packager
JNI launcher
shared-libpython embedding tests
Android native wheel in-app test
```

Gate:

- APK consumes the same core lineage;
- no earlier priority is weakened;
- baseline topology is retained unless a recorded decision gate requires change;
- private shared dependencies are introduced only per dependency and with evidence.

## 14. Release gates

A public baseline release requires:

```text
A1/A2 architecture preserved
B1/B2 Android build complete
C clean-room and API tests complete
D2 Termux/adb/root independence complete
D3 direct-extraction runtime complete
```

APK is not required for the first public standalone release.

## 15. Stop conditions

Development stops and opens a design review when:

- the only proposed fix is a broad Termux-specific runtime dependency;
- an Android private platform library is required;
- uv must patch the core to start;
- the APK path demands a preemptive core topology change;
- a source build appears to work only because host/Termux paths leaked into sysconfig;
- PGO results cannot be traced to a target execution profile;
- artifact metadata cannot describe the actual linkage.

## 16. Deliverable summary

```text
Priority 1 deliverable:
Astral-like Android/Bionic full and install-only distributions

Priority 2 deliverable:
Same artifact usable through Termux, adb, root, and uv-managed Termux

Priority 3 deliverable:
Fresh extract-anywhere runtime contract

Priority 4 deliverable:
APK packaging from the same core lineage
```

## References

- [python-build-standalone building](https://gregoryszorc.com/docs/python-build-standalone/main/building.html)
- [python-build-standalone distribution archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [uv managed Python](https://docs.astral.sh/uv/concepts/python-versions/)
- [CPython Android build and test flow](https://github.com/python/cpython/blob/v3.14.6/Android/README.md)
