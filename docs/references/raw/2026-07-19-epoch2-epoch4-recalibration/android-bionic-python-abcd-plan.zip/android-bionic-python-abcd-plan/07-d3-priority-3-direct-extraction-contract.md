# 07 — D3: Priority 3 Direct-Extraction Contract

## 1. Classification

**Class:** D3 — a stronger user-facing relocation guarantee added after the Astral-like Bionic runtime exists.  
**Reference experience:** Astral install-only distributions on Windows can be extracted at a chosen final location and used there without a traditional installer.

## 2. Normative definition

> An untouched install-only archive may be extracted to any suitable executable final path accessible to the current Android UID, and the CPython core will run from that location without uv, an installer, Termux packages, or runtime path patching.

This is **fresh extraction relocatability**.

It is not a guarantee that a mutated installation remains movable after virtual environments, packages, or generated scripts have recorded paths.

## 3. Guaranteed behavior

For each independent extraction:

```text
/path/A/python
/path/B/tools/python
/path/C/runtime/python
```

all of the following work immediately:

```sh
./bin/python3 -c 'import sys; print(sys.prefix)'
./bin/python3 -c 'import ssl, sqlite3, ctypes, zlib'
./bin/python3 -m pip --version
./bin/python3 -m venv ./test-venv
```

`sys.prefix` and resource paths reflect the current extraction root.

## 4. Explicit non-guarantees

The contract does not promise:

- movement of the installation after packages are installed;
- movement of pre-existing venvs;
- portability of generated console-script shebangs;
- portability of third-party package data containing absolute paths;
- execution from `/sdcard` or emulated shared storage;
- automatic ownership/SELinux translation across Android UIDs;
- identical behavior in an app sandbox and a root shell where process policies differ.

## 5. Suitable path definition

A supported path must:

```text
be readable and searchable by the current UID
allow execution of native code
preserve Unix file modes and symlinks used by the archive
provide or permit a writable temporary directory
not be a noexec/emulated shared-storage mount
```

The project documents tested path classes rather than promising literally every Android pathname.

## 6. Zero-fixup runtime rule

The following must work without post-extraction rewriting:

```text
ELF interpreter and bundled shared-library lookup
CPython executable discovery
sys.prefix and sys.exec_prefix
stdlib and lib-dynload discovery
built-in extension imports
certificate data discovery
terminal data discovery, when shipped
python -m pip
venv creation
```

uv may verify, record, and expose the installation. It must not make the runtime operational by rewriting ELF or core Python paths.

## 7. ELF-relative lookup

No runtime-critical ELF may contain a dependency on a fixed final prefix.

Expected example:

```text
bin/python3
  interpreter: /system/bin/linker64
  RUNPATH: $ORIGIN/../lib
```

Forbidden examples:

```text
/data/data/com.termux/files/usr/lib
/install/lib used as runtime path
host NDK path
build-container dependency path
```

The static dependency baseline reduces the number of relative native-library lookups needed.

## 8. CPython path discovery

The startup path algorithm must derive installation roots from the actual executable/library location and handle:

```text
direct executable invocation
relative executable invocation
symlink invocation
versioned and unversioned executable links
venv base executable resolution
```

Compile-time `/install` is permitted only as a staging prefix that is absent from effective runtime paths.

## 9. Runtime data

### Certificates

TLS verification must find a distribution-owned or explicitly validated certificate source without an installer patch.

Preferred bundle-relative shape:

```text
share/certs/ca-bundle.crt
```

The Python/OpenSSL default policy computes or records this location relative to the active prefix.

### Terminfo

When readline/curses support is included:

```text
share/terminfo/
```

must be found automatically. Requiring users to set `TERMINFO` for every invocation weakens the standalone contract.

### Timezone data

If the distribution supplies timezone data, it follows the same relative-resource policy. If it relies on Android system data, the dependency is documented and tested.

## 10. Runtime versus SDK relocation

Two levels are tracked independently.

### Required runtime level

```text
interpreter execution
stdlib imports
bundled extension imports
pip as a module
venv creation
```

### Strong SDK level

```text
python-config
pkg-config
C extension compilation
native wheel build
```

The runtime level is a release requirement. The SDK level is highly desirable, but it may initially require an explicit toolchain descriptor or build helper because the end user does not have the original NDK path.

An SDK helper may select a compatible NDK. It must not patch the installed runtime.

## 11. Extraction and movement distinction

Supported:

```text
archive -> extract fresh at /A -> use
same archive -> extract fresh at /B -> use
```

Not guaranteed:

```text
extract at /A -> install packages/venvs -> move the modified tree to /B
```

This distinction matches the requested Windows experience without claiming complete environment portability.

## 12. Relocation test matrix

Each release tests fresh extraction under:

```text
short path
deep path
path with a changed root basename
Termux-owned private path
adb-shell writable executable path
root-owned suitable path
symlinked executable invocation
```

For every root, record:

```text
sys.executable
sys.prefix
sys.exec_prefix
sys.path
sysconfig paths
loaded ELF dependencies
certificate path
module results
venv base executable
```

## 13. Archive-format requirements

The archive format must preserve:

```text
file modes
symlinks
long paths
UTF-8 filenames used by the distribution
hard links, if any
```

Gzip tar remains the maximum-compatibility install-only format. A zstd-compressed variant may also be published when extraction tooling is available.

## 14. Acceptance criteria for Priority 3

- three or more fresh extraction roots pass the runtime suite;
- uv is absent from at least one successful test path;
- no fixed Termux or final install prefix controls runtime execution;
- symlink invocation resolves the real installation correctly;
- TLS and terminal data are self-discovering or explicitly excluded from the flavor;
- relocation failures produce machine-readable test output;
- post-install movement is clearly excluded from claims and documentation.

## References

- [python-build-standalone overview](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [python-build-standalone quirks](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)
- [Distribution Archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [uv storage and managed Python locations](https://docs.astral.sh/uv/reference/storage/)
