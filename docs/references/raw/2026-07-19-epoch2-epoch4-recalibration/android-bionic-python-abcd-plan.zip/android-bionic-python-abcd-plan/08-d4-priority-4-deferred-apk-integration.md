# 08 — D4: Priority 4 Deferred APK Integration

## 1. Classification

**Class:** D4 — downstream consumer work after Priorities 1–3 stabilize.  
**Weight:** explicitly lower than Astral fidelity, generic Android/Bionic nativeness, and direct-extraction behavior.

APK is important, but it must not determine the first standalone architecture.

## 2. Why APK is fourth priority

The primary intended workflow is Termux with uv, with direct Termux/adb/root use as proof of generic Android nativeness. APK integration is a useful reuse path and may later enable Python-based CLI or application products, but it introduces app-specific concerns:

```text
Gradle and AAB/APK packaging
JNI entry points
app lifecycle
assets extraction
native library namespaces
app UID storage
Play distribution policy
```

These concerns should not be allowed to force early changes to:

- Astral's static-interpreter baseline;
- static native-dependency closure;
- install-only archive layout;
- direct shell launchers;
- uv integration design.

## 3. Core-lineage invariant

APK packaging MUST reuse the same build lineage:

```text
CPython source version
patch set
native dependency versions
extension-module policy
compiler/NDK/API floor
build profile
license inventory
provenance
```

It MAY transform the packaging layout.

```text
full archive or core build outputs
        |
        v
APK packager
├── jniLibs/<abi>/libpython...
├── jniLibs/<abi>/<required shared libs, if any>
├── assets/python stdlib
└── JNI/Kotlin launcher
```

The invariant is one core lineage, not one literal tarball layout.

## 4. Initial APK source artifact

The APK packager SHOULD consume the full archive because it provides:

- shared and static libpython artifacts;
- object files;
- extension metadata;
- static native dependency archives;
- licenses;
- exact link requirements.

This permits APK experiments without changing the user-facing install-only archive.

## 5. Baseline `libpython` use

Priority 1 produces Astral's static-interpreter/shared-libpython hybrid. The shared libpython artifact can be tested as the embedding library.

The APK experiment asks:

```text
Can the shared libpython from the same full archive
initialize correctly inside an app and use the same stdlib/module payload?
```

Only a negative result with a reproducible cause justifies changing the core topology.

## 6. Native dependency packaging

The baseline statically links OpenSSL, SQLite, libffi, and similar dependencies into CPython artifacts. This is tested first for APK use.

Private shared libraries such as:

```text
libssl_python.so
libcrypto_python.so
libsqlite3_python.so
libffi_python.so
```

are fallback packaging choices, not initial requirements. They may be useful if:

- code duplication becomes unacceptable;
- APK native-library boundaries require modular libraries;
- a dependency cannot be safely statically linked;
- symbol or licensing constraints require separation;
- official CPython Android compatibility materially benefits from that layout.

## 7. APK testbed

A minimal test app should:

1. load the shared libpython produced by the full archive;
2. set the Python home/module search path to app-owned packaged data;
3. initialize CPython through the embedding API;
4. run pure Python code;
5. import `_ssl`, `_sqlite3`, and `_ctypes`;
6. load one third-party Android native extension;
7. perform a verified TLS connection;
8. shut down or retain the interpreter according to the selected lifecycle policy.

The testbed is a consumer test, not the canonical build path.

## 8. Repackaging policy

Allowed transformations:

```text
rename or normalize libpython filename for Android packaging
place shared libraries under jniLibs ABI directories
zip/compile stdlib into assets
extract stdlib to app-private files at first run
remove CLI launchers from APK payload
include app-specific bootstrap code
```

Forbidden transformations:

```text
rebuild CPython against Termux libraries
use a different dependency version set without provenance
silently change extension module policy
patch the core in a way not represented in the full archive metadata
claim the APK runtime is the same lineage when it is independently built
```

## 9. Relationship to official CPython Android

Official CPython documentation treats Android primarily as embedded Python inside an app. It packages libpython, the standard library, and app code for private use.

This project uses official Android support as the embedding and ABI reference, while keeping Astral standalone architecture primary for the core distribution.

```text
Astral -> core distribution and release architecture
CPython Android -> app embedding and Android platform behavior
```

## 10. Priority isolation rules

Before Priorities 1–3 are complete, APK work may only:

- create a testbed;
- inspect full-archive usability;
- identify concrete incompatibilities;
- propose decision records.

It may not:

- replace the baseline `libpython` topology;
- replace static dependency closure;
- make the install-only layout APK-specific;
- make an app launcher a runtime prerequisite;
- delay direct Termux/adb/root validation.

## 11. Promotion criteria

APK integration becomes a supported output after:

- Priority 1 noopt release passes;
- Priority 2 clean Android and multi-context tests pass;
- Priority 3 direct-extraction tests pass;
- shared libpython embedding succeeds or a documented fallback is approved;
- app packaging uses the same provenance and dependency set;
- Android wheel/native-extension loading is validated inside the app.

## References

- [CPython 3.14: Using Python on Android](https://docs.python.org/3.14/using/android.html)
- [CPython Android source and testbed](https://github.com/python/cpython/tree/v3.14.6/Android)
- [python-build-standalone full archive](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
