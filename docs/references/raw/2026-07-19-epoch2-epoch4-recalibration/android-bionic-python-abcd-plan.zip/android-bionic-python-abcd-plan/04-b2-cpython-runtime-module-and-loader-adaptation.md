# 04 — B2: CPython Runtime, Module, and Loader Adaptation

## 1. Classification

**Class:** B — retain Astral's responsibilities for CPython configuration, module policy, relocation, metadata normalization, and launchers, but implement them for Android/Bionic.

## 2. Configure and cross-build answers

The CPython build retains Astral's high-level configuration pattern:

```text
--build=<build triple>
--host=aarch64-linux-android
--prefix=/install
--with-build-python=<host Python>
--without-ensurepip
<shared/static libpython baseline options>
<optimization options>
```

Android-specific cached answers and feature decisions must be explicit. They must be derived from official CPython Android behavior and the NDK rather than copied blindly from generic Linux cross-build assumptions.

Examples requiring review:

```text
getaddrinfo behavior
tzset
pthread-related checks
semaphore support
/dev/ptmx and pseudo-terminal behavior
fork/subprocess assumptions
shared memory APIs
clock and entropy APIs
locale behavior
```

## 3. Patch hierarchy

Patches are selected in this order:

1. upstream CPython Android implementation or backportable upstream change;
2. Android NDK guidance;
3. Astral's platform-neutral cross-build and relocatability patches;
4. Termux patches that solve a genuine Bionic issue without `$PREFIX` coupling;
5. project-specific patch, with a focused test and upstream rationale.

Every project patch must state:

```text
problem
affected CPython versions
Android API/ABI scope
upstream or reference issue
behavioral test
removal condition
```

## 4. Standard-library module matrix

The module policy remains metadata-driven. Android changes availability conditions, not the mechanism.

### Initial required feature set

```text
_ssl and _hashlib
_sqlite3
_ctypes
zlib, _bz2, _lzma, _zstd where supported
pyexpat
_decimal
_socket
select
subprocess support
_multiprocessing where Android semantics permit
venv
pip
```

### Deferred or excluded from the first core

```text
_tkinter
Tcl/Tk
X11 libraries
GUI-specific modules
Berkeley DB unless a strong compatibility case exists
NIS
OSS audio
platform-inapplicable tests and demos
```

A missing module must be reported in `PYTHON.json` and release notes rather than silently omitted.

## 5. Android process-model restrictions

Android is not a generic desktop Linux distribution. Even if the kernel exposes a syscall, execution may differ because of:

- application UID sandboxing;
- SELinux domain;
- writable and executable mount policy;
- process-spawn restrictions in an app context;
- app-private library namespaces;
- missing system-level services or configuration files.

The standalone CLI target should implement CPython semantics available to a native process, but it must not claim identical behavior in Termux, adb, root, and APK contexts where Android policy differs.

## 6. Loader-relative behavior

The distribution must not rely on a fixed build or install prefix to locate shared components.

For an ELF executable that needs a bundled shared library:

```text
bin/python3.x
DT_RUNPATH = $ORIGIN/../lib
```

For shared extension modules requiring a bundled library, any relative lookup must be designed around the module location and verified on the minimum API.

The baseline static dependency closure should keep `DT_NEEDED` small, but shared libpython and selected shared extension modules still require correct relative lookup.

Android-specific validation must cover:

- direct invocation;
- invocation through a symlink;
- altered `argv[0]` where feasible;
- execution after extraction at multiple roots;
- absence of `LD_LIBRARY_PATH` requirements.

## 7. CPython path discovery

Astral patches `getpath` behavior because a relocatable Python cannot rely on the compiled installation prefix.

Bionic must preserve equivalent behavior for:

```text
sys.executable
sys._base_executable
sys.prefix
sys.exec_prefix
stdlib
platstdlib
lib-dynload
venv base-prefix resolution
```

The current executable or library location must be the source of truth. Compile-time `/install` is a build staging convention, not a valid runtime fallback.

## 8. Sysconfig normalization

Astral removes build-environment paths from:

```text
_sysconfigdata_*.py
Python Makefile
pythonX.Y-config
pkg-config files
PYTHON.json fields
```

Bionic adds the following forbidden-path set:

```text
Android SDK absolute path
Android NDK absolute path
build-container path
host bootstrap Python path
Termux $PREFIX
temporary dependency prefix
```

`pkg-config` files SHOULD use their own file location to derive the prefix, for example:

```text
prefix=${pcfiledir}/../..
```

The distribution may retain the target compiler identity and flags needed to build extensions, but must not embed a nonexistent absolute NDK path as though the end user had the original build machine.

This leads to a separate SDK question: how end users obtain a compatible NDK/toolchain for source extension builds. That question must not block runtime relocation.

## 9. Python script launchers

Astral Unix rewrites Python shebangs into relative shell wrappers. Android does not normally provide `/bin/sh`; the standard shell path is `/system/bin/sh`.

Baseline interface:

```sh
python -m pip
python -m venv
```

Optional launchers may use:

```sh
#!/system/bin/sh
```

and resolve the adjacent interpreter. Launcher support must be tested in Termux, adb, and root contexts and must not be confused with core Python functionality.

## 10. Certificates and TLS defaults

A standalone `_ssl` module is insufficient if certificate discovery depends on a desktop Linux filesystem layout.

The project must define one of:

- a distribution-owned CA bundle located relative to `sys.prefix`;
- a documented, stable Android system certificate integration;
- a layered policy that prefers an explicit environment override, then bundle-relative data, then a validated system path.

The first release SHOULD include a reproducible CA bundle and a test for outbound TLS verification. Certificate update policy and license/source metadata must be explicit.

## 11. Terminal editing, curses, and terminfo

Astral Linux distributions may build libedit/ncurses and carry a terminfo database. Android has no universal desktop distribution terminfo path.

Choices:

1. omit readline/curses from the first minimal core;
2. bundle terminfo and configure the runtime to find it relative to the prefix;
3. patch the relevant libraries for bundle-relative lookup.

Priority 1 favors Astral feature parity, but Priority 3 rejects mandatory user environment setup. A staged approach is appropriate:

```text
first usable core: bundle data and perform internal/default relative lookup
later hardening: remove wrappers or environment dependence through library patches
```

## 12. `libpython` baseline and B adaptation boundary

The initial topology remains Astral's static interpreter plus shared libpython artifact.

Moving to `shared-libpython-primary` is a B change only after tests show an Android correctness or interoperability requirement. APK preference alone is insufficient because APK is Priority 4.

## 13. Acceptance criteria for B2

- required module imports and functional tests pass on Android;
- unavailable modules are explicit and metadata-driven;
- no build-time or Termux path controls runtime startup;
- shared components are found without `LD_LIBRARY_PATH`;
- `sys.prefix` and stdlib discovery follow the extraction root;
- `python -m pip` works;
- TLS verification has an explicit certificate policy;
- terminal data behavior is either self-contained or explicitly excluded from the first flavor.

## References

- [`build-cpython.sh`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-cpython.sh)
- [python-build-standalone quirks](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)
- [CPython Android source directory](https://github.com/python/cpython/tree/v3.14.6/Android)
- [CPython: Using Python on Android](https://docs.python.org/3.14/using/android.html)
- [Android dynamic linker changes for NDK developers](https://android.googlesource.com/platform/bionic/+/master/android-changes-for-ndk-developers.md)
