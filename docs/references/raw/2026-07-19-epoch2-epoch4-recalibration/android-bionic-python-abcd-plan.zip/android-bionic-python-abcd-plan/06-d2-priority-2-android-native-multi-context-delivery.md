# 06 — D2: Priority 2 Android-Native Multi-Context Delivery

## 1. Classification

**Class:** D2 — additional work after the Priority 1 Bionic standalone exists.  
**Goal:** prove that the core is Android/Bionic-native rather than Termux-overfitted and deliver it through Termux, adb, root, and uv-managed paths.

APK is not included here; it is Priority 4.

## 2. Termux-independent runtime definition

A distribution is Termux-independent when it does not require:

```text
/data/data/com.termux/files/usr
$PREFIX
Termux package database
Termux-provided libssl/libcrypto/libsqlite/libffi
Termux-specific loader wrappers
Termux-only shell paths
```

It may still run inside the Termux application sandbox. Execution location and ABI dependency are separate properties.

## 3. Independence audit

Every release scans:

```text
ELF dynamic sections
ELF/string contents
Python configuration data
Makefiles
pkg-config files
shell launchers
metadata
license/source records
```

Forbidden patterns include:

```text
/data/data/com.termux
com.termux
$PREFIX
Termux package-library paths
host build roots
```

A match must be either removed or documented as non-runtime text with a verifier exception.

## 4. Context matrix

The same untouched install-only archive is validated in:

| Context | Typical location | Core artifact |
|---|---|---|
| Direct Termux | `$HOME/...` | identical archive |
| adb shell | `/data/local/tmp/...` | identical archive |
| root shell | `/data/local/...` or another suitable path | identical archive |

The contexts differ in UID, SELinux domain, default environment, writable locations, and persistence. These differences are not solved by rebuilding Python.

## 5. Context-neutral defaults

The runtime must not hardcode one environment's values for:

```text
HOME
TMPDIR
cache directory
user site directory
shell
current working directory
```

The launcher or caller supplies them when the context lacks reasonable defaults.

Examples:

```sh
HOME=/data/local/tmp/py-home \
TMPDIR=/data/local/tmp/py-tmp \
/data/local/tmp/python/bin/python3
```

In Termux, the existing `HOME` and `TMPDIR` normally remain appropriate.

## 6. Direct Termux path

```text
install-only archive
    |
    v
extract under a suitable Termux-owned directory
    |
    v
bin/python3
```

Termux contributes:

```text
terminal emulator
shell
app-private filesystem context
HOME/TMPDIR
optional build tools for user packages
```

The standalone distribution contributes all CPython runtime dependencies.

A Termux `.deb` MAY wrap the untouched core payload, but it must not rebuild or relink the runtime against Termux packages.

## 7. adb and root helpers

Optional helpers are delivery tooling, not runtime prerequisites.

```text
adb-install
adb-run
root-install
```

They may:

- push archives;
- extract files;
- set Unix modes;
- create writable home/tmp directories;
- expose a path or symlink;
- report SELinux and mount constraints.

They must not patch `sys.prefix`, ELF RPATH, or native dependencies.

## 8. uv integration path

The preferred Termux user experience is eventually:

```text
Android/Bionic install-only artifact
        |
        v
uv managed-Python catalog
        |
        v
uv download / checksum / extraction / discovery
        |
        v
Termux project and virtual-environment workflow
```

uv already distinguishes managed and system Python installations, automatically downloads managed distributions, exposes versioned executables, and uses Astral `python-build-standalone` for CPython distributions.

Android integration may require:

```text
Android host detection
Bionic platform identity
artifact catalog entries
API-floor compatibility selection
managed install-directory policy
executable exposure
Python discovery query support
```

uv must be able to consume the core; it must not be required to repair core runtime relocation.

## 9. uv-compatible release metadata

A downloadable record needs at least:

```text
implementation
Python version
variant: GIL/free-threaded/debug
architecture
OS/platform: Android
libc: Bionic
minimum API level
archive URL
archive format
SHA-256
release build identifier
```

The public naming and catalog format should follow uv conventions where possible. Android-specific fields should be proposed upstream rather than hidden in an incompatible private manager.

## 10. Package-building distinction

Termux remains useful for source builds of third-party packages, but a wheel built against Termux `$PREFIX` is not automatically a generic Android wheel.

The project must distinguish:

```text
runtime core independence
native extension SDK/toolchain
Termux-hosted build convenience
public Android wheel compatibility
```

A user may compile a package in Termux against the standalone SDK, but the result is generic Android only if it avoids Termux runtime paths and follows Android wheel ABI/tag rules.

## 11. Cross-context acceptance suite

The same archive passes, where the context permits:

```text
startup and sys.prefix
ssl verified connection
sqlite transaction
ctypes callback
compression round trips
venv creation
python -m pip
pure-Python wheel install
native wheel install
subprocess
multiprocessing
signal handling
```

Differences caused by UID/SELinux are recorded per context and must not be misdiagnosed as different Python builds.

## 12. Acceptance criteria for Priority 2

- clean Android without Termux loads and runs the archive;
- direct Termux uses no Termux runtime libraries;
- adb and root consume the same archive;
- all runtime-critical paths are environment-neutral;
- optional helpers perform deployment only;
- uv integration installs the same artifact rather than a Termux-specific rebuild;
- Android wheel identity is not `manylinux` or a private Termux tag.

## References

- [uv: Python versions](https://docs.astral.sh/uv/concepts/python-versions/)
- [uv: Installing and managing Python](https://docs.astral.sh/uv/guides/install-python/)
- [uv storage](https://docs.astral.sh/uv/reference/storage/)
- [Termux execution environment](https://github.com/termux/termux-packages/wiki/Termux-execution-environment)
- [Android NDK: Native APIs](https://developer.android.com/ndk/guides/stable_apis)
