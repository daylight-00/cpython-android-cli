# 09 — Decision Gates: `libpython` and Native Dependencies

## 1. Purpose

This document prevents two plausible Android designs from becoming untested assumptions:

- `shared-libpython-primary`;
- private `lib*_python.so` native-dependency bundles.

Both are fallback architectures. They are independent choices.

## 2. The three topology axes

### Axis 1 — Interpreter to `libpython`

```text
Static-interpreter baseline:
python executable contains libpython code

Shared-libpython-primary:
python executable DT_NEEDED -> libpython.so
```

### Axis 2 — Standard-library extension build mode

```text
built-in/static extension
shared extension under lib-dynload
```

### Axis 3 — Third-party native dependency linkage

```text
static dependency archive linked into CPython artifact
private namespaced shared dependency shipped beside CPython
```

A design decision must name the axis being changed.

## 3. Baseline combination

Priority 1 begins with:

```text
Interpreter:          static libpython in executable
Shared libpython:     also emitted for downstream consumers
Stdlib extensions:    built-in/static by default
Native dependencies:  pinned static closure
```

This is the closest match to current Astral Unix behavior.

## 4. `shared-libpython-primary`

### Structure

```text
bin/python3
  DT_NEEDED -> libpython3.x.so
  RUNPATH   -> $ORIGIN/../lib
```

The CLI executable, embedder, and extensions can all resolve one shared runtime instance.

### Potential benefits

- one actual CPython runtime library per process;
- natural CLI/APK reuse;
- simpler embedding contract;
- reduced risk when third-party extensions explicitly link libpython;
- smaller launcher executable.

### Potential costs

- startup depends on dynamic discovery of libpython;
- Android RUNPATH/namespace behavior becomes runtime-critical;
- diverges from the Astral baseline;
- shared symbol export and SONAME policy become more important;
- a missing or misplaced shared library prevents any startup.

### Trigger conditions

Adopt only if tests demonstrate one or more of:

1. the Astral hybrid loads a second libpython instance used by an extension;
2. Python runtime state or C API behavior is inconsistent across copies;
3. Android loader semantics make the hybrid unreliable;
4. shared libpython from the baseline cannot serve the supported embedding consumer without rebuilding;
5. common Android native wheels require explicit libpython linkage that is unsafe under the hybrid.

### Required experiment

Build both topologies from identical sources and compare:

```text
CLI startup and relocation
built-in extension suite
shared third-party extension with and without libpython DT_NEEDED
ctypes.CDLL(None) and explicit libpython loading
embedding testbed
symbol/address identity for key runtime objects
process maps and loaded library list
```

## 5. Private `lib*_python.so` dependency bundle

### Structure

```text
_ssl.so or libpython
  -> libssl_python.so
  -> libcrypto_python.so

_sqlite3.so or libpython
  -> libsqlite3_python.so

_ctypes.so or libpython
  -> libffi_python.so
```

Namespacing reduces collision with system or app libraries.

### Potential benefits

- native dependencies can be shared by several Python extensions;
- dependency boundaries are visible and replaceable;
- APK `jniLibs` packaging aligns with official CPython Android patterns;
- isolated SONAMEs reduce accidental collision;
- debugging and security updates can target a dependency library.

### Potential costs

- more files and loader edges;
- more RUNPATH/namespace and load-order complexity;
- missing libraries become import/startup failures;
- stronger divergence from Astral static closure;
- direct-extraction testing becomes more complex;
- symbol isolation still needs careful configuration.

### Trigger conditions

Adopt for a specific dependency only if:

1. static linkage fails functionally or legally;
2. code duplication across multiple shared artifacts is significant and measured;
3. Android's library packaging requires a separately loadable dependency;
4. symbol isolation cannot be achieved reliably with static archives;
5. upstream CPython Android compatibility requires the namespaced shared form;
6. independent security servicing is an explicit release requirement that outweighs added complexity.

### Per-dependency decisions

A single global policy is not required.

```text
OpenSSL  -> static or private shared
SQLite   -> static or private shared
libffi   -> static or private shared
zlib     -> static or public NDK, by explicit decision
```

Each decision records size, loading behavior, symbols, license implications, and update strategy.

## 6. Combination matrix

| Interpreter topology | Dependency topology | Status |
|---|---|---|
| Static interpreter + shared libpython available | Static dependencies | **Priority 1 baseline** |
| Shared-libpython-primary | Static dependencies | First fallback candidate if libpython duplication is real |
| Static interpreter | Private shared dependencies | Possible but normally adds complexity without solving libpython topology |
| Shared-libpython-primary | Private shared dependencies | Most modular and app-like; furthest from Astral baseline |

## 7. Standard-library extension mode remains separate

Examples:

```text
built-in _ssl + static OpenSSL
shared _ssl.so + static OpenSSL
shared _ssl.so + private libssl_python.so
built-in _ssl + private libssl_python.so
```

The module may need to be shared for a CPython reason even if OpenSSL remains static, and vice versa.

## 8. Decision record template

```markdown
# Decision: <title>

## Baseline
## Reproducible Android failure
## Minimal reproducer
## Alternatives tested
## Astral divergence
## Android/CPython authority
## Runtime and archive impact
## Termux/adb/root impact
## Direct-extraction impact
## APK impact — advisory only before Priority 4
## Test additions
## Decision and rollback condition
```

## 9. Current decision

```text
Use Astral baseline first.
Do not adopt shared-libpython-primary preemptively.
Do not adopt private lib*_python.so bundles preemptively.
Keep both as measured fallback options.
Do not let APK convenience alone trigger either change.
```

## References

- [`build-cpython.sh`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-cpython.sh)
- [python-build-standalone technical notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)
- [CPython Android embedding model](https://docs.python.org/3.14/using/android.html)
