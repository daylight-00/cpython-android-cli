# 01 — A1: Preserved Build and Release Architecture

## 1. Classification

**Class:** A — preserve Astral as-is.  
**Goal:** retain the build graph, target metadata, dependency ownership, output artifacts, metadata, profiles, and release transformation before making Android-specific changes.

## 2. Repository and orchestration shape

The Bionic project SHOULD preserve the recognizable Astral layering:

```text
build.py
    |
    v
cpython-unix/build-main.py
    |
    +--> target settings
    +--> dependency needs
    +--> toolchain/build environment
    +--> Makefile dependency graph
    `--> archive production
```

Recommended repository shape:

```text
project/
├── build.py
├── cpython-unix/
│   ├── build-main.py
│   ├── build.py
│   ├── Makefile
│   ├── targets.yml
│   ├── extension-modules.yml
│   ├── build-cpython.sh
│   ├── build-openssl-*.sh
│   ├── build-sqlite.sh
│   ├── build-libffi.sh
│   ├── build-zlib.sh
│   └── patches/
├── pythonbuild/
│   ├── buildenv.py
│   ├── cpython.py
│   ├── downloads.py
│   └── utils.py
├── src/
├── tests/
└── docs/
```

Android-specific helpers may be added, but the Bionic target SHOULD remain inside this structure rather than creating an unrelated build system.

### Source anchors

- [`build.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/build.py)
- [`cpython-unix/build-main.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-main.py)
- [`cpython-unix/build.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build.py)
- [`cpython-unix/Makefile`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/Makefile)

## 3. Target-driven build model

The target definition remains declarative. The build pipeline should not infer critical compatibility policy from the host environment.

The target record owns:

```text
supported Python versions
supported build hosts
toolchain identity
compiler and linker configuration
dependency needs
optimization capabilities
platform-specific policy flags
```

Android fields are B adaptations, but the target-driven model itself is A.

## 4. Dependency graph and ownership

Astral builds each native dependency as an explicit input artifact to the CPython build. The Bionic project MUST preserve this model.

```text
source archive + checksum
        |
        v
isolated dependency build
        |
        v
versioned target artifact
        |
        v
CPython build dependency prefix
```

Conceptual outputs:

```text
openssl-<version>-<target>-<options>.tar
sqlite-<version>-<target>-<options>.tar
libffi-<version>-<target>-<options>.tar
zlib-<version>-<target>-<options>.tar
```

The final CPython target depends on all required dependency artifacts. This prevents accidental linkage to host or Termux packages and makes source/version provenance explicit.

### Source anchors

- [`cpython-unix/Makefile`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/Makefile)
- [`pythonbuild/downloads.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/pythonbuild/downloads.py)

## 5. Canonical full archive

The full `.tar.zst` archive remains the canonical build output.

```text
python/
├── PYTHON.json
├── build/
│   ├── CPython core object files
│   ├── extension-module object files
│   ├── static native dependency libraries
│   ├── generated Setup files
│   └── downstream relinking data
├── install/
│   └── working self-contained Python installation
└── licenses/
```

This is not merely a debug artifact. It is the authoritative downstream-consumer interface for:

- custom built-in extension sets;
- embedding;
- alternate launchers;
- stripped or specialized runtime packages;
- later APK packaging;
- inspection of exact linkage and licenses.

The Android project SHOULD not invent a separate SDK artifact unless the full archive proves insufficient.

## 6. `PYTHON.json`

`PYTHON.json` remains the canonical machine-readable metadata file.

It SHOULD continue to describe:

- Python implementation, version, ABI, and platform tag;
- target triple and build options;
- executable and installation paths;
- extension suffixes;
- `libpython` static/shared artifacts;
- core and extension object files;
- link requirements;
- enabled modules and their build modes;
- licensing and source provenance.

Android-specific metadata is added by schema extension, not by replacing `PYTHON.json` with an unrelated manifest.

Example extension:

```json
{
  "target_triple": "aarch64-linux-android",
  "android": {
    "abi": "arm64-v8a",
    "api_min": 24,
    "ndk_version": "<pinned>",
    "page_size_max": 16384
  }
}
```

The exact schema addition is B/C work. Keeping one canonical metadata surface is A.

## 7. Install-only transformations

The release process preserves Astral's transformation:

```text
full archive: python/install/*
                  |
                  v
install-only: python/*
```

Everything outside `python/install/*` is omitted.

Required flavors:

```text
full.tar.zst
install_only.tar.gz
install_only_stripped.tar.gz
```

The install-only archive is the primary user-facing direct-extraction artifact. The full archive is the build and downstream-integration artifact.

## 8. Build profiles

The option model remains:

```text
debug
noopt
lto
pgo
pgo+lto
```

Meaning:

- `debug`: pydebug and low compiler optimization, intended for diagnostics;
- `noopt`: baseline release build without PGO or LTO, not synonymous with `-O0`;
- `lto`: baseline release with link-time optimization;
- `pgo`: profile-guided optimization;
- `pgo+lto`: both optimization systems.

Install-only release selection SHOULD preserve the Astral preference order:

```text
pgo+lto > pgo > lto > noopt
```

Android may initially support only `noopt` and `debug`, then promote LTO and PGO after target execution infrastructure exists. The profile vocabulary and archive semantics stay unchanged.

## 9. Pinned packaging tools

The build SHOULD preserve Astral's distribution-owned pip policy:

```text
CPython configure: --without-ensurepip
build inputs: pinned pip wheel
build step: install pinned pip into the installation prefix
```

This makes the runtime's pip version part of the distribution release rather than an incidental CPython source payload.

## 10. Release identity and provenance

Each release SHOULD record:

```text
CPython version and source hash
project release identifier
Astral reference snapshot
NDK version
minimum Android API level
CPU ABI
build profile
free-threaded/debug variants
native dependency versions and hashes
patch-set identity
archive checksums
license inventory
reproducibility status
```

Naming may add Android API information, but metadata remains authoritative:

```text
cpython-3.14.x+<release>-aarch64-linux-android-api24-noopt-full.tar.zst
```

## 11. Acceptance criteria for A1

A1 is preserved only when:

- the Bionic target is invoked through the same top-level build interface;
- dependencies are explicit graph inputs rather than host packages;
- the full archive is canonical;
- install-only artifacts are derived mechanically from the full archive;
- `PYTHON.json` remains the authoritative build description;
- build profiles use the Astral vocabulary;
- pip and dependency versions are release-owned;
- no Android convenience layer bypasses the canonical archive pipeline.

## References

- [Python Standalone Builds](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [Building](https://gregoryszorc.com/docs/python-build-standalone/main/building.html)
- [Distribution Archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [Astral source snapshot](https://github.com/astral-sh/python-build-standalone/tree/2ff9048dc5a193564016765d530a63de7cbed770)
