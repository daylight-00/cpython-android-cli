# Astral-Like Android/Bionic Standalone CPython: ABCD Implementation Plan

**Status:** architecture and implementation planning baseline  
**Date:** 2026-07-18  
**Primary reference:** Astral `python-build-standalone` and uv managed-Python behavior  
**Platform authority:** CPython Android support and the Android NDK public ABI

This document set converts the project discussion into an implementation classification and priority plan.

## Project priorities

1. **Astral-official-like Bionic standalone.** Follow Astral's philosophy, build structure, artifact model, extension model, dependency ownership, metadata, and release engineering as closely as Android permits.
2. **Android/Bionic-native, not Termux-overfitted.** Termux is the primary practical host, but the core runtime contract is Android/Bionic rather than Termux `$PREFIX` or Termux package ABI.
3. **Direct extraction and use.** An untouched runtime archive must run after extraction to any suitable final path, without uv or an installer being required to repair the core runtime.
4. **APK consumption.** APK integration is valuable but deferred. It must consume the established core build lineage rather than shaping the first standalone architecture.

The first priority is implemented through three classes of work:

```text
Priority 1: Astral-like Bionic standalone

A. Preserve Astral implementation and contracts as-is
B. Preserve the Astral responsibility, but adapt its implementation for Android
C. Add Android-only infrastructure where Astral has no equivalent component
```

The later priorities add independent work:

```text
Priority 2: D2 — prove and deliver Android-native multi-context use
Priority 3: D3 — strengthen the direct-extraction contract
Priority 4: D4 — package the established core for APK consumers
```

## Canonical dependency order

```text
A: preserved Astral architecture
        |
B: Android adaptations
        |
C: Android-only infrastructure
        |
        v
Astral-like Bionic standalone  [Priority 1]
        |
        +--> D2: Termux / adb / root / uv delivery  [Priority 2]
        |
        +--> D3: extract-anywhere runtime contract  [Priority 3]
        |
        `--> D4: APK packaging and embedding         [Priority 4]
```

Priority 4 is deliberately downstream. APK requirements may reveal useful constraints, but they do not justify changing the initial `libpython` topology or native-dependency linkage policy before the Astral baseline has been built and tested.

## Document map

| Document | Scope |
|---|---|
| [00 — Priority and Classification Model](00-priority-and-classification-model.md) | Defines A/B/C/D, precedence, scope, and how to classify future work. |
| [01 — A1: Preserved Build and Release Architecture](01-a1-preserved-build-and-release-architecture.md) | Astral orchestration, target metadata, dependency graph, archive flavors, `PYTHON.json`, profiles, and release model retained as-is. |
| [02 — A2: Preserved Extension, Linkage, and Dependency Model](02-a2-preserved-extension-linkage-and-dependency-model.md) | Astral's generated `Setup.local`, static-first stdlib extensions, static dependency closure, `libpython` baseline, and pinned pip policy. |
| [03 — B1: Android Toolchain, ABI, and Build Adaptation](03-b1-android-toolchain-abi-and-build-adaptation.md) | NDK materialization, Bionic target metadata, API floor, compiler/linker flags, system-library boundary, and dependency cross-builds. |
| [04 — B2: CPython Runtime, Module, and Loader Adaptation](04-b2-cpython-runtime-module-and-loader-adaptation.md) | Android configure answers, CPython patches, module availability, loader-relative paths, sysconfig normalization, scripts, certificates, and terminal data. |
| [05 — C: Android-Only Infrastructure](05-c-android-only-infrastructure.md) | ADB/device runners, PGO collection, API metadata, ELF/API verification, device matrix, and Android wheel validation. |
| [06 — D2: Priority 2 Multi-Context Delivery](06-d2-priority-2-android-native-multi-context-delivery.md) | Termux independence, direct Termux, adb, root, uv integration, and context-neutral runtime defaults. |
| [07 — D3: Priority 3 Direct-Extraction Contract](07-d3-priority-3-direct-extraction-contract.md) | Exact relocation guarantee, zero-fixup runtime, path discovery, runtime data, sysconfig scope, and path test matrix. |
| [08 — D4: Deferred APK Integration](08-d4-priority-4-deferred-apk-integration.md) | APK as a fourth-priority consumer, allowed repackaging, embedding testbed, and rules preventing APK concerns from distorting the baseline. |
| [09 — Decision Gates: `libpython` and Native Dependencies](09-decision-gates-libpython-and-native-dependencies.md) | Baseline versus fallback choices for static-interpreter/shared-libpython and static versus private shared dependencies. |
| [10 — Implementation Sequence and Acceptance Gates](10-implementation-sequence-and-acceptance-gates.md) | Ordered stages, artifacts, experiments, promotion gates, and stop conditions. |
| [References](REFERENCES.md) | Consolidated primary references and source-code snapshot anchors. |
| [Module Review Notes](REVIEW-NOTES.md) | Independent review and cross-document consistency results. |

## Normative language

- **MUST** means a release or architecture requirement.
- **SHOULD** means the default unless evidence justifies a documented exception.
- **MAY** means optional behavior that must not weaken higher-priority guarantees.
- **Baseline** means the first architecture attempted because it most closely follows Astral.
- **Fallback** means a change adopted only after a recorded Android-specific failure or incompatibility.

## Source snapshot

The Astral source-code links in this set are pinned to repository commit `2ff9048dc5a193564016765d530a63de7cbed770`, observed on 2026-07-18. Documentation links point to the current `main` documentation unless a versioned CPython reference is more appropriate.
