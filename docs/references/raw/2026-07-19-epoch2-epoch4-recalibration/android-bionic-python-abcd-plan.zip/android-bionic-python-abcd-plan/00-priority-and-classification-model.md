# 00 — Priority and Classification Model

## 1. Purpose

This document defines how project work is classified and ordered. The purpose is to prevent lower-priority goals—especially Termux convenience or APK embedding—from silently changing the first Bionic standalone architecture before the Astral baseline has been tested.

## 2. Ordered priorities

### Priority 1 — Astral-official-like Bionic standalone

The first deliverable is a Bionic target that behaves like a plausible Astral-maintained standalone distribution.

This means preserving, wherever Android permits:

- self-contained and highly portable distribution goals;
- minimized host runtime dependencies;
- pinned source inputs and deterministic dependency ownership;
- target-driven build configuration;
- generated extension configuration rather than ad hoc manual module lists;
- static-first standard-library extension policy;
- full, install-only, and stripped install-only artifacts;
- rich machine-readable metadata;
- debug, baseline, LTO, PGO, and PGO+LTO build variants;
- downstream relinking and repackaging support;
- uv-compatible managed-Python consumption as a later integration path.

Astral states that its distributions are self-contained, highly portable, include most standard-library extension modules, and either distribute or statically link their library dependencies. It also treats the full archive as a downstream-repackaging SDK rather than only a runnable Python installation.

### Priority 2 — Android/Bionic-native and not Termux-overfitted

The core runtime contract is:

```text
Android kernel
+ Android dynamic linker
+ Bionic
+ public NDK APIs available at the declared API floor
+ declared CPU ABI
```

It is not:

```text
Termux application
+ Termux $PREFIX
+ Termux package database
+ Termux-provided libssl/libsqlite/libffi
```

This priority requires proof through clean Android contexts, not only a claim based on compiler flags.

### Priority 3 — direct extraction at the final path

An untouched runtime archive must be usable after extraction to a suitable executable path. The project does not require already-mutated virtual environments or generated scripts to remain movable.

```sh
tar -xf cpython-android.tar.gz
./python/bin/python3 -c 'import ssl, sqlite3, ctypes'
```

The direct runtime must not depend on uv performing path fixups.

### Priority 4 — APK consumption

APK integration is downstream and deferred.

It must:

- reuse the established CPython source, patch set, dependency versions, module policy, and provenance;
- consume the full archive or another output from the same core build;
- permit Android-specific repackaging into `jniLibs`, assets, or app-private files;
- avoid forcing an APK-optimized runtime topology into the initial CLI standalone without evidence.

It does not initially require the shell tarball and APK payload to be byte-identical.

## 3. Work classes

### A — Preserve Astral as-is

Use A when Android can use the same design and substantially the same implementation or data contract.

Typical A items:

- top-level build CLI and option grammar;
- target-driven configuration;
- dependency source pinning and per-dependency build artifacts;
- `extension-modules.yml` as canonical module metadata;
- generated `Modules/Setup.local`;
- static-first standard-library extensions;
- static native-dependency closure;
- full/install-only archive model;
- `PYTHON.json`;
- build profiles and release selection order;
- pinned pip wheel installed by the distribution build.

### B — Adapt an existing Astral responsibility for Android

Use B when Astral already has the responsibility, but its Linux/macOS implementation is not valid for Android.

Typical B items:

- target definition with Android ABI and API floor;
- toolchain materialization using the NDK;
- Android compiler and linker flags;
- public system-library allowlist;
- cross-compile configure answers;
- Bionic and Android CPython patches;
- Android module availability conditions;
- Android dynamic-loader-relative lookup;
- Android sysconfig and launcher normalization.

### C — Build Android-only infrastructure

Use C when Android support needs a component for which Astral desktop targets have no equivalent abstraction.

Typical C items:

- target execution through ADB or a managed emulator;
- target-side PGO profile collection;
- API-level metadata and compatibility auditing;
- Android ELF verifier;
- minimum/maximum API device matrix;
- Android wheel and native-extension validator.

### D — Add lower-priority delivery guarantees after Priority 1

D is split by user priority:

```text
D2 — Priority 2: multi-context Android delivery and Termux independence
D3 — Priority 3: strong direct-extraction behavior
D4 — Priority 4: APK packaging and embedding
```

## 4. Classification decision tree

```text
Does Astral already implement the same responsibility?
|
+-- No --> Is it required to build/test an Android target itself?
|          |
|          +-- Yes --> C
|          `-- No  --> D2, D3, or D4 according to the user priority
|
`-- Yes --> Can Android use the same implementation and contract?
           |
           +-- Yes --> A
           `-- No  --> B
```

## 5. Precedence rules

1. Android public ABI and security rules override every implementation preference.
2. Official CPython Android behavior is the first platform-port reference.
3. Astral architecture is authoritative for standalone distribution design.
4. Termux is a porting and operational reference, not the runtime ABI.
5. APK convenience cannot override Priority 1–3 without an explicit decision record.

## 6. Architecture-change rule

A baseline decision may be changed only when all of the following exist:

1. a reproducible Android-specific failure;
2. a minimal test demonstrating the failure;
3. evidence that an A or B implementation cannot reasonably solve it;
4. comparison of the proposed alternative against Astral behavior;
5. regression tests preserving all higher-priority guarantees.

This rule applies especially to:

- `shared-libpython-primary`;
- private `lib*_python.so` dependency bundles;
- APK-driven directory layouts;
- Termux-specific launch wrappers;
- runtime path fixups performed by uv.

## 7. Scope exclusions

The following are outside the initial guarantees:

- moving a used installation after packages or virtual environments are created;
- preserving generated console-script shebangs after such a move;
- treating `/sdcard` or emulated shared storage as a supported executable prefix;
- private Android platform libraries as stable dependencies;
- system-partition installation;
- GUI/X11/Tk as part of the first core flavor;
- APK distribution before the CLI core and direct-extraction model stabilize.

## References

- [Python Standalone Builds](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [Distribution Archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [uv: Python versions](https://docs.astral.sh/uv/concepts/python-versions/)
- [CPython 3.14: Using Python on Android](https://docs.python.org/3.14/using/android.html)
- [Android NDK: Native APIs](https://developer.android.com/ndk/guides/stable_apis)
