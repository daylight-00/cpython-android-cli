# 02 — A2: Preserved Extension, Linkage, and Dependency Model

## 1. Classification

**Class:** A — preserve Astral as-is.  
**Goal:** begin with Astral's current Unix extension and dependency topology before adopting Android-oriented alternatives.

This module intentionally separates three independent axes:

```text
Axis 1: Does the interpreter statically or dynamically consume libpython?
Axis 2: Is a Python stdlib extension built-in or a shared extension object?
Axis 3: Is the extension's native dependency static or a private shared library?
```

Conflating these axes causes premature architecture changes.

## 2. Canonical extension metadata

Astral treats `cpython-unix/extension-modules.yml` as canonical module metadata.

It records, per extension:

- source files;
- conditional sources by Python version and target;
- include paths and dependency include roots;
- library links;
- target-specific defines;
- disabled targets;
- required targets;
- build mode: static, shared, or shared-or-disabled;
- license/link metadata propagated into `PYTHON.json`.

The Bionic target MUST extend this metadata rather than maintain an unrelated hardcoded module list.

### Source anchors

- [`extension-modules.yml`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/extension-modules.yml)
- [`pythonbuild/cpython.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/pythonbuild/cpython.py)

## 3. Generated `Modules/Setup.local`

The builder derives `Modules/Setup.local` from extension metadata and validates that its metadata remains synchronized with CPython's own `Modules/Setup`, `Setup.bootstrap.in`, and `config.c.in` declarations.

This gives two important properties:

1. module policy is machine-readable and target-conditional;
2. CPython upgrades fail loudly when extension metadata becomes incomplete or inconsistent.

The Bionic build SHOULD preserve this validation and generation process. An Android-specific `Setup.local` may exist only as generated output.

## 4. Static-first standard-library extension policy

Astral's default extension mode is effectively static unless a module explicitly declares another mode.

Baseline Bionic policy:

```text
CPython core/builtin modules               -> built-in
most standard-library C extensions        -> built-in/static
modules requiring shared behavior         -> shared
third-party extensions installed by users -> shared loading supported
```

Examples expected to be built-in when available:

```text
_ssl
_hashlib
_sqlite3
_ctypes
zlib
_bz2
_lzma
pyexpat
_decimal
_socket
_multiprocessing
```

This is a baseline, not an unconditional final list. B adaptation may disable modules unavailable or inappropriate on Android.

## 5. Static native-dependency closure

Astral's Unix build removes most shared dependency libraries from the dependency prefix before building CPython, forcing extensions to resolve against static archives.

Conceptually:

```text
_ssl / _hashlib
    `--> libssl.a + libcrypto.a

_sqlite3
    `--> libsqlite3.a

_ctypes
    `--> libffi.a

zlib
    `--> libz.a
```

This minimizes runtime `DT_NEEDED` entries and prevents an installation from accidentally selecting the host's OpenSSL, SQLite, or libffi.

The Bionic baseline SHOULD therefore use pinned static dependency closure for:

- OpenSSL;
- SQLite;
- libffi;
- zlib;
- bzip2;
- xz/liblzma;
- expat;
- mpdecimal;
- zstd;
- line-editing/terminal libraries if included.

## 6. Astral `libpython` baseline

Current Astral Unix builds use a hybrid topology:

```text
python executable
`--> libpython code statically linked into the executable

archive also contains
`--> shared libpython for embedders and compatibility consumers
```

The build combines a shared libpython build with a configuration that statically links libpython into the interpreter.

Priority 1 therefore begins with this topology on Bionic.

It MUST NOT begin by assuming that `shared-libpython-primary` is required merely because APK embedding exists as Priority 4.

## 7. Baseline process topology

```text
bin/python3
├── CPython core code
├── built-in stdlib extension code
└── static native dependency code

lib/libpython3.x.so
└── shared libpython artifact for downstream consumers
```

Potential shared stdlib extension modules remain under:

```text
lib/python3.x/lib-dynload/*.so
```

Third-party native extensions remain dynamically loadable.

## 8. Why the baseline is valuable on Android

Static-first dependency closure offers:

- minimal dependency-file count;
- no Termux package-library runtime dependency;
- reduced Android linker search complexity;
- reproducible OpenSSL/SQLite/libffi versions;
- strong direct-extraction behavior;
- fewer native library name collisions;
- close architectural parity with the primary reference.

The baseline must be tested rather than replaced preemptively.

## 9. Known pressure points

The Astral baseline may need Android-specific changes if experiments demonstrate:

- a third-party extension causes a second shared libpython instance to enter the process and uses inconsistent runtime state;
- Android's loader/linker rules make the static-interpreter/shared-libpython hybrid unsafe;
- required standard-library modules cannot be built-in because of Android dynamic loading constraints;
- a native dependency cannot safely be statically linked or exported-symbol isolation cannot be enforced;
- APK packaging cannot use the shared libpython artifact produced by the baseline without rebuilding the core.

These are decision gates, not assumptions.

## 10. Symbol isolation

Static native libraries linked into CPython artifacts SHOULD be hidden from the public dynamic symbol surface where possible.

Controls include:

```text
-fvisibility=hidden
-Wl,--exclude-libs,ALL
version scripts or explicit export lists
no undefined symbols for shared objects
```

Only CPython API symbols and required initialization symbols should be exported. This reduces conflicts if an app or extension contains another OpenSSL/SQLite implementation.

## 11. Pinned pip and launcher distinction

`pip` is Python code installed from a pinned wheel. Generated launcher scripts are a separate portability issue.

The core distribution MUST support:

```sh
python -m pip
```

A `pip` executable MAY be provided after Android shebang/launcher behavior is solved, but it is not required to define the underlying packaging capability.

## 12. Acceptance criteria for A2

- `extension-modules.yml` remains canonical.
- `Setup.local` is generated and checked against the selected CPython source.
- default stdlib extension mode remains static/built-in.
- native feature dependencies come from project-owned static archives.
- the initial interpreter topology matches Astral's static-interpreter/shared-libpython hybrid.
- shared third-party extensions remain supported and tested.
- alternatives are introduced only through the decision gates in document 09.

## References

- [Technical Notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)
- [Distribution Archives: `PYTHON.json` build information](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [`build-cpython.sh`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-cpython.sh)
- [`extension-modules.yml`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/extension-modules.yml)
- [`pythonbuild/cpython.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/pythonbuild/cpython.py)
