# Module Review Notes

## 1. Review method

Each module was reviewed independently against:

- the four-priority order;
- the A/B/C/D classification rule;
- the primary-reference requirement;
- separation of Android/Bionic nativeness from Termux integration;
- separation of fresh extraction from post-install portability;
- isolation of APK concerns as Priority 4;
- baseline-versus-fallback discipline for `libpython` and native dependencies;
- consistency of artifact, metadata, and validation contracts.

## 2. README

**Result:** Pass.

The index presents A+B+C as Priority 1 and separates D2, D3, and D4. APK is visibly downstream and cannot appear to be a coequal first consumer.

## 3. 00 — Priority and Classification Model

**Result:** Pass after strengthening.

Changes made during review:

- added a classification decision tree;
- separated D2/D3/D4 rather than treating all consumers as one layer;
- added an architecture-change evidence rule;
- made APK-driven topology changes explicitly non-authoritative before Priority 4.

## 4. 01 — A1 Preserved Build and Release Architecture

**Result:** Pass.

The module preserves Astral's orchestration, target-driven graph, dependency artifacts, canonical full archive, install-only transformation, `PYTHON.json`, profiles, and pinned pip policy. It does not contain Android-specific implementation details beyond examples of later metadata extension.

## 5. 02 — A2 Preserved Extension, Linkage, and Dependency Model

**Result:** Pass after correction of earlier assumptions.

The module establishes the actual Astral baseline:

```text
static interpreter
+ shared libpython artifact
+ static-first stdlib extensions
+ static native dependency closure
```

`shared-libpython-primary` and private `lib*_python.so` are not presented as defaults.

## 6. 03 — B1 Android Toolchain, ABI, and Build Adaptation

**Result:** Pass.

The NDK, Bionic, API floor, public native ABI, and dependency cross-builds are treated as alternate implementations of existing Astral responsibilities. The module excludes GUI dependencies and avoids Termux toolchain paths.

## 7. 04 — B2 CPython Runtime, Module, and Loader Adaptation

**Result:** Pass with documented open areas.

The module preserves Astral's responsibilities for module metadata, getpath, sysconfig, launchers, certificates, and terminfo while identifying Android-specific implementations. Certificate and terminal-data policies remain engineering work but have explicit release requirements.

## 8. 05 — C Android-Only Infrastructure

**Result:** Pass.

The module contains only components that desktop-oriented Astral targets do not already provide: ADB execution, target PGO collection, API-level validation, Android ELF auditing, device matrix, and Android wheel smoke tests.

## 9. 06 — D2 Priority 2 Multi-Context Delivery

**Result:** Pass.

The module excludes APK, focuses on direct Termux/adb/root and uv-managed Termux, and treats Termux independence as a verified runtime property. Optional deployment helpers cannot modify the core.

## 10. 07 — D3 Priority 3 Direct-Extraction Contract

**Result:** Pass.

The guarantee is exactly the requested level: untouched archive, arbitrary suitable final extraction path, immediate core use. It does not promise movement of a mutated installation. Runtime and SDK relocatability are separately gated.

## 11. 08 — D4 Deferred APK Integration

**Result:** Pass after reducing scope and authority.

APK is explicitly fourth priority. It consumes the full archive/core lineage and may repackage it, but cannot preemptively force shared-libpython-primary, private shared dependencies, or an app-specific install-only layout.

## 12. 09 — Decision Gates

**Result:** Pass.

The three independent topology axes are clearly separated. Trigger conditions require reproducible Android failures and comparison data. APK preference alone cannot promote a fallback.

## 13. 10 — Implementation Sequence

**Result:** Pass.

The sequence builds the Astral skeleton, Android dependencies, baseline CPython, target infrastructure, Priority 2 delivery, Priority 3 relocation, optimizations, SDK maturity, and finally APK. The first public release does not require APK support.

## 14. Cross-document consistency findings

1. **Astral remains primary.** A decisions form the baseline and are changed only by Android evidence.
2. **Android authority remains mandatory.** B and C implement NDK/Bionic requirements without redefining the standalone philosophy.
3. **Termux is not the ABI.** No core contract includes `$PREFIX` or Termux package libraries.
4. **uv is preferred but optional.** It manages the artifact after direct runtime correctness exists.
5. **Relocation is narrowly and consistently defined.** Fresh extraction is guaranteed; post-mutation movement is excluded.
6. **APK is Priority 4.** It is absent from Priority 2, downstream in the sequence, and barred from preemptive topology decisions.
7. **`libpython` and dependency linkage remain evidence-gated.** Baseline and fallback architectures are consistent across all modules.
8. **One core lineage does not require one packaging container.** Termux/adb/root share the install-only archive; APK may repackage full-archive outputs.
9. **Wheel work is not confused with core execution.** Android wheel validation is infrastructure/SDK work and must avoid Termux runtime coupling.

## 15. Items that must not be silently changed

- replacing the Astral baseline before it is tested;
- making uv necessary for interpreter startup;
- linking the core against Termux libraries;
- treating APK as a first-priority architecture authority;
- defining relocatable as movement of used venvs;
- relying on private Android platform libraries;
- adopting shared-libpython-primary without a decision record;
- adopting private `lib*_python.so` globally without per-dependency evidence;
- publishing an Android native wheel as `manylinux` or generic glibc Linux.
