# 03 — B1: Android Toolchain, ABI, and Build Adaptation

## 1. Classification

**Class:** B — retain the Astral responsibility, replace the platform-specific implementation.  
**Scope:** target description, NDK toolchain, API floor, build isolation, compiler/linker policy, public native ABI boundary, and cross-building native dependencies.

## 2. Target identity

The GNU-style target triple remains:

```text
aarch64-linux-android
```

Android compatibility requires independent metadata:

```text
android_abi     = arm64-v8a
android_api_min = 24
libc            = bionic
ndk_version     = <pinned version>
```

The API floor must not be encoded only in the compiler executable name or archive filename. It is a first-class compatibility axis recorded in target settings and `PYTHON.json`.

## 3. Proposed target record

```yaml
aarch64-linux-android:
  host_platforms:
    - linux_x86_64
    - linux_aarch64
    - macos_arm64

  pythons_supported:
    - "3.14"

  target_kind: android-ndk
  android_abi: arm64-v8a
  android_api_min: 24
  ndk_version: "<pinned>"
  clang_triplet: aarch64-linux-android

  needs:
    - autoconf
    - bzip2
    - expat
    - libffi
    - mpdecimal
    - openssl-3.5
    - sqlite
    - xz
    - zlib
    - zstd

  openssl_target: android-arm64
```

GUI/X11/Tk dependencies are not part of the first target need-set.

## 4. NDK toolchain materialization

Astral's responsibility is to provide an isolated, controlled compiler and sysroot. Android implements that responsibility through a pinned NDK.

The toolchain provider derives:

```text
AR      = <ndk>/toolchains/llvm/prebuilt/<host>/bin/llvm-ar
AS      = <ndk>/toolchains/llvm/prebuilt/<host>/bin/llvm-as
CC      = <ndk>/.../bin/aarch64-linux-android<API>-clang
CXX     = <ndk>/.../bin/aarch64-linux-android<API>-clang++
NM      = <ndk>/.../bin/llvm-nm
RANLIB  = <ndk>/.../bin/llvm-ranlib
READELF = <ndk>/.../bin/llvm-readelf
STRIP   = <ndk>/.../bin/llvm-strip
```

The official CPython Android build follows this pattern and first produces a build-machine Python before building the Android target Python.

### Source anchors

- [CPython `Android/README.md` at v3.14.6](https://github.com/python/cpython/blob/v3.14.6/Android/README.md)
- [CPython `Android/android-env.sh` at v3.14.6](https://github.com/python/cpython/blob/v3.14.6/Android/android-env.sh)

## 5. Build isolation

The Astral build-environment abstraction remains, but it installs:

```text
host build tools
pinned Android SDK command-line tools if needed
pinned NDK
dependency build prefix
host/bootstrap CPython
target source and build trees
```

Host `/usr/include`, Homebrew, Termux `$PREFIX`, or arbitrary `pkg-config` search paths must not leak into target compilation.

Recommended environment controls:

```text
PKG_CONFIG_LIBDIR=<target dependency prefix>/lib/pkgconfig
PKG_CONFIG_SYSROOT_DIR=<target sysroot or empty by policy>
PATH=<pinned tools only>
CC/CXX/AR/RANLIB/READELF/STRIP explicitly set
```

## 6. Compiler and linker baseline

A starting policy derived from official CPython Android and Android NDK constraints:

```text
CFLAGS:
  -fPIC
  -fvisibility=hidden
  -fstack-protector-strong
  -D__BIONIC_NO_PAGE_SIZE_MACRO

LDFLAGS:
  -Wl,--build-id=sha1
  -Wl,--no-rosegment
  -Wl,-z,max-page-size=16384
  -Wl,-z,relro
  -Wl,-z,now
  -Wl,--no-undefined
```

`-lm` must be supplied where package build systems omit it, because Android is less permissive than many desktop Linux builds about unresolved mathematical symbols.

Every flag must be tested against the pinned NDK and API floor. The target configuration owns these flags; individual dependency scripts should not independently invent incompatible policy.

## 7. Public system-library boundary

The distribution may rely only on public NDK libraries available at the declared API floor.

Conservative initial allowlist:

```text
libc.so
libm.so
libdl.so
```

Additional public NDK libraries are added only when a feature requires them and the dependency is recorded in metadata.

Linux names such as `libpthread`, `librt`, `libutil`, or `libcrypt` must not be copied into the Android allowlist. Bionic provides different library boundaries, and some functions live in `libc`.

Private libraries found under Android system partitions are not valid dependencies merely because a particular device exposes them.

## 8. API-floor enforcement

The selected compiler launcher and NDK headers protect against accidental references to APIs newer than `android_api_min`, but this is not sufficient by itself.

Release validation must inspect:

- strong undefined symbol references;
- `DT_NEEDED` libraries unavailable at the API floor;
- weak/new API behavior where used;
- device/emulator loading at the minimum API.

Android's loader resolves strong references at load time. A symbol newer than the minimum API can prevent startup before the code path is executed.

## 9. Native dependency cross-build contract

Each Astral dependency script retains the same input/output responsibility but receives Android implementations for:

```text
configure host/target
NDK compiler variables
Android feature tests
static/PIC archive production
pkg-config metadata
license capture
path normalization
```

Required output shape:

```text
include/
lib/*.a
lib/pkgconfig/*.pc
share/licenses/ or equivalent build metadata
```

### OpenSSL

- use a pinned OpenSSL source version;
- use the appropriate Android Configure target, such as `android-arm64`;
- disable or adjust features unavailable or inappropriate on Android;
- produce PIC static archives for linkage into CPython artifacts;
- record configuration flags and source hash.

### SQLite

- build a project-owned static archive;
- make feature decisions explicit rather than inheriting Termux or system defaults;
- test extension loading policy independently from core SQLite availability.

### libffi

- use official Android/Bionic-compatible configure logic or patches;
- validate closure allocation and executable-memory behavior on actual Android contexts;
- test `ctypes` callbacks, not only `import ctypes`.

### Compression and parser libraries

- build bzip2, xz/liblzma, zlib, expat, mpdecimal, and zstd with NDK tools;
- ensure all produced static objects are PIC when they may enter shared libpython or shared extensions;
- prevent host `pkg-config` contamination.

## 10. Host and target Python

The build-machine Python and Android target Python remain separate products.

```text
host/build Python
    |
    +--> freezing and generated-code steps
    +--> metadata scripts using target sysconfig data
    `--> build orchestration

Android target Python
    `--> final distribution
```

Official CPython Android already models this split. Astral's cross-build patches and metadata generation can be reused where platform-neutral.

## 11. Initial scope

First target:

```text
CPython 3.14.x
aarch64-linux-android
arm64-v8a
API 24 baseline
GIL build
noopt and debug
static dependency closure
no Tk/X11
```

Additional ABIs, free-threaded builds, and higher/lower API floors are not needed to validate the architecture.

## 12. Acceptance criteria for B1

- the NDK version and API floor are pinned and recorded;
- all target code is compiled through the NDK toolchain;
- host and Termux include/library paths are absent;
- only public NDK libraries are allowed as host dependencies;
- native dependencies are project-built static artifacts;
- minimum-API load tests pass;
- target and dependency build metadata are reproducible and auditable.

## References

- [CPython Android README](https://github.com/python/cpython/blob/v3.14.6/Android/README.md)
- [CPython Android environment](https://github.com/python/cpython/blob/v3.14.6/Android/android-env.sh)
- [Android NDK: Native APIs](https://developer.android.com/ndk/guides/stable_apis)
- [Android NDK: Using newer APIs](https://developer.android.com/ndk/guides/using-newer-apis)
- [Android NDK build-system maintainer guidance](https://android.googlesource.com/platform/ndk/+/master/docs/BuildSystemMaintainers.md)
