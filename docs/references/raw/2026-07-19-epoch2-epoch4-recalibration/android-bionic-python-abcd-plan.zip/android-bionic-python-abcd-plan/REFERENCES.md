# References

## 1. Source snapshot policy

The Astral source-code anchors in this documentation are pinned to:

```text
repository: astral-sh/python-build-standalone
commit:     2ff9048dc5a193564016765d530a63de7cbed770
observed:   2026-07-18
```

CPython Android source anchors use the `v3.14.6` tag where possible. Android and uv documentation links refer to their current official documentation as of 2026-07-18.

## 2. Astral `python-build-standalone`

1. [Python Standalone Builds](https://gregoryszorc.com/docs/python-build-standalone/main/)  
   Primary statement of self-contained, highly portable distributions, minimized runtime dependencies, and downstream recombination.
2. [Building](https://gregoryszorc.com/docs/python-build-standalone/main/building.html)  
   Build entry point and profile options.
3. [Distribution Archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)  
   Full archive, `PYTHON.json`, install-only transformation, and optimization preference order.
4. [Running Distributions](https://gregoryszorc.com/docs/python-build-standalone/main/running.html)
5. [Behavior Quirks](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)  
   Build-time paths, uv fixups, launcher and terminfo portability issues.
6. [Technical Notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)  
   Static dependency linkage and `Setup.local` design.
7. [Repository snapshot](https://github.com/astral-sh/python-build-standalone/tree/2ff9048dc5a193564016765d530a63de7cbed770)
8. [`build.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/build.py)
9. [`cpython-unix/build-main.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-main.py)
10. [`cpython-unix/build.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build.py)
11. [`cpython-unix/Makefile`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/Makefile)
12. [`cpython-unix/targets.yml`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/targets.yml)
13. [`cpython-unix/extension-modules.yml`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/extension-modules.yml)
14. [`cpython-unix/build-cpython.sh`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/cpython-unix/build-cpython.sh)
15. [`pythonbuild/cpython.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/pythonbuild/cpython.py)
16. [`pythonbuild/downloads.py`](https://github.com/astral-sh/python-build-standalone/blob/2ff9048dc5a193564016765d530a63de7cbed770/pythonbuild/downloads.py)

## 3. uv

17. [uv documentation](https://docs.astral.sh/uv/)
18. [Python versions](https://docs.astral.sh/uv/concepts/python-versions/)  
    Managed/system Python distinction, downloads, variants, discovery, and Astral CPython distributions.
19. [Installing and managing Python](https://docs.astral.sh/uv/guides/install-python/)
20. [Storage](https://docs.astral.sh/uv/reference/storage/)
21. [Environment variables](https://docs.astral.sh/uv/reference/environment/)
22. [Settings](https://docs.astral.sh/uv/reference/settings/)
23. [Python support policy](https://docs.astral.sh/uv/reference/policies/python/)

## 4. CPython Android

24. [Using Python on Android — Python 3.14](https://docs.python.org/3.14/using/android.html)
25. [CPython Android directory at v3.14.6](https://github.com/python/cpython/tree/v3.14.6/Android)
26. [`Android/README.md`](https://github.com/python/cpython/blob/v3.14.6/Android/README.md)
27. [`Android/android.py`](https://github.com/python/cpython/blob/v3.14.6/Android/android.py)
28. [`Android/android-env.sh`](https://github.com/python/cpython/blob/v3.14.6/Android/android-env.sh)
29. [Android testbed](https://github.com/python/cpython/tree/v3.14.6/Android/testbed)

## 5. Android NDK and Bionic

30. [Android NDK: Native APIs](https://developer.android.com/ndk/guides/stable_apis)
31. [Android NDK: Using newer APIs](https://developer.android.com/ndk/guides/using-newer-apis)
32. [Android NDK documentation](https://developer.android.com/ndk/)
33. [Build-system maintainer guidance](https://android.googlesource.com/platform/ndk/+/master/docs/BuildSystemMaintainers.md)
34. [Android changes for NDK developers](https://android.googlesource.com/platform/bionic/+/master/android-changes-for-ndk-developers.md)
35. [Android 7.0 native linking changes](https://developer.android.com/about/versions/nougat/android-7.0-changes#ndk)

## 6. Python packaging

36. [Platform compatibility tags](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/)
37. [Binary distribution format](https://packaging.python.org/en/latest/specifications/binary-distribution-format/)
38. [Package formats](https://packaging.python.org/en/latest/discussions/package-formats/)

## 7. Termux as a secondary implementation reference

39. [Termux execution environment](https://github.com/termux/termux-packages/wiki/Termux-execution-environment)
40. [Termux packages repository](https://github.com/termux/termux-packages)
41. [Termux CPython recipe](https://github.com/termux/termux-packages/blob/master/packages/python/build.sh)
42. [Termux OpenSSL recipe](https://github.com/termux/termux-packages/tree/master/packages/openssl)
43. [Termux SQLite recipe](https://github.com/termux/termux-packages/tree/master/packages/libsqlite)
44. [Termux libffi recipe](https://github.com/termux/termux-packages/tree/master/packages/libffi)
45. [Termux zlib recipe](https://github.com/termux/termux-packages/tree/master/packages/zlib)

## 8. Reference authority hierarchy

When sources appear to suggest different implementations:

1. Android public ABI and dynamic-loader rules;
2. official CPython Android port behavior;
3. Python packaging specifications;
4. Astral standalone architecture and release engineering;
5. uv managed-Python behavior;
6. Termux recipes as Bionic porting evidence.

This hierarchy does not reduce Astral's role as the primary standalone design reference. It only prevents desktop implementation details from overriding mandatory Android platform contracts.
