# 10 — Open Questions and Phased Plan

## 1. Decisions requiring experiments

### 1.1 `libpython` linkage

Compare:

- CLI linked to a private shared `libpython` that is also APK-consumable;
- statically linked CLI plus separately built embeddable `libpython`.

Decision criteria: relocation reliability, artifact identity, startup, size, embedding, symbol visibility, and maintenance burden.

### 1.2 Third-party dependency linkage

Compare:

- Astral-like static linkage into Python extension modules;
- namespaced private shared libraries.

This is the most important unresolved distribution-policy choice.

### 1.3 Native-extension SDK metadata

Determine whether `_sysconfigdata`, Makefiles, `python-config`, and pkg-config files can be fully relative or dynamically derived. If not, define an optional, uv-independent SDK initialization mechanism.

### 1.4 Android API-level artifact policy

Possible models:

- one conservative minimum-API artifact per ABI;
- multiple API-level artifacts;
- one base artifact with runtime probing for optional APIs.

The model must align with wheel tags and uv artifact selection.

### 1.5 Certificate source

Evaluate:

- bundled Mozilla-compatible CA bundle;
- Android trust-store bridge;
- configurable combined policy.

Direct shell and APK contexts may require different trust integration, while the core must remain deterministic.

### 1.6 Terminal editing

Select libedit versus readline, curses implementation, bundled terminfo, and relocation-aware discovery. Licensing and interactive behavior both matter.

### 1.7 Official CPython Android artifacts

Evaluate how much of the official Android embeddable package, patches, and build conventions can be reused while adding a direct CLI and Astral-like distribution contract.

## 2. Phased implementation

### Phase 0 — contract and test harness

- freeze terminology and invariants from this documentation;
- build relocation and ELF-audit scripts before the final build system;
- define metadata schemas and artifact naming.

### Phase 1 — baseline Android/Bionic core

- target `arm64-v8a` and one conservative minimum API;
- build baseline release without PGO/LTO;
- own OpenSSL, SQLite, libffi, zlib, and other enabled dependencies;
- pass direct Termux tests without linking to Termux packages.

### Phase 2 — cross-context relocation

- pass fresh-extraction tests in Termux, adb shell, and root shell;
- eliminate runtime-critical absolute build and Termux paths;
- finalize certificate and terminfo behavior.

### Phase 3 — full/SDK artifact and native-wheel probe

- publish headers and coherent `sysconfig` metadata;
- build a trivial native extension and wheel;
- validate Android tags and extension loading;
- compare static-dependency and private-shared policies.

### Phase 4 — optimized release engineering

- implement reproducible PGO training;
- enable and validate LTO;
- publish install-only, stripped, full, and debug artifacts;
- publish provenance, licenses, SBOM, and test reports.

### Phase 5 — uv integration in Termux

- provide an Android artifact catalog;
- build or obtain uv for Bionic;
- implement Android host/target selection as required;
- validate `uv python install`, discovery, venv, sync, and run;
- keep direct extraction as an independent release gate.

### Phase 6 — APK reuse

- generate APK-consumable payload from the same core build lineage;
- add JNI/native initialization example;
- validate app linker namespaces and application-private resources;
- use uv primarily at build time for dependency resolution.

### Phase 7 — wheel ecosystem expansion

- automate Android wheel builds;
- port high-value native packages using Termux recipes as references;
- publish compatibility and support policy;
- expand ABI and Android API matrix.

## 3. Questions for future decision records

Each resolved item should receive a short Architecture Decision Record:

- Why was static or private-shared dependency linkage selected?
- What is the supported `libpython` contract?
- What exact relocatability level is guaranteed for SDK metadata?
- What Android API floor is supported and why?
- What modules are intentionally omitted on Android?
- What wheel ABI dependencies are stable and public?
- How are dependency security updates released?
- What guarantees apply to APK consumers versus shell consumers?

## 4. Final design baseline

The stable statement at the end of the discussion is:

> Build an Astral-inspired, self-contained Android/Bionic Core Distribution, then place a project-owned Delivery and Integration Layer above it. That layer must produce an untouched install-only archive that runs after extraction to any suitable final path without uv or Termux packages; expose uv as the preferred optional manager in Termux; preserve direct Termux, adb-shell, and root-shell use as first-class paths; and transform the same core build lineage into Android-native APK packaging.

## Primary references

- [python-build-standalone documentation](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [uv documentation](https://docs.astral.sh/uv/)
- [CPython Android documentation](https://docs.python.org/3/using/android.html)
- [Android NDK documentation](https://developer.android.com/ndk/)
- [Python Packaging User Guide](https://packaging.python.org/)
- [Termux packages repository](https://github.com/termux/termux-packages)
