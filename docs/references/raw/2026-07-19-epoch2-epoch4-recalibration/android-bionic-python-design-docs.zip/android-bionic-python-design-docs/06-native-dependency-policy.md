# 06 — Native Dependency Policy

## 1. Ownership rule

The Android host supplies only deliberately accepted public ABI components. The distribution owns all other runtime dependencies.

```text
Host-owned
----------
Android dynamic linker
Bionic libc
libm and libdl as public NDK interfaces
selected public NDK libraries at declared API levels

Distribution-owned
------------------
OpenSSL or selected crypto implementation
SQLite
libffi
compression and parsing libraries
line-editing and terminal resources
certificates
```

The mere presence of a library in Android system partitions does not make it a public ABI.

## 2. Android platform policy

Android documentation explicitly warns applications not to link against non-NDK platform libraries. Such libraries may vary across releases and devices, and linker namespaces may prevent access.

Consequences:

- do not use Android's private `libssl.so` or `libcrypto.so`;
- do not assume Android's internal SQLite or libffi is publicly linkable;
- bundle or statically link all non-NDK libraries;
- audit every transitive `DT_NEEDED` entry.

## 3. Dependency-specific policy

### 3.1 OpenSSL

Android internally uses BoringSSL-derived components, but does not expose OpenSSL as a stable general-purpose NDK ABI.

Project policy:

- pin upstream source and patch set;
- build for Android/Bionic with the declared minimum API;
- statically link into relevant extensions if Astral-like experiments validate it, otherwise use namespaced private shared libraries;
- ship license texts and configuration/certificate policy;
- test `_ssl`, `_hashlib`, TLS verification, and provider behavior.

### 3.2 SQLite

Android uses SQLite internally, but the native SQLite C library is not the target public ABI for this standalone distribution.

Project policy:

- own the SQLite source version and compile options;
- publish compile-time options in metadata;
- link statically into `_sqlite3` by default candidate;
- test database creation, WAL, locking, URI handling, and Android filesystem behavior.

### 3.3 libffi

libffi supports CPython `_ctypes`. It is not a public Android NDK system-library contract.

Project policy:

- pin and build libffi for each Android ABI;
- link statically into `_ctypes` by default candidate;
- test callbacks, closures, ABI calling conventions, and executable-memory restrictions across API levels.

### 3.4 zlib

Android NDK publicly exposes `libz`, and also provides a matching static `libz.a` in the NDK. The device's dynamic `libz.so` version can differ from the NDK headers.

Project policy candidates:

1. use the NDK static `libz.a` for a controlled and simple dependency;
2. build and statically link a project-pinned zlib for maximum provenance consistency;
3. use device `libz.so` only if size is prioritized and API compatibility is demonstrated.

Because the primary reference emphasizes controlled dependencies, static linkage is preferred unless testing shows a compelling reason otherwise.

## 4. Additional likely dependencies

The manifest and build system should explicitly account for:

- `libbz2`;
- `liblzma`/XZ;
- Expat;
- libedit or readline and curses/terminfo;
- decimal and UUID-related dependencies where applicable;
- CA certificate bundle;
- optional Tcl/Tk, which is likely excluded initially;
- compiler runtime and unwind support.

No dependency may be included merely because it was detected on the Termux build host.

## 5. Termux as a reference, not a runtime provider

Termux recipes are valuable for:

- Android/Bionic configure flags;
- missing API patches;
- cross-compilation fixes;
- test exclusions and Android behavior;
- dependency version experience.

The project may reuse or adapt those patches subject to licensing and attribution. It must rebuild dependencies into its own artifact lineage and must not link to `$PREFIX/lib` at runtime.

## 6. Version and provenance manifest

For every dependency record:

```json
{
  "name": "openssl",
  "version": "...",
  "source": "...",
  "source_sha256": "...",
  "patches": ["..."],
  "license": "...",
  "build_target": "aarch64-linux-android",
  "minimum_android_api": 26,
  "linkage": "static-into-extension",
  "consumers": ["_ssl", "_hashlib"]
}
```

Also record:

- compiler flags and feature options;
- exported symbol policy;
- CVE/security-update tracking;
- test results;
- source archive or commit identity.

## 7. Update policy

A release is defined by the combination of:

```text
CPython version
+ dependency set
+ toolchain
+ patch set
+ build profile
+ Android target matrix
```

A dependency security update therefore creates a new distribution build even when the CPython version is unchanged.

## Primary references

- [Android NDK native APIs](https://developer.android.com/ndk/guides/stable_apis)
- [Android restrictions on non-NDK native libraries](https://developer.android.com/about/versions/nougat/android-7.0-changes#ndk)
- [python-build-standalone technical notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)
- [Termux Python recipe](https://github.com/termux/termux-packages/blob/master/packages/python/build.sh)
- [Termux OpenSSL recipe](https://github.com/termux/termux-packages/tree/master/packages/openssl)
- [Termux SQLite recipe](https://github.com/termux/termux-packages/tree/master/packages/libsqlite)
- [Termux libffi recipe](https://github.com/termux/termux-packages/tree/master/packages/libffi)
- [Termux zlib recipe](https://github.com/termux/termux-packages/tree/master/packages/zlib)
