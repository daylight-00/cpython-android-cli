# 00 — Scope and Design Priorities

## 1. Project statement

The project will produce an **Astral-official-like, relocatable, Android/Bionic-native CPython distribution** suitable for CLI use and reusable by Android application packaging.

The first practical deployment environment is Termux with uv. However, the distribution is not defined as a Termux package and must not depend at runtime on Termux-provided OpenSSL, SQLite, libffi, zlib, `$PREFIX`, or the Termux package database.

## 2. Ordered priorities

### Priority 1 — Astral-official-like Bionic standalone

Astral `python-build-standalone` is the primary architectural reference. The project should preserve, where applicable:

- self-contained and highly portable distribution goals;
- minimized host runtime dependencies;
- deterministic and pinned dependency builds;
- install-only and full/SDK artifact separation;
- optimization variants and explicit build metadata;
- rich machine-readable metadata and licensing information;
- downstream repackaging and embedding support;
- compatibility with uv-style managed-Python selection and installation.

The project should preserve **Astral's design intent**, not blindly copy platform-specific implementation details from glibc Linux, macOS, or Windows.

### Priority 2 — Android/Bionic native, not Termux-overfitted

The runtime contract is:

```text
Android kernel
+ Android dynamic linker
+ Bionic
+ public NDK APIs available at the declared minimum API level
+ declared CPU ABI
```

The runtime contract is not:

```text
Termux app
+ Termux $PREFIX
+ Termux package versions
+ Termux-provided shared libraries
```

Termux remains valuable as:

- the primary development and interactive validation host;
- a source of Android/Bionic patches and build recipes;
- an on-device compiler and native-package build environment;
- the first uv integration target.

### Priority 3 — direct extraction and use

The untouched runtime archive must be usable after extraction at an arbitrary **suitable executable installation path**.

Examples:

```text
/data/data/com.termux/files/home/python
/data/local/tmp/python
/data/local/python
<an app-owned suitable native-code location or packaged native payload>
```

The distribution must not require uv to become runnable. uv may provide management, but direct use must remain valid:

```sh
tar -xf cpython-android.tar.gz
./python/bin/python3 -c 'import ssl, sqlite3, ctypes'
```

## 3. Resulting architecture

```text
Android Core Distribution
        |
        v
Delivery and Integration Layer
        |
        +--> optional uv installation/integration --> Termux
        +--> direct Termux use
        +--> direct adb-shell use
        +--> direct root-shell use
        +--> APK packaging from the same core build lineage
```

The **Android Core Distribution** is the canonical Bionic-native CPython payload. The **Delivery and Integration Layer** is the project-owned layer that turns that payload into install-only archives, full/SDK artifacts, uv catalog entries, direct-shell usage contracts, and APK-consumable packaging. It must remain thin enough that every path consumes the same core rather than rebuilding a different Python for each environment.

## 4. Non-goals

The following are not initial requirements:

- moving a mutated installation after packages have been installed;
- moving pre-existing virtual environments without recreation;
- preserving generated console-script shebangs after relocation;
- installing CPython into Android's read-only `/system` partition;
- treating private Android platform libraries as stable runtime dependencies;
- requiring a single executable or fully static CPython binary;
- guaranteeing that one literal tarball layout is optimal for both shell extraction and APK packaging.

## 5. Identified tensions

### 5.1 Astral Unix install-time fixups versus immediate direct execution

`python-build-standalone` documents build-time paths in `_sysconfigdata`, the Python Makefile, and metadata. uv fixes these paths when it installs managed Python distributions.

This project requires a stronger core-runtime property:

- interpreter startup, standard-library discovery, extension loading, certificates, and terminal support must work immediately after extraction;
- native-extension build metadata should also be relocatable if practical;
- if SDK metadata requires a one-time initialization, that requirement must not affect ordinary runtime execution and must be explicitly documented.

### 5.2 One core versus one packaging format

Termux, `adb shell`, and root shell should consume the same install-only archive.

APK consumption should reuse the same source, patches, dependency versions, compiled core, and provenance, but may require Android-specific repackaging into `jniLibs`, assets, or an application-private layout. The invariant is **one core build lineage**, not necessarily one byte-identical container format.

### 5.3 Astral-like dependency linking versus update granularity

Astral commonly statically links third-party dependencies into Python extension modules. This minimizes runtime dependencies and closely matches the primary reference. Private shared libraries may reduce duplication and ease security updates, but introduce loader, namespace, and SONAME policy.

The provisional default is documented in [05 — Extension and Linkage Policy](05-extension-and-linkage-policy.md), while final selection remains experiment-driven.

## 6. Decision precedence

When requirements conflict, use this order:

1. correctness on the declared Android ABI/API-level matrix;
2. direct extraction and Termux independence;
3. fidelity to Astral's cross-platform distribution philosophy;
4. uv integration convenience;
5. artifact size and build speed.

This order prevents uv or Termux implementation convenience from redefining the core distribution contract.

## Primary references

- [python-build-standalone overview](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [python-build-standalone distribution archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [python-build-standalone behavior quirks](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)
- [uv Python versions](https://docs.astral.sh/uv/concepts/python-versions/)
- [Termux execution environment](https://github.com/termux/termux-packages/wiki/Termux-execution-environment)
