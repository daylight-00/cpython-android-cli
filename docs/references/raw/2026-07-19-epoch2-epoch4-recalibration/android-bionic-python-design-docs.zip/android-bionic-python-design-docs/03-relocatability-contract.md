# 03 — Relocatability Contract

## 1. Canonical definition

For this project:

> **Relocatable means that an untouched distribution archive can be extracted to any suitable final absolute path and the CPython core will run from that location without Termux-specific packages, Termux-specific absolute paths, or rebuilding.**

This is an **extract-anywhere** or **install-prefix-relocatable** contract.

## 2. Required and excluded levels

| Level | Definition | Required |
|---|---|---:|
| Self-contained | Runtime dependency closure is shipped or intentionally delegated to public Android ABI | Yes |
| Extract-anywhere | Fresh archive works at arbitrary suitable final path | Yes |
| Post-install movable | Used installation can later be moved unchanged | No |
| Portable venv | Existing virtual environments survive movement | No |
| Portable generated scripts | pip/installer-generated shebangs survive movement | No |

## 3. Example acceptance scenario

The same untouched artifact is independently extracted to:

```text
/data/data/com.termux/files/home/cpython-a
/data/local/tmp/cpython-b
/data/local/cpython-c
```

At each location:

```sh
./bin/python3 -I -c '
import sys, ssl, sqlite3, ctypes, zlib
print(sys.executable)
print(sys.prefix)
print(ssl.OPENSSL_VERSION)
'
```

must succeed, and `sys.prefix` must reflect the current extraction root.

## 4. Suitable path

"Any path" does not mean every Android-visible path. A suitable path must:

- permit the current UID to traverse and read files;
- permit execution or native loading under the relevant Android policy;
- preserve Unix permissions and archive filenames;
- support required symlinks if the layout uses them;
- not be a shared-storage/FUSE path that removes executable or Unix metadata semantics;
- provide or allow a separate writable `HOME` and `TMPDIR`.

Shared storage such as `/sdcard` is not a required extraction target.

## 5. Runtime relocation invariants

### 5.1 ELF loading

The executable and extension modules must locate distribution-owned shared objects relative to their own location or through an equally location-independent mechanism.

No runtime dependency may resolve to:

```text
/data/data/com.termux/files/usr/lib
$PREFIX/lib
<build-worker absolute path>
```

### 5.2 CPython prefix discovery

The interpreter must locate:

```text
lib/pythonX.Y
lib/pythonX.Y/lib-dynload
site initialization files
encodings
```

relative to the current installation root.

### 5.3 Runtime data

The distribution must define a relocation-aware policy for:

- CA certificates;
- OpenSSL configuration, if used;
- terminfo and line-editing support;
- timezone or locale data if bundled;
- optional Tcl/Tk resources, if ever supported.

Astral documents terminfo as an example where a bundled resource may still require environment initialization because lower-level libraries contain absolute search paths. The Android build must either patch that behavior, provide a launcher initialization mechanism, or document a stable environment variable contract.

### 5.4 Build metadata

`_sysconfigdata`, Python's Makefile, `python-config`, pkg-config files, and metadata often record build-time or install-time paths.

Two acceptable implementation models exist:

1. **Fully dynamic metadata:** derive include and library paths from the current `sys.prefix` at runtime.
2. **Optional SDK initialization:** ordinary Python execution works immediately, while a separate idempotent command initializes only native-extension build metadata for the selected installation path.

The first model is preferred. The second may be accepted only if direct interpreter use and prebuilt-wheel installation remain unaffected.

uv must not be the only available implementation of such initialization.

## 6. Relationship to Astral behavior

Astral distributions are self-contained and highly portable, but the documented Unix builds may retain absolute build-time paths in `_sysconfigdata`, Makefiles, and `PYTHON.json`; uv fixes these when installing managed Python.

The Android project's runtime contract is intentionally stricter for ordinary execution:

```text
fresh extraction -> runnable CPython core
```

It does not require the stronger and largely impractical guarantee:

```text
mutated installation + venvs + generated scripts -> movable forever
```

## 7. Windows experience as the user-facing model

The desired experience is analogous to a Windows standalone archive:

```text
extract to C:\Tools\PythonA -> works
extract the same untouched archive to D:\Apps\PythonB -> works
```

The Android equivalent is not Windows DLL search semantics; it is the same user-visible property implemented with Android-compatible ELF, prefix, and resource discovery.

## 8. Relocation test matrix

Every release candidate should be tested at:

- a long Termux app-private path;
- `/data/local/tmp` under `adb shell`;
- a root-owned `/data/local/...` path;
- a path containing spaces or non-ASCII characters if Android and tooling permit it;
- at least two independent extraction roots in one test run.

The test must inspect loaded libraries and opened files to prove that neither the build root nor Termux `$PREFIX` is used.

## Primary references

- [python-build-standalone behavior quirks: build-time paths and terminfo](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)
- [uv storage and relocation limits for existing virtual environments](https://docs.astral.sh/uv/reference/storage/)
- [python-build-standalone overview](https://gregoryszorc.com/docs/python-build-standalone/main/)
