# 08 — Wheel and Package Ecosystem

## 1. What a wheel is

A wheel is a built Python package archive with the `.whl` extension. Its filename includes compatibility tags:

```text
{distribution}-{version}-{python tag}-{ABI tag}-{platform tag}.whl
```

Examples:

```text
example-1.0-py3-none-any.whl
example-1.0-cp314-cp314-android_26_arm64_v8a.whl
```

## 2. Pure Python versus native wheels

### Pure Python wheel

```text
py3-none-any
```

Contains no platform-specific native extension and is usually usable unchanged on Android if the Python package itself does not assume unavailable OS features.

### Native wheel

Contains one or more compiled `.so` extension modules. Compatibility depends on:

- CPython version and ABI;
- Android platform tag;
- minimum Android API level;
- Android CPU ABI;
- external native dependencies;
- extension-loading and symbol policies of the core distribution.

## 3. Android wheel tags

Python packaging specifications define compatibility tags as:

```text
python tag - ABI tag - platform tag
```

Android platform tags use Android-specific platform identity rather than generic `linux_aarch64`. The runtime's `sysconfig`, `packaging.tags`, build backend, and installer must agree on the Android platform and API floor.

A Termux prefix must not become the public wheel platform identity.

## 4. Package installation paths

### Case A — compatible prebuilt wheel exists

```text
wheel download -> compatibility check -> unpack/install
```

No compiler is required.

### Case B — only source distribution exists

```text
source distribution
       |
       v
PEP 517 build backend
       |
       v
Android compiler + CPython SDK + native dependencies
       |
       v
Android wheel
       |
       v
installation
```

The full/SDK artifact must make this path coherent.

## 5. Termux ecosystem as a reference

Termux is useful because it already contains extensive experience building native Python packages against Bionic:

- Clang and NDK toolchain behavior;
- package-specific Android patches;
- `$PREFIX`-based dependency recipes;
- difficult scientific and cryptographic package build knowledge;
- on-device source builds.

But the standalone wheel contract differs:

```text
Termux package or Termux-specific wheel
    may depend on $PREFIX/lib

Project Android wheel
    must depend only on public Android ABI,
    distribution-defined stable SDK interfaces,
    or dependencies bundled into the wheel
```

Termux recipes are a porting knowledge source, not the target wheel ABI.

## 6. Native dependency strategies for wheels

A native wheel may:

1. depend only on public NDK libraries;
2. bundle private shared libraries inside the wheel and use a supported relative loading layout;
3. statically link third-party dependencies into its extension;
4. depend on a deliberately published, versioned SDK ABI from the core distribution.

It must not accidentally depend on:

```text
/data/data/com.termux/files/usr/lib
unversioned private Android platform libraries
build-host absolute paths
```

## 7. Recommended phased ecosystem

### Phase 1 — pure Python and source builds

- ensure `pip`/uv can install `py3-none-any` wheels;
- provide an SDK artifact for on-device or CI native builds;
- document known unsupported stdlib and platform features.

### Phase 2 — foundational Android wheels

Build and publish a small set of high-value packages that validate the ABI:

- a trivial C extension;
- cffi/cryptography-related probes;
- selected packaging/build tools;
- one C++ extension;
- one Rust/PyO3 extension.

### Phase 3 — automated Android wheel CI

Use standardized Android wheel tags and a repeatable toolchain, with compatibility checks on real devices or emulators across the API matrix.

## 8. venv and relocation boundary

The core distribution is extract-anywhere relocatable. Virtual environments created from it may contain:

- interpreter symlinks or copies;
- absolute paths in `pyvenv.cfg`;
- generated console-script shebangs.

Moving the base installation after venv creation is not guaranteed. uv itself documents that changing the managed Python installation directory does not automatically update existing virtual environments.

## 9. Acceptance criteria for packaging identity

The runtime must report and generate:

- correct Android `sysconfig.get_platform()` output;
- correct extension suffixes;
- correct Python/ABI/platform tags;
- no generic glibc/manylinux tags;
- no Termux-specific public platform tag unless a separate explicitly Termux-targeted ecosystem is intentionally created.

## Primary references

- [Platform compatibility tags](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/)
- [Python package formats and wheel filenames](https://packaging.python.org/en/latest/discussions/package-formats/)
- [CPython on Android](https://docs.python.org/3/using/android.html)
- [Termux Python recipe](https://github.com/termux/termux-packages/blob/master/packages/python/build.sh)
- [uv storage and virtual-environment relocation limitation](https://docs.astral.sh/uv/reference/storage/)
