# 02 — Target Architecture

## 1. Architecture overview

```text
Upstream CPython
Android NDK and pinned toolchain
Pinned third-party dependencies
Official CPython Android support
Termux recipes and patches as references
                |
                v
+------------------------------------------------+
| Android/Bionic Core Distribution Build System  |
|                                                |
| - deterministic dependency builds              |
| - Android ABI and API-level targeting           |
| - CPython configuration and patches             |
| - relocation-aware core layout                  |
| - extension and linkage policy                  |
| - tests, metadata, licenses, and provenance     |
+------------------------------------------------+
                |
                v
        Android Core Distribution
                |
                v
+------------------------------------------------+
| Delivery and Integration Layer                 |
|                                                |
| - install-only and full/SDK archive assembly   |
| - release catalog and uv metadata              |
| - direct-shell launch and environment contracts|
| - APK payload transformation                   |
+------------------------------------------------+
        /          /          |          \
       /          /           |           \
 uv management  direct      direct       APK packaging
      |          Termux      adb/root     from same core
      v
   Termux
```

## 2. Android Core Distribution responsibilities

The core distribution must contain or control:

- CPython executable and/or embeddable `libpython`;
- Python standard library;
- native standard-library extension modules;
- all required non-NDK native dependencies;
- CA certificate strategy;
- terminal editing and terminfo strategy;
- relocation-aware startup and resource discovery;
- correct Android `sysconfig` identity and wheel tags;
- build metadata, dependency versions, checksums, licenses, and provenance.

It must not require:

- uv;
- Termux packages;
- Termux's `$PREFIX`;
- private Android platform libraries;
- a privileged UID.

## 3. Delivery and Integration Layer responsibilities

This layer is the explicit "project work" between the canonical core and its consumers. It must:

- preserve the core payload and provenance across all outputs;
- create relocatable install-only shell archives;
- create full/SDK and debug artifacts;
- publish checksums, manifests, catalogs, and licenses;
- expose optional uv-compatible metadata and installation paths;
- define direct Termux, adb, and root usage without uv;
- transform the same core lineage into APK-consumable placement when needed;
- avoid injecting consumer-specific native dependencies into the core.

It may add wrappers, metadata, path exposure, and packaging transformations. It may not silently replace core libraries with Termux packages or rebuild unrelated Python variants for each consumer.

## 4. Runtime consumers

### 4.1 Direct Termux use

Termux supplies:

- terminal emulator and shell;
- app-private executable filesystem;
- a convenient `HOME`, `TMPDIR`, compiler, and development toolchain.

The core supplies CPython and its complete native dependency closure.

### 4.2 Optional uv-managed Termux use

uv may:

- resolve a requested Python version and variant;
- select the matching Android artifact;
- download and verify it;
- extract it to `UV_PYTHON_INSTALL_DIR`;
- expose executables through `UV_PYTHON_BIN_DIR`;
- discover the interpreter;
- create and manage virtual environments and projects.

uv must not be needed to repair ordinary runtime startup.

### 4.3 `adb shell`

The same shell artifact should operate under the shell UID when extracted to a suitable executable path and provided explicit writable state:

```sh
export HOME=/data/local/tmp/home
export TMPDIR=/data/local/tmp/tmp
/data/local/tmp/python/bin/python3
```

Environment defaults differ; the core binary does not.

### 4.4 Root shell

The root context uses the same artifact. Root changes accessible locations and permissions, not the ABI target. A root-specific CPython build is not required.

### 4.5 APK integration

The APK path reuses the same core build lineage but may transform packaging:

```text
Shell install-only archive               APK payload
--------------------------               -----------
bin/python3                              lib/arm64-v8a/libpython*.so
lib/libpython*.so                        lib/arm64-v8a/private dependencies
lib/python3.x                            assets or app-private stdlib payload
                                         JNI or native launcher
```

The shared invariant is:

- identical source revisions;
- identical patch set;
- identical dependency versions;
- compatible build profile and extension set;
- common metadata and provenance.

The byte-level container need not be identical.

## 5. Artifact families

The design should produce at least:

1. **install-only shell artifact** — direct Termux/ADB/root use and uv installation;
2. **full SDK artifact** — headers, link metadata, static objects/libraries where supported, and machine-readable build metadata;
3. **debug artifact** — debug CPython and unstripped symbols;
4. **APK-consumable payload or repackaging recipe** — same core lineage for embedding.

## 6. Host dependency boundary

```text
Provided by Android host
------------------------
Android kernel
Android dynamic linker
Bionic libc
public NDK libraries deliberately selected by policy
CPU and API-level compatibility

Provided by distribution
------------------------
CPython
stdlib and extension modules
OpenSSL / SQLite / libffi / compression dependencies as selected
certificates and terminal resources
metadata and licenses
```

## 7. Thin environment integration

Environment-specific integration should remain thin:

- choose an installation path;
- set or document `HOME` and `TMPDIR`;
- expose `python` on `PATH`;
- adapt APK file placement and interpreter startup;
- optionally configure uv storage.

It must not substitute missing core libraries or silently introduce Termux package dependencies.

## Primary references

- [python-build-standalone overview](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [python-build-standalone full and install-only archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [uv Python versions](https://docs.astral.sh/uv/concepts/python-versions/)
- [uv storage](https://docs.astral.sh/uv/reference/storage/)
- [CPython on Android](https://docs.python.org/3/using/android.html)
