# 01 — Conceptual Foundations

## 1. Native is not determined by the shell

A shell parses commands and asks the kernel to execute programs. It does not grant or remove native status.

```text
Termux terminal app
        |
        v
Bash or Zsh  --execve()--> CPython ELF
                              |
                              v
                    Android dynamic linker
                              |
                              v
                    Bionic and native libraries
                              |
                              v
                       Android kernel
```

The same Android/Bionic executable can be launched by:

- Termux Bash or Zsh;
- Android `/system/bin/sh` through `adb shell`;
- a root shell;
- an Android application launcher or JNI host.

The meaningful differences are UID, SELinux domain, environment variables, accessible paths, and packaging—not the native instruction set or libc target.

## 2. Native classifications

| Axis | Meaning | Target result |
|---|---|---|
| CPU-native | Executes ARM64 machine code directly | Yes for `arm64-v8a` artifacts |
| Kernel-native | Uses the Android kernel directly, without PRoot or a guest VM | Yes |
| Android ABI-native | Uses Android ELF conventions, Bionic, and Android dynamic linker | Yes |
| Termux-native | Integrated with Termux prefix and package ABI | Optional integration only |
| Android platform component | Built into AOSP/system partitions | No |

The intended description is:

> **Android/Bionic-native and Termux-independent, with optional Termux and uv integration.**

## 3. Termux native versus Android native

Termux programs are already Android-native. Termux documentation states that its packages execute directly on the Android host, are built with the Android NDK, and dynamically link against Bionic.

However, typical Termux packages are also tightly integrated with:

```text
/data/data/com.termux/files/usr
$PREFIX
Termux package versions
Termux-specific patches and configuration
```

Therefore:

```text
Android-native
└── Termux-native Android software
```

The project aims for the broader parent category, while supporting Termux as a consumer.

## 4. Runtime and library layers

A useful dependency model is:

```text
Python application
------------------------------
Python standard library and packages
------------------------------
CPython language runtime
------------------------------
Python native extension modules
------------------------------
OpenSSL / SQLite / libffi / zlib / liblzma / libbz2 / libedit or readline
------------------------------
Bionic + compiler runtime + Android dynamic linker
------------------------------
Android kernel syscall ABI
```

### Library

A library is reusable code and data exposed through an API. It may be static (`.a`) or shared (`.so`). Examples include OpenSSL, SQLite, libffi, and zlib.

### Runtime

A runtime is the mechanism and supporting software that makes execution semantics work. CPython is a language runtime; Bionic is a core part of the C runtime; the Android dynamic linker participates in native process startup.

### Runtime environment

The runtime environment is broader than the runtime binary. It includes:

- libraries and runtime data;
- filesystem layout;
- `HOME`, `TMPDIR`, locale, certificates, and terminal database;
- UID, permissions, SELinux context, and kernel interfaces.

The core distribution owns code and portable data. Each consumer environment supplies context.

## 5. Android, Termux, and Debian userlands

| Property | Android | Termux | Debian |
|---|---|---|---|
| Role | Complete mobile platform OS | Hosted Unix-like app userland | General-purpose Linux distribution |
| libc | Bionic | Bionic | glibc |
| Package model | APK/APEX and platform modules | Termux `.deb` packages under `$PREFIX` | APT/dpkg system packages |
| System ownership | Boot, hardware, framework, app sandbox | Its app-private prefix and processes | General-purpose system userland |
| Typical shell | `/system/bin/sh` | Bash/Zsh | Bash/Dash |
| Service model | Android init and framework services | No independent PID 1 | Usually systemd |

This project does not recreate Debian. It builds a CPython distribution directly for Android's Bionic ABI.

## 6. Public Android ABI boundary

The Android NDK documents public native libraries such as `libc`, `libm`, `libdl`, and `libz`. Android also contains many private platform libraries, but applications must not rely on them because they can change, disappear, or be blocked by linker namespaces.

Therefore the project must:

- depend on Bionic and declared public NDK APIs;
- bundle or statically link non-NDK dependencies;
- avoid treating the presence of a `.so` under `/system/lib64` as a compatibility guarantee.

## Primary references

- [Termux execution environment](https://github.com/termux/termux-packages/wiki/Termux-execution-environment)
- [Android NDK native APIs](https://developer.android.com/ndk/guides/stable_apis)
- [Android 7.0 restrictions on non-NDK native libraries](https://developer.android.com/about/versions/nougat/android-7.0-changes#ndk)
- [CPython on Android](https://docs.python.org/3/using/android.html)
