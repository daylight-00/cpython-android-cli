# 09 — Validation and Acceptance

## 1. Release philosophy

A build is not accepted because it runs in the Termux build environment. It is accepted only after proving the declared Android/Bionic distribution contract across independent contexts and extraction roots.

## 2. Required test dimensions

| Dimension | Minimum coverage |
|---|---|
| CPU ABI | `arm64-v8a` initially; expand explicitly |
| Android API | declared minimum plus at least one recent API |
| Context | direct Termux, adb shell, root shell |
| Installation path | multiple unrelated suitable paths |
| Build profile | baseline release, primary optimized release, debug smoke test |
| Package behavior | stdlib, native extensions, pure wheel, native test wheel |
| Packaging | install-only and full/SDK consistency |

APK integration becomes a separate release gate once implemented.

## 3. Direct-extraction gate

For each context:

1. start from an untouched archive;
2. extract to a new path;
3. do not source Termux environment scripts except what is inherent to the shell;
4. set only explicit `HOME`/`TMPDIR` as needed;
5. run the interpreter and import tests;
6. inspect `sys.prefix`, `sys.path`, `sysconfig`, and wheel tags;
7. trace loaded libraries and opened runtime files.

## 4. Core smoke tests

```python
import bz2
import ctypes
import hashlib
import json
import lzma
import os
import pathlib
import sqlite3
import ssl
import sys
import sysconfig
import zlib

print(sys.version)
print(sys.executable)
print(sys.prefix)
print(sys.exec_prefix)
print(sysconfig.get_platform())
print(ssl.OPENSSL_VERSION)
print(sqlite3.sqlite_version)
```

Also test:

- REPL line editing and special keys;
- Unicode filesystem paths;
- TLS certificate verification;
- SQLite WAL and locking;
- ctypes callbacks;
- subprocess behavior where supported;
- extension-module loading from a wheel;
- venv creation and uv environment creation.

## 5. Dependency audit

For every executable and `.so`:

- inspect ELF interpreter;
- inspect `DT_NEEDED`, `RPATH`, and `RUNPATH`;
- reject references to Termux paths or build roots;
- verify all non-NDK dependencies are statically incorporated or shipped;
- inspect exported symbols and SONAMEs;
- run under Android linker namespace conditions relevant to APK use.

Representative commands:

```sh
readelf -l bin/python3
readelf -d bin/python3
find lib -name '*.so' -exec readelf -d '{}' ';'
strings bin/python3 | grep -E '/data/data/com\.termux|/build|/install'
```

String matches require interpretation, but runtime-critical matches are release blockers.

## 6. File-access audit

Use tracing where available to confirm actual runtime behavior:

```sh
strace -f -e trace=openat,execve   ./bin/python3 -c 'import ssl, sqlite3, ctypes, zlib'
```

Reject unplanned access to:

- `$PREFIX`;
- build-worker paths;
- unrelated system OpenSSL/SQLite/libffi;
- inaccessible certificate or terminfo locations.

## 7. Relocation matrix

A release candidate should be tested with independent fresh extractions, not by copying a previously initialized installation.

| Path | Context | Expected |
|---|---|---|
| Termux long app-private path | Termux UID | Pass |
| `/data/local/tmp/...` | adb shell UID | Pass |
| `/data/local/...` | root | Pass |
| second unrelated path in same context | same UID | Pass |
| `/sdcard/...` | shared storage | Not a required target |

## 8. Astral-fidelity checks

Review each release against the reference philosophy:

- host runtime dependencies minimized;
- dependency versions pinned;
- install-only and full artifacts coherent;
- licensing metadata complete;
- optimization profile explicit;
- extension inventory explicit;
- no opportunistic host-library detection;
- deterministic or explainably reproducible build inputs.

## 9. uv integration gate

After direct extraction passes:

- uv selects the correct Android/Bionic artifact;
- checksum verification succeeds;
- installation path is configurable;
- executable exposure works;
- uv discovers interpreter metadata correctly;
- `uv venv`, `uv sync`, and `uv run` work;
- direct artifact and uv-installed artifact have equivalent core behavior;
- uv does not introduce Termux library dependencies.

## 10. Wheel gate

- install a pure Python wheel;
- build and install a trivial Android native wheel;
- verify tags and extension suffix;
- audit native wheel dependencies;
- create a venv and repeat;
- confirm that unsupported manylinux/glibc wheels are rejected.

## 11. APK gate

When implemented:

- package the same core build lineage;
- load `libpython` and private dependencies under app linker namespaces;
- initialize Python with an app-owned prefix;
- import the same extension set;
- verify no shell or Termux dependency;
- test lifecycle, repeated initialization policy, and application-private storage.

## 12. Release evidence

Each release should publish:

- artifact checksums;
- dependency and toolchain manifest;
- patch manifest;
- SBOM or equivalent inventory;
- test matrix and device/API results;
- relocation audit;
- ELF dependency report;
- license bundle;
- known limitations.

## Primary references

- [python-build-standalone overview](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [python-build-standalone distribution metadata and archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [Android NDK public API boundary](https://developer.android.com/ndk/guides/stable_apis)
- [Android private native library restrictions](https://developer.android.com/about/versions/nougat/android-7.0-changes#ndk)
