# Android/Bionic Standalone CPython Design Documentation

**Status:** design baseline  
**Date:** 2026-07-17  
**Primary reference:** Astral `python-build-standalone` and uv managed-Python behavior

This documentation captures the design conclusions reached for a CPython CLI distribution with three ordered priorities:

1. **Astral-official-like Bionic standalone.** Preserve the philosophy, release engineering, metadata, dependency ownership, artifact structure, and managed-Python compatibility of Astral's standalone distributions wherever Android permits.
2. **Android/Bionic native, not Termux-overfitted.** Termux is the first practical host and development environment, but it is not the runtime ABI contract. The same core must be usable without Termux packages from a suitable Termux path, `adb shell`, a root shell, or an Android application integration.
3. **Direct extraction at an arbitrary suitable final path.** An untouched archive must be usable after extraction to any suitable executable path. uv is optional: it may select, download, install, discover, and manage the distribution, but it must not be required to make the core runtime function.

## Document map

| Document | Purpose |
|---|---|
| [00 — Scope and Design Priorities](00-scope-and-design-priorities.md) | Project definition, precedence rules, non-goals, and identified tensions. |
| [01 — Conceptual Foundations](01-conceptual-foundations.md) | Native, shell, runtime, library, Android, Termux, and Debian distinctions. |
| [02 — Target Architecture](02-target-architecture.md) | Core distribution, consumers, uv path, direct-use paths, and APK reuse. |
| [03 — Relocatability Contract](03-relocatability-contract.md) | Exact meaning of relocatable, suitable paths, invariants, and exclusions. |
| [04 — Artifacts and Build Profiles](04-artifacts-and-build-profiles.md) | Install-only/full/debug artifacts and release, PGO, LTO, and debug profiles. |
| [05 — Extension and Linkage Policy](05-extension-and-linkage-policy.md) | Built-in versus shared Python extensions and static versus shared dependencies. |
| [06 — Native Dependency Policy](06-native-dependency-policy.md) | Bionic/public NDK boundary and OpenSSL, SQLite, libffi, zlib ownership. |
| [07 — uv Integration and Runtime Consumers](07-uv-integration-and-runtime-consumers.md) | Optional uv integration and direct Termux/ADB/root/APK consumption. |
| [08 — Wheel and Package Ecosystem](08-wheel-and-package-ecosystem.md) | Wheel fundamentals, Android tags, Termux as a reference, and source builds. |
| [09 — Validation and Acceptance](09-validation-and-acceptance.md) | Cross-context tests, dependency audits, relocation matrix, and release gates. |
| [10 — Open Questions and Phased Plan](10-open-questions-and-phased-plan.md) | Decisions still requiring experiments and an implementation sequence. |
| [References](REFERENCES.md) | Primary sources preserved from the discussion. |
| [Module Review Notes](REVIEW-NOTES.md) | Independent review outcome for each module. |

## Canonical architecture

```text
Astral philosophy and python-build-standalone reference
                         |
                         v
              Android Core Distribution
                         |
                         v
          Delivery and Integration Layer
        /          /          |          \
       /          /           |           \
 uv management  direct      direct       APK packaging
      |          Termux      adb/root     from same core
      v
   Termux
```

The architectural rule is:

> **The Delivery and Integration Layer exposes one Android Core Distribution through several independent paths. uv is one optional path, not a runtime prerequisite.**

## Terminology policy

- **Android-native / Bionic-native:** compiled for an Android ABI, loaded by the Android dynamic linker, using Bionic and public Android/NDK interfaces.
- **Termux-native:** Android-native software integrated with Termux's prefix, package set, and runtime assumptions.
- **Termux-independent:** does not require Termux packages, `$PREFIX`, or Termux-specific absolute runtime paths.
- **Relocatable:** an untouched archive may be extracted to an arbitrary suitable final path and used there without path-specific rebuilding.
- **Portable installed environment:** an already-used installation, including venvs and generated scripts, can be moved after mutation. This is explicitly not guaranteed.

## Reference policy

Astral documentation is the primary design reference. Official CPython, Android NDK, Python Packaging Authority, and Termux documentation define platform contracts and compatibility boundaries. Termux recipes may be used as Android/Bionic porting references, but Termux package ABI and prefix assumptions are not part of the target runtime contract.
