# 07 — uv Integration and Runtime Consumers

## 1. Placement in the architecture

```text
Android Core Distribution
        |
        v
Delivery and Integration Layer
        |
        +--> uv installation/integration --> Termux
        +--> direct Termux
        +--> adb
        +--> root
        +--> APK
```

uv is treated as the preferred contemporary Python manager and the primary practical managed integration path in Termux. It is one output of the Delivery and Integration Layer alongside direct-use and APK outputs.

However:

> **The core distribution must function without uv.**

uv is responsible for management operations, not for defining the Android ABI or supplying missing runtime libraries.

## 2. Desired uv workflow

The target user experience is:

```sh
uv python install 3.14
uv venv --python 3.14
uv sync
uv run python
```

For Android, uv would need to understand or be extended to understand:

- Android as distinct from generic Linux;
- Bionic rather than glibc or musl;
- CPU ABI such as `aarch64`/`arm64-v8a`;
- minimum Android API level;
- GIL, free-threaded, and debug variants;
- artifact naming, catalog, and executable discovery.

As of the documentation baseline, uv's bundled managed Python downloads are described for macOS, Linux, and Windows; Android support requires separate integration work.

## 3. Existing uv mechanisms to reuse

uv already provides useful management concepts:

- managed Python version selection and automatic download;
- explicit implementation/version/OS/architecture/libc requests;
- `UV_PYTHON_INSTALL_DIR`;
- `UV_PYTHON_BIN_DIR`;
- custom Python installation JSON through `python-downloads-json-url` / `UV_PYTHON_DOWNLOADS_JSON_URL`;
- Python install mirrors;
- interpreter discovery and metadata querying;
- venv, project, tool, lock, and sync workflows.

The project should integrate with these mechanisms rather than build a competing version manager unless an upstream limitation makes it unavoidable.

## 4. Distribution catalog

An Android artifact catalog should describe:

```json
{
  "implementation": "cpython",
  "version": "3.14.6",
  "target": "aarch64-linux-android",
  "android_abi": "arm64-v8a",
  "minimum_android_api": 26,
  "variant": "gil",
  "optimization": "pgo+lto",
  "artifact_flavor": "install_only",
  "url": "...",
  "sha256": "..."
}
```

The uv integration design must determine whether Android API level belongs in uv's platform identity, artifact metadata, compatibility selection logic, or all three.

## 5. Direct runtime paths remain first-class

### Direct Termux

```sh
tar -xf cpython-android.tar.gz
./python/bin/python3
```

### `adb shell`

```sh
mkdir -p /data/local/tmp/py-home /data/local/tmp/py-tmp
HOME=/data/local/tmp/py-home TMPDIR=/data/local/tmp/py-tmp /data/local/tmp/python/bin/python3
```

### Root shell

Same artifact, different accessible installation roots and security context.

No direct path may require uv-generated wrappers to locate the standard library or native dependencies.

## 6. Environment-specific defaults

Thin integration may set defaults without changing the core:

| Context | Likely integration responsibility |
|---|---|
| Termux | PATH exposure, uv storage defaults, `HOME`, `TMPDIR`, shell completion |
| adb shell | explicit persistent or temporary storage roots, HOME/TMPDIR creation |
| root | optional system-wide path under `/data/local`, ownership and permissions |
| APK | native library placement, stdlib packaging, JNI/native launcher, lifecycle |

These are deployment policies, not separate Python ABIs.

## 7. APK relationship

The official CPython Android documentation centers on embedding `libpython` in an Android application and packaging the interpreter, standard library, and code for app-private use.

This project adds a CLI distribution, but the APK path should remain compatible with the official embedding model:

- use the same core build lineage;
- expose an embeddable `libpython` and dependency payload;
- provide an APK packaging recipe or generated payload;
- do not require the APK to execute a Termux-style prefix;
- do not require uv inside the application at runtime.

uv may still be used at APK build time to resolve Python dependencies and collect Android-compatible wheels.

## 8. uv must not hide core defects

Release validation must test direct extraction before uv integration. A distribution that works only after uv rewrites runtime-critical paths does not satisfy the core contract.

Recommended order:

```text
1. direct extraction validation
2. uv installation validation
3. uv venv and project workflows
4. direct and uv-installed artifact equivalence checks
```

## 9. Upstream strategy

Prefer an upstreamable division:

- this project publishes Android/Bionic CPython artifacts and metadata;
- uv gains Android host/target and managed-Python support;
- custom JSON/mirror mechanisms allow independent release cadence;
- Termux packaging may distribute uv or a minimal integration profile without owning the Python runtime dependencies.

## Primary references

- [uv Python versions](https://docs.astral.sh/uv/concepts/python-versions/)
- [uv storage](https://docs.astral.sh/uv/reference/storage/)
- [uv settings: custom Python downloads and install mirror](https://docs.astral.sh/uv/reference/settings/)
- [uv environment variables](https://docs.astral.sh/uv/reference/environment/)
- [uv Android target issue](https://github.com/astral-sh/uv/issues/14574)
- [CPython on Android](https://docs.python.org/3/using/android.html)
