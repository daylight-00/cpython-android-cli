# Module Review Notes

Each module was reviewed independently for scope, internal consistency, consistency with the ordered priorities, and preservation of primary references.

## Review criteria

- Does the module distinguish Android/Bionic-native from Termux integration?
- Does it preserve direct extraction and uv-optional behavior?
- Does it distinguish one core build lineage from one literal packaging format?
- Does it avoid claiming that a shell determines native status?
- Does it distinguish Python extensions from their third-party dependencies?
- Does it avoid relying on private Android platform libraries?
- Does it avoid promising movement of mutated venvs or generated scripts?
- Are unresolved engineering choices labeled as provisional or experimental?
- Are official references included?

## Module outcomes

### README

**Result:** Pass.  
Provides the canonical architecture, ordered priorities, terminology, and document navigation without introducing new policy.

### 00 — Scope and Design Priorities

**Result:** Pass.  
The priority order matches the final discussion. The primary tension—Astral Unix fixups versus immediate direct extraction—is explicit. APK reuse is defined as common core lineage rather than forced byte-identical packaging.

### 01 — Conceptual Foundations

**Result:** Pass.  
Correctly separates shell, terminal, ABI, libc, and execution context. Termux-native is presented as a narrower integration category within Android-native software.

### 02 — Target Architecture

**Result:** Pass after structural revision.  
The document now explicitly separates the canonical Android Core Distribution from the project-owned Delivery and Integration Layer requested in the final architecture. uv is optional and appears only on the Termux-managed path. Direct Termux, adb, and root are first-class. APK packaging is a sibling consumer of the same core lineage.

### 03 — Relocatability Contract

**Result:** Pass with one deliberate limitation.  
The guaranteed level is fresh extract-anywhere use. Movement of mutated installations, venvs, and generated scripts is excluded. SDK metadata relocation remains an implementation question, but it cannot block ordinary runtime use.

### 04 — Artifacts and Build Profiles

**Result:** Pass.  
Optimization profiles and archive flavors are independent. Astral `noopt` is correctly treated as baseline release rather than debug `-O0`. PGO provenance and LTO toolchain compatibility are explicit.

### 05 — Extension and Linkage Policy

**Result:** Pass as a decision framework, not a finalized linkage decision.  
The module corrects an earlier overcommitment to private shared dependencies by restoring Astral's static-into-extension model as the primary candidate. It requires an explicit comparison against namespaced private shared dependencies.

### 06 — Native Dependency Policy

**Result:** Pass.  
Public NDK versus private Android platform libraries is clear. OpenSSL, SQLite, and libffi are distribution-owned. zlib's public NDK status is acknowledged without abandoning reproducible dependency ownership.

### 07 — uv Integration and Runtime Consumers

**Result:** Pass.  
uv management is preferred but optional. Existing uv mechanisms are reused conceptually. Current Android integration work is not misrepresented as already complete.

### 08 — Wheel and Package Ecosystem

**Result:** Pass.  
Explains wheel basics without assuming prior knowledge. Termux is a source of build recipes and patches, not the public wheel ABI. Pure and native wheel paths are separated.

### 09 — Validation and Acceptance

**Result:** Pass.  
Release gates directly test the project claims: multiple extraction roots, multiple Android contexts, dependency closure, absence of Termux paths, correct wheel identity, and uv equivalence after direct runtime success.

### 10 — Open Questions and Phased Plan

**Result:** Pass.  
Unresolved items are isolated from settled goals. The implementation sequence establishes direct runtime correctness before uv and APK integration.

### References

**Result:** Pass.  
Primary sources are preserved and grouped. The hierarchy gives Android and CPython platform contracts precedence over implementation references.

## Cross-document consistency findings

1. **uv is optional everywhere.** No module makes uv a runtime prerequisite.
2. **Termux is a primary host, not the ABI.** No module permits `$PREFIX` runtime dependencies in the core.
3. **Relocatability has one stable definition.** Fresh extraction to a suitable final path is guaranteed; post-mutation movement is not.
4. **The Delivery and Integration Layer is explicit.** It sits between the canonical core and uv/direct-shell/APK outputs, preserving the user's requested architecture.
5. **APK is a core consumer, not necessarily the same archive.** This avoids a packaging conflict while preserving one build lineage.
6. **Linkage policy remains intentionally open.** Astral-like static dependency linkage is the default candidate, but private shared linkage remains an experiment.
7. **Wheel identity is Android, not generic Linux or Termux.**

## Items that must not be silently changed later

- making uv mandatory for interpreter startup;
- linking core artifacts to Termux package libraries;
- defining `relocatable` as post-install venv portability;
- calling private Android system libraries stable dependencies;
- building APK support from a separate, unrelated CPython/dependency lineage;
- publishing Android native wheels with generic manylinux/glibc identity.
