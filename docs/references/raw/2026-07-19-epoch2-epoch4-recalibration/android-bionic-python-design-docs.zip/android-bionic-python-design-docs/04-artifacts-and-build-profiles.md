# 04 — Artifacts and Build Profiles

## 1. Separate optimization profile from artifact flavor

These are independent axes.

### Optimization profile

Describes how code was compiled:

- debug;
- baseline release;
- PGO;
- LTO;
- PGO + LTO.

### Artifact flavor

Describes what files are shipped:

- install-only;
- install-only stripped;
- full/SDK;
- debug symbols or debug full.

An artifact name must encode both axes or expose them in metadata.

## 2. Astral profile mapping

`python-build-standalone` uses optimization labels such as:

| Astral label | Project interpretation |
|---|---|
| `debug` | Debug CPython, diagnostics enabled, not a normal end-user build |
| `noopt` | Baseline release build without PGO or LTO |
| `pgo` | Profile-guided optimization |
| `lto` | Link-time optimization |
| `pgo+lto` | Combined optimized release |

Astral's install-only archive uses the fastest available build, preferring `pgo+lto`, then `pgo`, `lto`, and `noopt`.

## 3. Recommended profiles

### 3.1 Primary release: `release-pgo+lto`

Purpose:

- default uv-managed and directly extracted runtime;
- performance-oriented user distribution;
- stripped install-only artifact plus separate symbols.

Requirements:

- reproducible PGO training workload;
- target-device or representative Android execution for profile collection;
- recorded compiler, linker, NDK, workload, and profile-data hashes;
- regression tests against baseline release.

### 3.2 Baseline release: `release-baseline`

Purpose:

- control build for diagnosing PGO/LTO failures;
- faster iterative release engineering;
- compatibility and performance comparison.

This corresponds conceptually to Astral `noopt`, not to an unoptimized `-O0` build.

### 3.3 Debug: `debug`

Purpose:

- CPython assertions and allocator diagnostics;
- C-level debugging of Bionic, loader, extension, and memory issues;
- unstripped symbols and debugger-friendly metadata.

Debug variants must be distinguishable in Python ABI metadata and uv variant selection.

### 3.4 Optional individual `pgo` and `lto`

These are useful during bring-up and regression isolation but need not be permanent public release artifacts if `pgo+lto` and baseline are reliable.

## 4. PGO on Android

PGO requires:

```text
instrumented build
       |
       v
representative workload on target or equivalent runtime
       |
       v
profile collection
       |
       v
optimized rebuild
```

Key Android-specific concerns:

- cross-build host cannot necessarily execute target binaries;
- device heterogeneity may bias training;
- Android process policy and filesystem performance may distort workloads;
- the training suite should represent interpreter startup, imports, common stdlib use, and package workflows rather than one synthetic benchmark.

The profile recipe is part of release provenance.

## 5. LTO on Android

LTO enables whole-program optimization across compilation units. The project must record:

- full versus ThinLTO;
- exact Clang/LLVM version;
- linker and plugin versions;
- whether full/SDK artifacts contain native objects or LLVM bitcode;
- downstream restrictions when reusing those artifacts.

Astral warns that reconsuming build artifacts can be fragile when toolchains differ. The Android SDK artifact should therefore publish a supported toolchain contract.

## 6. Artifact flavors

### 6.1 Install-only

Contains only the runtime installation:

```text
python/
├── bin/
├── lib/
├── include/          # optional policy decision
├── share/
├── etc/
└── licenses/
```

Use cases:

- direct Termux/ADB/root extraction;
- uv managed-Python installation;
- runtime tests.

### 6.2 Install-only stripped

Same runtime contract with nonessential debug information removed. Separate symbol archives should preserve diagnosability.

### 6.3 Full/SDK

Contains:

- installable runtime;
- headers;
- static and import libraries as supported;
- extension and dependency objects where legally and technically appropriate;
- `PYTHON.json`-like machine-readable metadata;
- sysconfig and wheel-build support;
- licenses and source provenance.

### 6.4 Debug full

Contains debug CPython, symbols, diagnostic libraries, and metadata for native debugging.

## 7. Suggested artifact naming

```text
cpython-3.14.6+build1-aarch64-linux-android-api26-pgo+lto-install_only.tar.gz
cpython-3.14.6+build1-aarch64-linux-android-api26-pgo+lto-install_only_stripped.tar.gz
cpython-3.14.6+build1-aarch64-linux-android-api26-baseline-full.tar.zst
cpython-3.14.6+build1-aarch64-linux-android-api26-debug-full.tar.zst
```

Metadata remains authoritative; filenames are an index.

## 8. Minimum metadata

```json
{
  "python_version": "3.14.6",
  "python_abi": "cp314",
  "target_triple": "aarch64-linux-android",
  "android_abi": "arm64-v8a",
  "minimum_android_api": 26,
  "gil_mode": "gil",
  "build_type": "release",
  "optimization": "pgo+lto",
  "lto_mode": "thin",
  "artifact_flavor": "install_only",
  "toolchain": {
    "ndk": "...",
    "clang": "...",
    "lld": "..."
  }
}
```

## Primary references

- [python-build-standalone distribution archives and optimization preference](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
- [python-build-standalone running and reconsuming build artifacts](https://gregoryszorc.com/docs/python-build-standalone/main/running.html)
- [uv Python version variants](https://docs.astral.sh/uv/concepts/python-versions/)
