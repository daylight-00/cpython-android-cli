# References

This list preserves the primary sources used during the discussion. The design documents prefer official or primary project documentation.

## Astral and python-build-standalone

1. [python-build-standalone — overview](https://gregoryszorc.com/docs/python-build-standalone/main/)  
   Defines self-contained, highly portable distributions and minimized runtime dependencies.
2. [Distribution Archives](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)  
   Describes full and install-only archives and optimization preference order.
3. [Running Distributions](https://gregoryszorc.com/docs/python-build-standalone/main/running.html)  
   Covers use and reuse of build artifacts and toolchain compatibility.
4. [Behavior Quirks](https://gregoryszorc.com/docs/python-build-standalone/main/quirks.html)  
   Documents terminfo behavior, Windows pip launcher portability, build-time absolute paths, and uv fixups.
5. [Technical Notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)  
   Documents deterministic dependency builds, static linkage into extensions, `Setup.local`, and dependency choices.
6. [python-build-standalone GitHub repository](https://github.com/astral-sh/python-build-standalone)

## uv

7. [uv documentation](https://docs.astral.sh/uv/)
8. [Python versions](https://docs.astral.sh/uv/concepts/python-versions/)  
   Covers managed Python downloads, variants, discovery, and executable exposure.
9. [Installing and managing Python](https://docs.astral.sh/uv/guides/install-python/)
10. [Storage](https://docs.astral.sh/uv/reference/storage/)  
    Documents managed Python directories and the fact that moving installations does not update existing venvs.
11. [Settings](https://docs.astral.sh/uv/reference/settings/)  
    Includes custom Python-download JSON and install-mirror settings.
12. [Environment variables](https://docs.astral.sh/uv/reference/environment/)  
    Includes `UV_PYTHON_INSTALL_DIR`, `UV_PYTHON_BIN_DIR`, and custom-download controls.
13. [uv issue: support target `aarch64-linux-android`](https://github.com/astral-sh/uv/issues/14574)

## CPython and Python packaging

14. [Using Python on Android — Python 3.14](https://docs.python.org/3/using/android.html)  
    Defines the official Android embedding model and app-private packaging assumptions.
15. [Python releases for Android](https://www.python.org/downloads/android/)
16. [Platform compatibility tags](https://packaging.python.org/en/latest/specifications/platform-compatibility-tags/)  
    Defines wheel tag structure and platform compatibility semantics.
17. [Python package formats](https://packaging.python.org/en/latest/discussions/package-formats/)  
    Introduces wheel filename components and package formats.

## Android

18. [Android NDK native APIs](https://developer.android.com/ndk/guides/stable_apis)  
    Defines public NDK libraries, Bionic-related core APIs, and zlib behavior.
19. [Android 7.0 behavior changes — linking to platform libraries](https://developer.android.com/about/versions/nougat/android-7.0-changes#ndk)  
    Explains why non-NDK private native libraries must not be runtime dependencies.
20. [Android NDK documentation](https://developer.android.com/ndk/)

## Termux

21. [Termux execution environment](https://github.com/termux/termux-packages/wiki/Termux-execution-environment)  
    States that Termux programs execute natively on Android and documents Bionic and prefix assumptions.
22. [Termux packages repository](https://github.com/termux/termux-packages)
23. [Termux CPython build recipe](https://github.com/termux/termux-packages/blob/master/packages/python/build.sh)
24. [Termux OpenSSL recipe](https://github.com/termux/termux-packages/tree/master/packages/openssl)
25. [Termux SQLite recipe](https://github.com/termux/termux-packages/tree/master/packages/libsqlite)
26. [Termux libffi recipe](https://github.com/termux/termux-packages/tree/master/packages/libffi)
27. [Termux zlib recipe](https://github.com/termux/termux-packages/tree/master/packages/zlib)

## Reference hierarchy

When sources appear to imply different designs, use this hierarchy:

1. official Android ABI and security contracts;
2. official CPython platform behavior;
3. Python packaging specifications;
4. Astral distribution philosophy and managed-Python behavior;
5. Termux implementation experience as a porting reference.

This ordering prevents a useful implementation reference from overriding the target platform's public compatibility contract.
