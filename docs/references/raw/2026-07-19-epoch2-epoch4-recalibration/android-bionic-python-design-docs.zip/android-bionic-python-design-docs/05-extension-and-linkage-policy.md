# 05 — Extension and Linkage Policy

## 1. Distinguish two independent choices

### Python extension placement

- **Built-in:** module code is linked into the interpreter or `libpython`.
- **Shared extension:** module is a separately loadable `.so` under `lib-dynload` or a package.

### Third-party dependency linkage

- **Static into extension:** e.g. SQLite code is linked into `_sqlite3.so`.
- **Private shared dependency:** `_sqlite3.so` depends on a distribution-owned `libsqlite3_*.so`.
- **Public system dependency:** extension depends on a documented public NDK library.

These choices must not be conflated.

## 2. Primary Astral reference behavior

Astral documents a build strategy where Python extensions are built deterministically and third-party dependencies such as SQLite are statically linked into the extension rather than remaining runtime dependencies on host `libsqlite3.so`.

This supports:

- minimized host runtime dependencies;
- deterministic dependency versions;
- avoidance of incompatible host libraries;
- straightforward install-only archives.

Astral also uses custom `Modules/Setup.local` or equivalent controlled build declarations rather than relying entirely on opportunistic host detection.

## 3. Recommended provisional policy

### 3.1 Python extension modules

- Keep essential bootstrap modules built in.
- Keep ordinary standard-library native extensions as separately loadable `.so` files.
- Preserve support for third-party native extension modules and Android wheels.

Example:

```text
bin/python3
lib/libpython3.14.so            # final decision may vary
lib/python3.14/lib-dynload/
├── _ssl....so
├── _hashlib....so
├── _sqlite3....so
├── _ctypes....so
├── zlib....so
└── _lzma....so
```

This retains a mainstream CPython extension-loading model.

### 3.2 Third-party dependencies

The Astral-faithful default candidate is:

```text
_ssl.so      <- static OpenSSL components as supported
_hashlib.so  <- static crypto components as supported
_sqlite3.so  <- static SQLite
_ctypes.so   <- static libffi
zlib.so      <- static project-pinned zlib or NDK static zlib
_lzma.so     <- static liblzma
_bz2.so      <- static libbz2
```

This must be experimentally validated for:

- code-size duplication;
- exported-symbol visibility;
- duplicate-library state across modules;
- OpenSSL initialization and provider behavior;
- APK and shell linker namespaces;
- licensing and attribution;
- sanitizer and debugger behavior.

## 4. Alternative private-shared model

If static linkage creates unacceptable duplication or update costs, use versioned and namespaced private shared objects:

```text
lib/libcpython_android_crypto.so
lib/libcpython_android_sqlite3.so
lib/libcpython_android_ffi.so
```

Advantages:

- one copy shared by multiple modules;
- smaller aggregate code size;
- easier replacement of a vulnerable dependency within a distribution update;
- potentially clearer symbol debugging.

Costs:

- RUNPATH and loader-namespace complexity;
- SONAME and symbol-visibility policy;
- collision risk in embedding processes;
- more runtime files and dependency ordering;
- APK packaging requirements.

Private shared libraries must never use ambiguous unnamespaced assumptions about host `libssl.so` or `libsqlite3.so`.

## 5. `libpython` policy

The project needs both CLI and APK/embedding use cases. Candidate policies:

### Shared `libpython`

Pros:

- natural APK embedding artifact;
- smaller CLI executable;
- one runtime implementation shared with embedding consumers.

Cons:

- additional relocation and RUNPATH requirements;
- embedding hosts must load the correct private library;
- symbol-export policy becomes important.

### Statically linked CLI plus separate embeddable library

Pros:

- robust CLI startup;
- fewer runtime loader dependencies for direct shell use.

Cons:

- potentially two different linkage products;
- increased testing and provenance complexity;
- less direct identity between CLI and APK core.

**Provisional recommendation:** prefer a private shared `libpython` if it can be made reliably location-independent across Termux, ADB, root, and APK packaging. Keep a static CLI experiment as a fallback and benchmark both.

## 6. Symbol visibility

Distribution-owned static or shared dependencies should not unintentionally export broad symbol sets into the process. This is especially important when third-party wheels or APK libraries load another copy of the same upstream dependency.

Required controls include:

- hidden visibility by default;
- explicit export maps/version scripts;
- auditing `DT_NEEDED`, exported symbols, and relocation entries;
- tests that load unrelated wheels or host libraries with overlapping dependency names.

## 7. Extension availability manifest

Each artifact must record:

- built-in modules;
- shared standard-library extensions;
- omitted or restricted Android modules;
- per-extension third-party dependencies;
- linkage mode and source versions;
- loading support for third-party `.so` extensions.

This should be machine-readable and analogous in purpose to Astral `PYTHON.json`.

## 8. Decision gate

Before finalizing linkage policy, build and compare at least:

1. shared Python extensions with statically linked third-party dependencies;
2. shared Python extensions with namespaced private shared dependencies.

Compare:

- total archive and installed size;
- cold startup and import time;
- memory sharing;
- symbol collisions;
- relocation simplicity;
- security-update rebuild scope;
- APK integration;
- wheel compatibility.

## Primary references

- [python-build-standalone technical notes](https://gregoryszorc.com/docs/python-build-standalone/main/technotes.html)
- [python-build-standalone overview and minimized runtime dependencies](https://gregoryszorc.com/docs/python-build-standalone/main/)
- [python-build-standalone full distribution metadata](https://gregoryszorc.com/docs/python-build-standalone/main/distributions.html)
